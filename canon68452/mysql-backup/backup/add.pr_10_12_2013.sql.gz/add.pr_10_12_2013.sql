#
# MySQL database dump
# Created by MySQL_Backup class, ver. 1.0.0
#
# Host: localhost
# Generated: Oct 12, 2013 at 21:47
# MySQL version: 5.1.67-community-log
# PHP version: 5.3.21
#
# Database: `creative_ls`
#


#
# Table structure for table `accordions`
#

DROP TABLE IF EXISTS `accordions`;
CREATE TABLE `accordions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_album` int(11) NOT NULL COMMENT 'Номер альбома',
  `accordion_nm` varchar(64) NOT NULL COMMENT 'Имя кнопки',
  `collapse_numer` int(11) NOT NULL COMMENT 'Номер раздела акордеона',
  `collapse_nm` varchar(64) NOT NULL COMMENT 'Имя раздела',
  `collapse` text NOT NULL COMMENT 'Содержание раздела',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=cp1251;

#
# Dumping data for table `accordions`
#

INSERT INTO accordions VALUES ('1', '1', 'Условия и скидки!', '1', 'Заказ фотографий:', 'Фотографии, представленные в данном альбоме прошли предварительную ручную обработку и полностью подготовлены к печати в размере 13x18см 300Dpi в городских минилабах с применением стандартного профиля. Внимание! В целях экономии места на сервере и защиты контента превьюшки, представленные на странице, сильно сжаты и предназначены только для общего представления о фотографии (местность, время, кадрировка, закрытые глаза, номер кадра и т.д ). При покупке фотографии на Ваш email,указанный при регистрации, придет ссылка для скачивания файла фотографии в разрешении <code>13x18см 300Dpi</code> без <code>IP</code> - защиты и <code>водяного знака</code>. Выкупленные фотографии Вы имеете право распечатывать в любом количестве. Для использования фотографий в рекламных или коммерческих целях свяжитесь с фотографом.');
INSERT INTO accordions VALUES ('2', '1', 'Условия и скидки!', '2', 'Рейтинговая система голосования:', 'На сайте действует системе оценки фотографий посетителями. Вы можете проголосовать за понравившуюся Вам фотографию, повысив ее рейтинг. Пять лучших фотографий, набравших максимальное количество баллов, размещаются в шапке альбома на призовых местах.');
INSERT INTO accordions VALUES ('3', '1', 'Условия и скидки!', '3', 'Действующие на альбом акции и скидки:', 'Фотографии, набравшие больше 5 звездочек в рейтинге, распечатаваются для владельцев бесплатно.');
INSERT INTO accordions VALUES ('44', '737', 'default', '1', 'default', '');
INSERT INTO accordions VALUES ('41', '734', 'default', '1', 'default', '');
INSERT INTO accordions VALUES ('32', '730', '', '1', 'default', '');
INSERT INTO accordions VALUES ('37', '729', '', '1', 'default', '');
INSERT INTO accordions VALUES ('38', '731', 'default', '1', 'default', '');
INSERT INTO accordions VALUES ('40', '733', 'default', '1', 'default', '');


#
# Table structure for table `account_inv`
#

DROP TABLE IF EXISTS `account_inv`;
CREATE TABLE `account_inv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL COMMENT 'Номер пользователя',
  `merchant_id` varchar(64) NOT NULL COMMENT ' id мерчанта',
  `amount` float(8,2) NOT NULL DEFAULT '0.00' COMMENT 'Сумма пополнения',
  `sys` enum('card','liqpay','easypay') NOT NULL DEFAULT 'card' COMMENT 'Система оплаты',
  `currency` varchar(64) NOT NULL COMMENT 'Валюта',
  `description` varchar(512) NOT NULL COMMENT 'Описание',
  `status` varchar(64) NOT NULL COMMENT 'статус транзакции',
  `code` varchar(64) NOT NULL COMMENT 'код ошибки (если есть ошибка)',
  `transaction_id` varchar(64) NOT NULL COMMENT 'id транзакции в системе LiqPay',
  `pay_way` varchar(64) NOT NULL COMMENT 'способ которым оплатит покупатель(если не указывать то он сам выбирает, с карты или с телефона(liqpay, card))',
  `sender_phone` varchar(64) NOT NULL COMMENT 'телефон оплативший заказ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=cp1251 COMMENT='Пополнение счета на сайте';

#
# Dumping data for table `account_inv`
#

INSERT INTO account_inv VALUES ('100', '29', 'i3213059147', '0.02', 'liqpay', 'UAH', 'photo', 'failure', '', '26627060', 'card', '+380949477070');
INSERT INTO account_inv VALUES ('101', '29', 'i3213059147', '0.02', 'liqpay', 'UAH', 'photo', 'failure', '', '26627080', 'card', '+380949477070');
INSERT INTO account_inv VALUES ('102', '29', 'i3213059147', '1.00', 'liqpay', 'UAH', 'photo', 'wait_secure', '', '26627163', 'card', '+380949477070');
INSERT INTO account_inv VALUES ('103', '29', '', '0.00', 'card', '', '', '', '', '', '', '');
INSERT INTO account_inv VALUES ('104', '59', '', '0.00', 'card', '', '', '', '', '', '', '');


#
# Table structure for table `actions`
#

DROP TABLE IF EXISTS `actions`;
CREATE TABLE `actions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL COMMENT 'Номер пользователя',
  `ip` varchar(64) NOT NULL COMMENT 'Ip последнего захода',
  `brauzer` varchar(256) NOT NULL COMMENT 'браузер пользователя',
  `user_event` enum('вход','выход','подписка','отписка','покупка фотографий','сообщение в контакте','сообщение в гостевой','пополнение счета') NOT NULL COMMENT 'Событие юзера (подписка,отписка, покупка фотографий,сообщение в контакте,сообщение в гостевой)',
  `time_event` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Время  события',
  `id_album` int(11) NOT NULL COMMENT 'Номер альбома',
  `id_subs` int(11) NOT NULL COMMENT 'id акции',
  `id_account_inv` int(11) NOT NULL COMMENT 'id пополнения счета',
  PRIMARY KEY (`id`),
  KEY `id_user` (`id_user`),
  KEY `time_event` (`time_event`),
  KEY `user_event` (`user_event`,`id_album`),
  KEY `id_subs` (`id_subs`),
  KEY `id_account_inv` (`id_account_inv`)
) ENGINE=MyISAM AUTO_INCREMENT=559 DEFAULT CHARSET=cp1251 COMMENT='действия пользователей';

#
# Dumping data for table `actions`
#

INSERT INTO actions VALUES ('149', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'пополнение счета', '2013-06-10 23:43:45', '0', '0', '100');
INSERT INTO actions VALUES ('168', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'пополнение счета', '2013-06-10 23:54:12', '0', '0', '102');
INSERT INTO actions VALUES ('169', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 'вход', '2013-06-10 23:56:08', '0', '0', '0');
INSERT INTO actions VALUES ('170', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 'пополнение счета', '2013-06-10 23:56:11', '0', '0', '103');
INSERT INTO actions VALUES ('171', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-11 16:02:25', '0', '0', '0');
INSERT INTO actions VALUES ('172', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'подписка', '2013-06-11 22:47:30', '670', '0', '0');
INSERT INTO actions VALUES ('173', '29', '127.0.0.1', '', 'выход', '2013-06-11 23:11:28', '0', '0', '0');
INSERT INTO actions VALUES ('174', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-11 23:12:11', '0', '0', '0');
INSERT INTO actions VALUES ('167', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'пополнение счета', '2013-06-10 23:46:24', '0', '0', '101');
INSERT INTO actions VALUES ('175', '29', '127.0.0.1', '', 'выход', '2013-06-12 03:39:58', '0', '0', '0');
INSERT INTO actions VALUES ('176', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-12 03:47:04', '0', '0', '0');
INSERT INTO actions VALUES ('177', '29', '127.0.0.1', '', 'выход', '2013-06-12 04:04:15', '0', '0', '0');
INSERT INTO actions VALUES ('178', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-12 04:05:56', '0', '0', '0');
INSERT INTO actions VALUES ('179', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-12 10:19:53', '0', '0', '0');
INSERT INTO actions VALUES ('180', '29', '127.0.0.1', '', 'выход', '2013-06-12 13:07:29', '0', '0', '0');
INSERT INTO actions VALUES ('181', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-12 13:16:33', '0', '0', '0');
INSERT INTO actions VALUES ('182', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-13 11:54:48', '0', '0', '0');
INSERT INTO actions VALUES ('183', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-16 12:57:09', '0', '0', '0');
INSERT INTO actions VALUES ('184', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-16 18:35:01', '0', '0', '0');
INSERT INTO actions VALUES ('185', '29', '127.0.0.1', '', 'выход', '2013-06-16 23:52:57', '0', '0', '0');
INSERT INTO actions VALUES ('186', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-17 00:02:45', '0', '0', '0');
INSERT INTO actions VALUES ('187', '29', '127.0.0.1', '', 'выход', '2013-06-17 00:15:35', '0', '0', '0');
INSERT INTO actions VALUES ('188', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-17 00:19:15', '0', '0', '0');
INSERT INTO actions VALUES ('189', '29', '127.0.0.1', '', 'выход', '2013-06-17 00:34:43', '0', '0', '0');
INSERT INTO actions VALUES ('190', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-17 00:35:08', '0', '0', '0');
INSERT INTO actions VALUES ('191', '29', '127.0.0.1', '', 'выход', '2013-06-17 00:54:48', '0', '0', '0');
INSERT INTO actions VALUES ('192', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-17 00:55:17', '0', '0', '0');
INSERT INTO actions VALUES ('193', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-17 10:06:31', '0', '0', '0');
INSERT INTO actions VALUES ('194', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 'вход', '2013-06-17 11:39:07', '0', '0', '0');
INSERT INTO actions VALUES ('195', '29', '127.0.0.1', '', 'выход', '2013-06-17 13:24:31', '0', '0', '0');
INSERT INTO actions VALUES ('196', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-17 13:27:14', '0', '0', '0');
INSERT INTO actions VALUES ('197', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-17 17:19:04', '0', '0', '0');
INSERT INTO actions VALUES ('198', '29', '127.0.0.1', '', 'выход', '2013-06-17 19:43:10', '0', '0', '0');
INSERT INTO actions VALUES ('199', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-17 19:48:45', '0', '0', '0');
INSERT INTO actions VALUES ('200', '29', '127.0.0.1', '', 'выход', '2013-06-18 01:56:12', '0', '0', '0');
INSERT INTO actions VALUES ('201', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-18 01:58:28', '0', '0', '0');
INSERT INTO actions VALUES ('202', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 'вход', '2013-06-18 02:14:37', '0', '0', '0');
INSERT INTO actions VALUES ('203', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 'вход', '2013-06-18 03:37:32', '0', '0', '0');
INSERT INTO actions VALUES ('204', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-18 09:09:48', '0', '0', '0');
INSERT INTO actions VALUES ('205', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 'вход', '2013-06-18 13:09:34', '0', '0', '0');
INSERT INTO actions VALUES ('206', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-18 17:58:49', '0', '0', '0');
INSERT INTO actions VALUES ('207', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-19 01:49:40', '0', '0', '0');
INSERT INTO actions VALUES ('208', '57', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-19 01:53:52', '0', '0', '0');
INSERT INTO actions VALUES ('209', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-19 02:38:52', '0', '0', '0');
INSERT INTO actions VALUES ('210', '29', '127.0.0.1', '', 'выход', '2013-06-19 02:41:37', '0', '0', '0');
INSERT INTO actions VALUES ('211', '30', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-19 02:41:54', '0', '0', '0');
INSERT INTO actions VALUES ('212', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-19 02:42:34', '0', '0', '0');
INSERT INTO actions VALUES ('213', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 'вход', '2013-06-19 13:47:56', '0', '0', '0');
INSERT INTO actions VALUES ('214', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 'вход', '2013-06-19 20:12:45', '0', '0', '0');
INSERT INTO actions VALUES ('215', '29', '127.0.0.1', '', 'выход', '2013-06-20 02:58:49', '0', '0', '0');
INSERT INTO actions VALUES ('216', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 20:03:57', '0', '0', '0');
INSERT INTO actions VALUES ('217', '29', '127.0.0.1', '', 'выход', '2013-06-20 20:04:25', '0', '0', '0');
INSERT INTO actions VALUES ('218', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 20:04:43', '0', '0', '0');
INSERT INTO actions VALUES ('219', '29', '127.0.0.1', '', 'выход', '2013-06-20 20:08:07', '0', '0', '0');
INSERT INTO actions VALUES ('220', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 20:08:15', '0', '0', '0');
INSERT INTO actions VALUES ('221', '29', '127.0.0.1', '', 'выход', '2013-06-20 20:08:58', '0', '0', '0');
INSERT INTO actions VALUES ('222', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 20:11:26', '0', '0', '0');
INSERT INTO actions VALUES ('223', '29', '127.0.0.1', '', 'выход', '2013-06-20 20:11:34', '0', '0', '0');
INSERT INTO actions VALUES ('224', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 20:11:55', '0', '0', '0');
INSERT INTO actions VALUES ('225', '29', '127.0.0.1', '', 'выход', '2013-06-20 20:11:57', '0', '0', '0');
INSERT INTO actions VALUES ('226', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 20:12:47', '0', '0', '0');
INSERT INTO actions VALUES ('227', '29', '127.0.0.1', '', 'выход', '2013-06-20 20:13:34', '0', '0', '0');
INSERT INTO actions VALUES ('228', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 20:14:07', '0', '0', '0');
INSERT INTO actions VALUES ('229', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 20:14:36', '0', '0', '0');
INSERT INTO actions VALUES ('230', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 20:14:47', '0', '0', '0');
INSERT INTO actions VALUES ('231', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 20:17:32', '0', '0', '0');
INSERT INTO actions VALUES ('232', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 20:20:11', '0', '0', '0');
INSERT INTO actions VALUES ('233', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 20:22:22', '0', '0', '0');
INSERT INTO actions VALUES ('234', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 20:23:32', '0', '0', '0');
INSERT INTO actions VALUES ('235', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 20:31:00', '0', '0', '0');
INSERT INTO actions VALUES ('236', '29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 21:06:00', '0', '0', '0');
INSERT INTO actions VALUES ('237', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 22:29:23', '0', '0', '0');
INSERT INTO actions VALUES ('238', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 22:41:26', '0', '0', '0');
INSERT INTO actions VALUES ('239', '59', '127.0.0.1', '', 'выход', '2013-06-20 22:48:52', '0', '0', '0');
INSERT INTO actions VALUES ('240', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 22:52:50', '0', '0', '0');
INSERT INTO actions VALUES ('241', '59', '127.0.0.1', '', 'выход', '2013-06-20 22:53:56', '0', '0', '0');
INSERT INTO actions VALUES ('242', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 22:57:08', '0', '0', '0');
INSERT INTO actions VALUES ('243', '59', '127.0.0.1', '', 'выход', '2013-06-20 22:57:26', '0', '0', '0');
INSERT INTO actions VALUES ('244', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 22:57:34', '0', '0', '0');
INSERT INTO actions VALUES ('245', '59', '127.0.0.1', '', 'выход', '2013-06-20 22:57:47', '0', '0', '0');
INSERT INTO actions VALUES ('246', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-20 23:57:44', '0', '0', '0');
INSERT INTO actions VALUES ('247', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-21 00:28:31', '0', '0', '0');
INSERT INTO actions VALUES ('248', '59', '127.0.0.1', '', 'выход', '2013-06-21 00:49:36', '0', '0', '0');
INSERT INTO actions VALUES ('249', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-21 01:31:43', '0', '0', '0');
INSERT INTO actions VALUES ('250', '61', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-21 02:02:07', '0', '0', '0');
INSERT INTO actions VALUES ('251', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', 'вход', '2013-06-21 02:02:58', '0', '0', '0');
INSERT INTO actions VALUES ('252', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 'вход', '2013-06-25 12:05:58', '0', '0', '0');
INSERT INTO actions VALUES ('253', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-26 01:38:15', '0', '0', '0');
INSERT INTO actions VALUES ('254', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-26 10:35:17', '0', '0', '0');
INSERT INTO actions VALUES ('255', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-26 10:35:30', '0', '0', '0');
INSERT INTO actions VALUES ('256', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 'вход', '2013-06-26 10:40:22', '0', '0', '0');
INSERT INTO actions VALUES ('257', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-26 10:58:45', '0', '0', '0');
INSERT INTO actions VALUES ('258', '59', '127.0.0.1', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0)', 'вход', '2013-06-26 11:09:28', '0', '0', '0');
INSERT INTO actions VALUES ('259', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-26 11:15:16', '0', '0', '0');
INSERT INTO actions VALUES ('260', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-26 15:35:12', '0', '0', '0');
INSERT INTO actions VALUES ('261', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 'вход', '2013-06-26 15:41:30', '0', '0', '0');
INSERT INTO actions VALUES ('262', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-26 18:30:19', '0', '0', '0');
INSERT INTO actions VALUES ('263', '59', '127.0.0.1', '', 'выход', '2013-06-26 18:36:09', '0', '0', '0');
INSERT INTO actions VALUES ('264', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-26 21:37:58', '0', '0', '0');
INSERT INTO actions VALUES ('265', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-26 21:38:11', '0', '0', '0');
INSERT INTO actions VALUES ('266', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-26 21:38:30', '0', '0', '0');
INSERT INTO actions VALUES ('267', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-26 21:39:20', '0', '0', '0');
INSERT INTO actions VALUES ('268', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-26 21:39:28', '0', '0', '0');
INSERT INTO actions VALUES ('269', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-26 21:40:25', '0', '0', '0');
INSERT INTO actions VALUES ('270', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-26 21:40:46', '0', '0', '0');
INSERT INTO actions VALUES ('271', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-26 21:56:19', '0', '0', '0');
INSERT INTO actions VALUES ('272', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-26 21:57:43', '0', '0', '0');
INSERT INTO actions VALUES ('273', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-28 12:56:04', '0', '0', '0');
INSERT INTO actions VALUES ('274', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-29 17:07:00', '0', '0', '0');
INSERT INTO actions VALUES ('275', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 'вход', '2013-06-29 20:01:31', '0', '0', '0');
INSERT INTO actions VALUES ('276', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-29 21:31:18', '0', '0', '0');
INSERT INTO actions VALUES ('277', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 'вход', '2013-06-30 12:16:55', '0', '0', '0');
INSERT INTO actions VALUES ('278', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-30 15:01:22', '0', '0', '0');
INSERT INTO actions VALUES ('279', '59', '127.0.0.1', '', 'выход', '2013-06-30 16:39:50', '0', '0', '0');
INSERT INTO actions VALUES ('280', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-30 16:40:26', '0', '0', '0');
INSERT INTO actions VALUES ('281', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 'вход', '2013-06-30 17:48:20', '0', '0', '0');
INSERT INTO actions VALUES ('282', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-06-30 18:01:55', '0', '0', '0');
INSERT INTO actions VALUES ('283', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 'вход', '2013-06-30 18:03:16', '0', '0', '0');
INSERT INTO actions VALUES ('284', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 'вход', '2013-06-30 18:18:50', '0', '0', '0');
INSERT INTO actions VALUES ('285', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0', 'вход', '2013-06-30 18:29:53', '0', '0', '0');
INSERT INTO actions VALUES ('286', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-03 11:48:58', '0', '0', '0');
INSERT INTO actions VALUES ('287', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'подписка', '2013-07-03 11:58:48', '729', '0', '0');
INSERT INTO actions VALUES ('288', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'подписка', '2013-07-03 11:59:13', '730', '0', '0');
INSERT INTO actions VALUES ('289', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-03 13:57:49', '0', '0', '0');
INSERT INTO actions VALUES ('290', '59', '127.0.0.1', '', 'выход', '2013-07-03 21:16:04', '0', '0', '0');
INSERT INTO actions VALUES ('291', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-03 22:00:21', '0', '0', '0');
INSERT INTO actions VALUES ('292', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-04 00:22:29', '0', '0', '0');
INSERT INTO actions VALUES ('293', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-04 00:36:45', '0', '0', '0');
INSERT INTO actions VALUES ('294', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-05 00:28:52', '0', '0', '0');
INSERT INTO actions VALUES ('295', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-05 00:29:19', '0', '0', '0');
INSERT INTO actions VALUES ('296', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-05 01:51:23', '0', '0', '0');
INSERT INTO actions VALUES ('297', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-05 12:01:35', '0', '0', '0');
INSERT INTO actions VALUES ('298', '59', '127.0.0.1', '', 'выход', '2013-07-05 12:32:41', '0', '0', '0');
INSERT INTO actions VALUES ('299', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-06 14:02:42', '0', '0', '0');
INSERT INTO actions VALUES ('300', '59', '127.0.0.1', '', 'выход', '2013-07-06 14:04:00', '0', '0', '0');
INSERT INTO actions VALUES ('301', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-06 14:04:07', '0', '0', '0');
INSERT INTO actions VALUES ('302', '59', '127.0.0.1', '', 'выход', '2013-07-06 14:15:17', '0', '0', '0');
INSERT INTO actions VALUES ('303', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-07 13:26:39', '0', '0', '0');
INSERT INTO actions VALUES ('304', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-08 01:53:22', '0', '0', '0');
INSERT INTO actions VALUES ('305', '59', '127.0.0.1', '', 'выход', '2013-07-08 02:04:32', '0', '0', '0');
INSERT INTO actions VALUES ('306', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-08 02:10:22', '0', '0', '0');
INSERT INTO actions VALUES ('307', '59', '127.0.0.1', '', 'выход', '2013-07-08 02:14:02', '0', '0', '0');
INSERT INTO actions VALUES ('308', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-08 02:34:24', '0', '0', '0');
INSERT INTO actions VALUES ('309', '59', '127.0.0.1', '', 'выход', '2013-07-08 02:54:16', '0', '0', '0');
INSERT INTO actions VALUES ('310', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-08 02:54:29', '0', '0', '0');
INSERT INTO actions VALUES ('311', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0', 'вход', '2013-07-08 03:54:35', '0', '0', '0');
INSERT INTO actions VALUES ('312', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-08 09:39:29', '0', '0', '0');
INSERT INTO actions VALUES ('313', '59', '127.0.0.1', '', 'выход', '2013-07-08 11:12:21', '0', '0', '0');
INSERT INTO actions VALUES ('314', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-08 11:13:40', '0', '0', '0');
INSERT INTO actions VALUES ('315', '59', '127.0.0.1', '', 'выход', '2013-07-08 11:13:46', '0', '0', '0');
INSERT INTO actions VALUES ('316', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-08 11:13:57', '0', '0', '0');
INSERT INTO actions VALUES ('317', '59', '127.0.0.1', '', 'выход', '2013-07-08 11:14:10', '0', '0', '0');
INSERT INTO actions VALUES ('318', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-08 11:15:01', '0', '0', '0');
INSERT INTO actions VALUES ('319', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-09 04:13:58', '0', '0', '0');
INSERT INTO actions VALUES ('320', '59', '127.0.0.1', '', 'выход', '2013-07-09 04:33:33', '0', '0', '0');
INSERT INTO actions VALUES ('321', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-09 04:33:49', '0', '0', '0');
INSERT INTO actions VALUES ('322', '59', '127.0.0.1', '', 'выход', '2013-07-09 04:36:17', '0', '0', '0');
INSERT INTO actions VALUES ('323', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-09 04:36:26', '0', '0', '0');
INSERT INTO actions VALUES ('324', '59', '127.0.0.1', '', 'выход', '2013-07-09 05:04:43', '0', '0', '0');
INSERT INTO actions VALUES ('325', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-09 05:05:27', '0', '0', '0');
INSERT INTO actions VALUES ('326', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'подписка', '2013-07-09 05:28:36', '731', '0', '0');
INSERT INTO actions VALUES ('327', '59', '127.0.0.1', '', 'выход', '2013-07-09 06:00:58', '0', '0', '0');
INSERT INTO actions VALUES ('328', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-09 06:01:08', '0', '0', '0');
INSERT INTO actions VALUES ('329', '59', '127.0.0.1', '', 'выход', '2013-07-09 06:17:19', '0', '0', '0');
INSERT INTO actions VALUES ('330', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-09 06:17:36', '0', '0', '0');
INSERT INTO actions VALUES ('331', '59', '127.0.0.1', '', 'выход', '2013-07-09 14:47:39', '0', '0', '0');
INSERT INTO actions VALUES ('332', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-09 14:48:10', '0', '0', '0');
INSERT INTO actions VALUES ('333', '59', '127.0.0.1', '', 'выход', '2013-07-09 14:48:45', '0', '0', '0');
INSERT INTO actions VALUES ('334', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-09 14:49:03', '0', '0', '0');
INSERT INTO actions VALUES ('335', '59', '127.0.0.1', '', 'выход', '2013-07-09 14:52:18', '0', '0', '0');
INSERT INTO actions VALUES ('336', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-09 14:52:45', '0', '0', '0');
INSERT INTO actions VALUES ('337', '59', '127.0.0.1', '', 'выход', '2013-07-09 14:56:35', '0', '0', '0');
INSERT INTO actions VALUES ('338', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-09 14:57:21', '0', '0', '0');
INSERT INTO actions VALUES ('339', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-09 15:16:21', '0', '0', '0');
INSERT INTO actions VALUES ('340', '59', '127.0.0.1', '', 'выход', '2013-07-09 15:17:45', '0', '0', '0');
INSERT INTO actions VALUES ('341', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-09 15:31:08', '0', '0', '0');
INSERT INTO actions VALUES ('342', '59', '127.0.0.1', '', 'выход', '2013-07-09 15:56:58', '0', '0', '0');
INSERT INTO actions VALUES ('343', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-09 15:57:10', '0', '0', '0');
INSERT INTO actions VALUES ('344', '59', '127.0.0.1', '', 'выход', '2013-07-09 15:57:16', '0', '0', '0');
INSERT INTO actions VALUES ('345', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-09 15:58:03', '0', '0', '0');
INSERT INTO actions VALUES ('346', '59', '127.0.0.1', '', 'выход', '2013-07-09 15:58:13', '0', '0', '0');
INSERT INTO actions VALUES ('347', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0', 'вход', '2013-07-09 17:26:19', '0', '0', '0');
INSERT INTO actions VALUES ('348', '59', '127.0.0.1', '', 'выход', '2013-07-09 18:43:52', '0', '0', '0');
INSERT INTO actions VALUES ('349', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0', 'вход', '2013-07-09 18:49:05', '0', '0', '0');
INSERT INTO actions VALUES ('350', '59', '127.0.0.1', '', 'выход', '2013-07-09 18:54:37', '0', '0', '0');
INSERT INTO actions VALUES ('351', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-09 19:03:01', '0', '0', '0');
INSERT INTO actions VALUES ('352', '59', '127.0.0.1', '', 'выход', '2013-07-09 19:31:30', '0', '0', '0');
INSERT INTO actions VALUES ('353', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-09 19:32:33', '0', '0', '0');
INSERT INTO actions VALUES ('354', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0', 'вход', '2013-07-11 10:41:57', '0', '0', '0');
INSERT INTO actions VALUES ('355', '59', '127.0.0.1', '', 'выход', '2013-07-11 10:48:10', '0', '0', '0');
INSERT INTO actions VALUES ('356', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0', 'вход', '2013-07-11 10:48:43', '0', '0', '0');
INSERT INTO actions VALUES ('357', '59', '127.0.0.1', '', 'выход', '2013-07-11 10:49:12', '0', '0', '0');
INSERT INTO actions VALUES ('358', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0', 'вход', '2013-07-11 10:49:24', '0', '0', '0');
INSERT INTO actions VALUES ('359', '59', '127.0.0.1', '', 'выход', '2013-07-11 10:51:28', '0', '0', '0');
INSERT INTO actions VALUES ('360', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0', 'вход', '2013-07-11 10:51:44', '0', '0', '0');
INSERT INTO actions VALUES ('361', '59', '127.0.0.1', '', 'выход', '2013-07-11 12:08:46', '0', '0', '0');
INSERT INTO actions VALUES ('362', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0', 'вход', '2013-07-11 12:08:56', '0', '0', '0');
INSERT INTO actions VALUES ('363', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-11 13:05:31', '0', '0', '0');
INSERT INTO actions VALUES ('364', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'пополнение счета', '2013-07-11 14:03:56', '0', '0', '105');
INSERT INTO actions VALUES ('365', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'пополнение счета', '2013-07-11 14:04:50', '0', '0', '104');
INSERT INTO actions VALUES ('366', '59', '127.0.0.1', '', 'выход', '2013-07-11 21:34:28', '0', '0', '0');
INSERT INTO actions VALUES ('367', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-11 21:36:16', '0', '0', '0');
INSERT INTO actions VALUES ('368', '59', '127.0.0.1', '', 'выход', '2013-07-11 22:14:39', '0', '0', '0');
INSERT INTO actions VALUES ('369', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-11 22:17:17', '0', '0', '0');
INSERT INTO actions VALUES ('370', '59', '127.0.0.1', '', 'выход', '2013-07-11 22:29:26', '0', '0', '0');
INSERT INTO actions VALUES ('371', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-11 22:29:48', '0', '0', '0');
INSERT INTO actions VALUES ('372', '59', '127.0.0.1', '', 'выход', '2013-07-11 22:48:23', '0', '0', '0');
INSERT INTO actions VALUES ('373', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-11 22:48:36', '0', '0', '0');
INSERT INTO actions VALUES ('374', '59', '127.0.0.1', '', 'выход', '2013-07-12 00:07:49', '0', '0', '0');
INSERT INTO actions VALUES ('375', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-12 00:08:23', '0', '0', '0');
INSERT INTO actions VALUES ('376', '59', '127.0.0.1', '', 'выход', '2013-07-12 00:12:33', '0', '0', '0');
INSERT INTO actions VALUES ('377', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-12 00:13:43', '0', '0', '0');
INSERT INTO actions VALUES ('378', '59', '127.0.0.1', '', 'выход', '2013-07-12 00:18:30', '0', '0', '0');
INSERT INTO actions VALUES ('379', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-12 00:19:21', '0', '0', '0');
INSERT INTO actions VALUES ('380', '59', '127.0.0.1', '', 'выход', '2013-07-12 00:21:19', '0', '0', '0');
INSERT INTO actions VALUES ('381', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-12 00:22:23', '0', '0', '0');
INSERT INTO actions VALUES ('382', '59', '127.0.0.1', '', 'выход', '2013-07-12 00:22:35', '0', '0', '0');
INSERT INTO actions VALUES ('383', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-12 00:22:47', '0', '0', '0');
INSERT INTO actions VALUES ('384', '59', '127.0.0.1', '', 'выход', '2013-07-12 00:26:09', '0', '0', '0');
INSERT INTO actions VALUES ('385', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-12 00:26:27', '0', '0', '0');
INSERT INTO actions VALUES ('386', '59', '127.0.0.1', '', 'выход', '2013-07-12 00:27:12', '0', '0', '0');
INSERT INTO actions VALUES ('387', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-12 00:27:26', '0', '0', '0');
INSERT INTO actions VALUES ('388', '59', '127.0.0.1', '', 'выход', '2013-07-12 00:32:49', '0', '0', '0');
INSERT INTO actions VALUES ('389', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-12 00:32:59', '0', '0', '0');
INSERT INTO actions VALUES ('390', '59', '127.0.0.1', '', 'выход', '2013-07-12 00:34:19', '0', '0', '0');
INSERT INTO actions VALUES ('391', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.116 Safari/537.36', 'вход', '2013-07-12 00:34:30', '0', '0', '0');
INSERT INTO actions VALUES ('392', '59', '127.0.0.1', '', 'выход', '2013-07-12 02:56:19', '0', '0', '0');
INSERT INTO actions VALUES ('393', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-13 23:50:39', '0', '0', '0');
INSERT INTO actions VALUES ('394', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-19 20:20:45', '0', '0', '0');
INSERT INTO actions VALUES ('395', '59', '127.0.0.1', '', 'выход', '2013-07-19 20:45:50', '0', '0', '0');
INSERT INTO actions VALUES ('396', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-19 20:48:33', '0', '0', '0');
INSERT INTO actions VALUES ('397', '59', '127.0.0.1', '', 'выход', '2013-07-19 21:31:47', '0', '0', '0');
INSERT INTO actions VALUES ('398', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-19 21:32:57', '0', '0', '0');
INSERT INTO actions VALUES ('399', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-20 13:15:24', '0', '0', '0');
INSERT INTO actions VALUES ('400', '59', '127.0.0.1', '', 'выход', '2013-07-20 14:02:58', '0', '0', '0');
INSERT INTO actions VALUES ('401', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-20 15:05:51', '0', '0', '0');
INSERT INTO actions VALUES ('402', '59', '127.0.0.1', '', 'выход', '2013-07-20 15:12:17', '0', '0', '0');
INSERT INTO actions VALUES ('403', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-20 15:15:32', '0', '0', '0');
INSERT INTO actions VALUES ('404', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-20 15:16:13', '0', '0', '0');
INSERT INTO actions VALUES ('405', '59', '127.0.0.1', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Win64; x64; .NET CLR 2.0.50727; SLCC2; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C; Media Center PC 6.0; InfoPath.3; Tablet PC 2.0; .NET4.0E)', 'вход', '2013-07-20 16:09:57', '0', '0', '0');
INSERT INTO actions VALUES ('406', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-22 15:56:54', '0', '0', '0');
INSERT INTO actions VALUES ('407', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-23 15:30:40', '0', '0', '0');
INSERT INTO actions VALUES ('408', '59', '127.0.0.1', '', 'выход', '2013-07-23 16:19:01', '0', '0', '0');
INSERT INTO actions VALUES ('409', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-23 16:19:14', '0', '0', '0');
INSERT INTO actions VALUES ('410', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0', 'вход', '2013-07-23 16:26:54', '0', '0', '0');
INSERT INTO actions VALUES ('411', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:22.0) Gecko/20100101 Firefox/22.0', 'вход', '2013-07-23 16:33:01', '0', '0', '0');
INSERT INTO actions VALUES ('412', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-23 17:30:45', '0', '0', '0');
INSERT INTO actions VALUES ('413', '59', '127.0.0.1', '', 'выход', '2013-07-23 20:39:44', '0', '0', '0');
INSERT INTO actions VALUES ('414', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-24 11:28:15', '0', '0', '0');
INSERT INTO actions VALUES ('415', '59', '127.0.0.1', '', 'выход', '2013-07-24 11:37:36', '0', '0', '0');
INSERT INTO actions VALUES ('416', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-24 11:39:01', '0', '0', '0');
INSERT INTO actions VALUES ('417', '59', '127.0.0.1', '', 'выход', '2013-07-24 11:39:23', '0', '0', '0');
INSERT INTO actions VALUES ('418', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-24 11:39:39', '0', '0', '0');
INSERT INTO actions VALUES ('419', '59', '127.0.0.1', '', 'выход', '2013-07-24 11:43:54', '0', '0', '0');
INSERT INTO actions VALUES ('420', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-24 12:18:52', '0', '0', '0');
INSERT INTO actions VALUES ('421', '59', '127.0.0.1', '', 'выход', '2013-07-24 12:19:17', '0', '0', '0');
INSERT INTO actions VALUES ('422', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-24 13:36:30', '0', '0', '0');
INSERT INTO actions VALUES ('423', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-24 18:44:23', '0', '0', '0');
INSERT INTO actions VALUES ('424', '59', '127.0.0.1', '', 'выход', '2013-07-24 20:53:44', '0', '0', '0');
INSERT INTO actions VALUES ('425', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-24 23:15:51', '0', '0', '0');
INSERT INTO actions VALUES ('426', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-28 19:35:58', '0', '0', '0');
INSERT INTO actions VALUES ('427', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-29 10:35:14', '0', '0', '0');
INSERT INTO actions VALUES ('428', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-07-30 22:50:58', '0', '0', '0');
INSERT INTO actions VALUES ('429', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36', 'вход', '2013-08-01 00:16:57', '0', '0', '0');
INSERT INTO actions VALUES ('430', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 'вход', '2013-08-06 22:47:29', '0', '0', '0');
INSERT INTO actions VALUES ('431', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 'вход', '2013-08-08 13:58:25', '0', '0', '0');
INSERT INTO actions VALUES ('432', '59', '127.0.0.1', '', 'выход', '2013-08-08 14:45:02', '0', '0', '0');
INSERT INTO actions VALUES ('433', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 'вход', '2013-08-08 14:49:12', '0', '0', '0');
INSERT INTO actions VALUES ('434', '59', '127.0.0.1', '', 'выход', '2013-08-08 15:49:06', '0', '0', '0');
INSERT INTO actions VALUES ('435', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 'вход', '2013-08-08 16:32:31', '0', '0', '0');
INSERT INTO actions VALUES ('436', '59', '127.0.0.1', '', 'выход', '2013-08-08 22:52:29', '0', '0', '0');
INSERT INTO actions VALUES ('437', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 'вход', '2013-08-09 00:28:37', '0', '0', '0');
INSERT INTO actions VALUES ('438', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 'вход', '2013-08-09 09:37:09', '0', '0', '0');
INSERT INTO actions VALUES ('439', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0', 'вход', '2013-08-09 10:55:23', '0', '0', '0');
INSERT INTO actions VALUES ('440', '59', '127.0.0.1', '', 'выход', '2013-08-09 11:51:33', '0', '0', '0');
INSERT INTO actions VALUES ('441', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 'вход', '2013-08-09 11:52:07', '0', '0', '0');
INSERT INTO actions VALUES ('442', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 'вход', '2013-08-09 12:02:32', '0', '0', '0');
INSERT INTO actions VALUES ('443', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0', 'вход', '2013-08-09 12:08:29', '0', '0', '0');
INSERT INTO actions VALUES ('444', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 'вход', '2013-08-09 18:06:23', '0', '0', '0');
INSERT INTO actions VALUES ('445', '59', '127.0.0.1', '', 'выход', '2013-08-09 18:37:21', '0', '0', '0');
INSERT INTO actions VALUES ('446', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 'вход', '2013-08-09 18:37:28', '0', '0', '0');
INSERT INTO actions VALUES ('447', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 'вход', '2013-08-09 18:54:33', '0', '0', '0');
INSERT INTO actions VALUES ('448', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0', 'вход', '2013-08-09 19:24:45', '0', '0', '0');
INSERT INTO actions VALUES ('449', '59', '127.0.0.1', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0)', 'вход', '2013-08-09 23:54:12', '0', '0', '0');
INSERT INTO actions VALUES ('450', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 'вход', '2013-08-10 08:52:06', '0', '0', '0');
INSERT INTO actions VALUES ('451', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0', 'вход', '2013-08-10 09:07:50', '0', '0', '0');
INSERT INTO actions VALUES ('452', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 'вход', '2013-08-10 15:56:07', '0', '0', '0');
INSERT INTO actions VALUES ('453', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0', 'вход', '2013-08-10 15:56:58', '0', '0', '0');
INSERT INTO actions VALUES ('454', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 'вход', '2013-08-11 10:43:55', '0', '0', '0');
INSERT INTO actions VALUES ('455', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0', 'вход', '2013-08-13 10:20:48', '0', '0', '0');
INSERT INTO actions VALUES ('456', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 'вход', '2013-08-13 10:21:11', '0', '0', '0');
INSERT INTO actions VALUES ('457', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 'вход', '2013-08-15 18:35:09', '0', '0', '0');
INSERT INTO actions VALUES ('458', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36', 'вход', '2013-08-20 11:28:22', '0', '0', '0');
INSERT INTO actions VALUES ('459', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.57 Safari/537.36', 'вход', '2013-08-25 18:45:08', '0', '0', '0');
INSERT INTO actions VALUES ('460', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.57 Safari/537.36', 'вход', '2013-08-27 03:48:02', '0', '0', '0');
INSERT INTO actions VALUES ('461', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-04 19:46:33', '0', '0', '0');
INSERT INTO actions VALUES ('462', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-05 11:11:38', '0', '0', '0');
INSERT INTO actions VALUES ('463', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-06 02:27:21', '0', '0', '0');
INSERT INTO actions VALUES ('464', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-06 10:37:32', '0', '0', '0');
INSERT INTO actions VALUES ('465', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-08 19:51:05', '0', '0', '0');
INSERT INTO actions VALUES ('466', '59', '127.0.0.1', '', 'выход', '2013-09-08 19:58:10', '0', '0', '0');
INSERT INTO actions VALUES ('467', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-08 19:58:55', '0', '0', '0');
INSERT INTO actions VALUES ('468', '59', '127.0.0.1', '', 'выход', '2013-09-09 00:46:04', '0', '0', '0');
INSERT INTO actions VALUES ('469', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-09 12:17:57', '0', '0', '0');
INSERT INTO actions VALUES ('470', '59', '127.0.0.1', '', 'выход', '2013-09-09 16:01:08', '0', '0', '0');
INSERT INTO actions VALUES ('471', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-09 23:45:09', '0', '0', '0');
INSERT INTO actions VALUES ('472', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-10 13:26:33', '0', '0', '0');
INSERT INTO actions VALUES ('473', '59', '127.0.0.1', '', 'выход', '2013-09-10 17:00:34', '0', '0', '0');
INSERT INTO actions VALUES ('474', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-10 17:00:48', '0', '0', '0');
INSERT INTO actions VALUES ('475', '59', '127.0.0.1', '', 'выход', '2013-09-10 17:24:46', '0', '0', '0');
INSERT INTO actions VALUES ('476', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-10 19:31:01', '0', '0', '0');
INSERT INTO actions VALUES ('477', '59', '127.0.0.1', '', 'выход', '2013-09-10 20:14:56', '0', '0', '0');
INSERT INTO actions VALUES ('478', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-10 20:27:18', '0', '0', '0');
INSERT INTO actions VALUES ('479', '59', '127.0.0.1', '', 'выход', '2013-09-10 21:30:09', '0', '0', '0');
INSERT INTO actions VALUES ('480', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-10 21:32:12', '0', '0', '0');
INSERT INTO actions VALUES ('481', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-11 19:11:20', '0', '0', '0');
INSERT INTO actions VALUES ('482', '59', '127.0.0.1', '', 'выход', '2013-09-12 02:07:49', '0', '0', '0');
INSERT INTO actions VALUES ('483', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-12 23:56:26', '0', '0', '0');
INSERT INTO actions VALUES ('484', '59', '127.0.0.1', '', 'выход', '2013-09-12 23:56:59', '0', '0', '0');
INSERT INTO actions VALUES ('485', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-13 01:51:50', '0', '0', '0');
INSERT INTO actions VALUES ('486', '59', '127.0.0.1', '', 'выход', '2013-09-13 01:52:02', '0', '0', '0');
INSERT INTO actions VALUES ('487', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-14 12:30:21', '0', '0', '0');
INSERT INTO actions VALUES ('488', '59', '127.0.0.1', '', 'выход', '2013-09-14 12:55:12', '0', '0', '0');
INSERT INTO actions VALUES ('489', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-14 12:55:35', '0', '0', '0');
INSERT INTO actions VALUES ('490', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0', 'вход', '2013-09-14 12:56:31', '0', '0', '0');
INSERT INTO actions VALUES ('491', '59', '127.0.0.1', '', 'выход', '2013-09-14 13:00:31', '0', '0', '0');
INSERT INTO actions VALUES ('492', '59', '127.0.0.1', '', 'выход', '2013-09-14 13:03:46', '0', '0', '0');
INSERT INTO actions VALUES ('493', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-14 14:10:51', '0', '0', '0');
INSERT INTO actions VALUES ('494', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0', 'вход', '2013-09-14 18:21:18', '0', '0', '0');
INSERT INTO actions VALUES ('495', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-14 18:34:49', '0', '0', '0');
INSERT INTO actions VALUES ('496', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0', 'вход', '2013-09-14 18:35:15', '0', '0', '0');
INSERT INTO actions VALUES ('497', '59', '127.0.0.1', '', 'выход', '2013-09-14 18:55:41', '0', '0', '0');
INSERT INTO actions VALUES ('498', '59', '127.0.0.1', '', 'выход', '2013-09-14 18:57:36', '0', '0', '0');
INSERT INTO actions VALUES ('499', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-14 19:00:28', '0', '0', '0');
INSERT INTO actions VALUES ('500', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0', 'вход', '2013-09-14 19:00:55', '0', '0', '0');
INSERT INTO actions VALUES ('501', '59', '127.0.0.1', '', 'выход', '2013-09-14 19:03:49', '0', '0', '0');
INSERT INTO actions VALUES ('502', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0', 'вход', '2013-09-14 20:34:37', '0', '0', '0');
INSERT INTO actions VALUES ('503', '59', '127.0.0.1', '', 'выход', '2013-09-14 20:35:02', '0', '0', '0');
INSERT INTO actions VALUES ('504', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0', 'вход', '2013-09-14 20:52:52', '0', '0', '0');
INSERT INTO actions VALUES ('505', '59', '127.0.0.1', '', 'выход', '2013-09-14 20:54:22', '0', '0', '0');
INSERT INTO actions VALUES ('506', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0', 'вход', '2013-09-14 21:20:10', '0', '0', '0');
INSERT INTO actions VALUES ('507', '59', '127.0.0.1', '', 'выход', '2013-09-14 21:20:23', '0', '0', '0');
INSERT INTO actions VALUES ('508', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0', 'вход', '2013-09-14 22:09:36', '0', '0', '0');
INSERT INTO actions VALUES ('509', '59', '127.0.0.1', '', 'выход', '2013-09-14 22:09:41', '0', '0', '0');
INSERT INTO actions VALUES ('510', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0', 'вход', '2013-09-14 22:10:40', '0', '0', '0');
INSERT INTO actions VALUES ('511', '59', '127.0.0.1', '', 'выход', '2013-09-14 22:10:43', '0', '0', '0');
INSERT INTO actions VALUES ('512', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0', 'вход', '2013-09-14 22:18:50', '0', '0', '0');
INSERT INTO actions VALUES ('513', '59', '127.0.0.1', '', 'выход', '2013-09-14 22:18:53', '0', '0', '0');
INSERT INTO actions VALUES ('514', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0', 'вход', '2013-09-14 23:21:10', '0', '0', '0');
INSERT INTO actions VALUES ('515', '59', '127.0.0.1', '', 'выход', '2013-09-14 23:24:58', '0', '0', '0');
INSERT INTO actions VALUES ('516', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-15 13:07:29', '0', '0', '0');
INSERT INTO actions VALUES ('517', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-15 13:32:20', '0', '0', '0');
INSERT INTO actions VALUES ('518', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-15 16:28:09', '0', '0', '0');
INSERT INTO actions VALUES ('519', '59', '127.0.0.1', '', 'выход', '2013-09-15 22:46:01', '0', '0', '0');
INSERT INTO actions VALUES ('520', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-16 00:54:35', '0', '0', '0');
INSERT INTO actions VALUES ('521', '59', '127.0.0.1', '', 'выход', '2013-09-16 03:34:51', '0', '0', '0');
INSERT INTO actions VALUES ('522', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-16 03:37:52', '0', '0', '0');
INSERT INTO actions VALUES ('523', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-16 09:53:11', '0', '0', '0');
INSERT INTO actions VALUES ('524', '59', '127.0.0.1', '', 'выход', '2013-09-16 11:38:05', '0', '0', '0');
INSERT INTO actions VALUES ('525', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-16 11:45:44', '0', '0', '0');
INSERT INTO actions VALUES ('526', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0', 'вход', '2013-09-16 16:29:26', '0', '0', '0');
INSERT INTO actions VALUES ('527', '59', '127.0.0.1', '', 'выход', '2013-09-16 16:29:44', '0', '0', '0');
INSERT INTO actions VALUES ('528', '59', '127.0.0.1', '', 'выход', '2013-09-16 16:30:47', '0', '0', '0');
INSERT INTO actions VALUES ('529', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-17 11:56:17', '0', '0', '0');
INSERT INTO actions VALUES ('530', '59', '127.0.0.1', '', 'выход', '2013-09-17 16:55:31', '0', '0', '0');
INSERT INTO actions VALUES ('531', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36', 'вход', '2013-09-19 18:43:02', '0', '0', '0');
INSERT INTO actions VALUES ('532', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.76 Safari/537.36', 'вход', '2013-09-24 16:10:17', '0', '0', '0');
INSERT INTO actions VALUES ('533', '59', '127.0.0.1', '', 'выход', '2013-09-24 20:16:54', '0', '0', '0');
INSERT INTO actions VALUES ('534', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.76 Safari/537.36', 'вход', '2013-09-27 14:13:56', '0', '0', '0');
INSERT INTO actions VALUES ('535', '59', '127.0.0.1', '', 'выход', '2013-09-27 15:08:09', '0', '0', '0');
INSERT INTO actions VALUES ('536', '0', '127.0.0.1', '', 'выход', '2013-09-27 15:08:13', '0', '0', '0');
INSERT INTO actions VALUES ('537', '0', '127.0.0.1', '', 'выход', '2013-09-27 15:08:15', '0', '0', '0');
INSERT INTO actions VALUES ('538', '0', '127.0.0.1', '', 'выход', '2013-09-27 15:08:17', '0', '0', '0');
INSERT INTO actions VALUES ('539', '0', '127.0.0.1', '', 'выход', '2013-09-27 15:08:19', '0', '0', '0');
INSERT INTO actions VALUES ('540', '0', '127.0.0.1', '', 'выход', '2013-09-27 15:08:22', '0', '0', '0');
INSERT INTO actions VALUES ('541', '0', '127.0.0.1', '', 'выход', '2013-09-27 15:08:26', '0', '0', '0');
INSERT INTO actions VALUES ('542', '0', '127.0.0.1', '', 'выход', '2013-09-27 15:08:28', '0', '0', '0');
INSERT INTO actions VALUES ('543', '0', '127.0.0.1', '', 'выход', '2013-09-27 15:09:30', '0', '0', '0');
INSERT INTO actions VALUES ('544', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.76 Safari/537.36', 'вход', '2013-09-27 17:14:50', '0', '0', '0');
INSERT INTO actions VALUES ('545', '59', '127.0.0.1', '', 'выход', '2013-09-27 18:54:45', '0', '0', '0');
INSERT INTO actions VALUES ('546', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.76 Safari/537.36', 'вход', '2013-09-27 20:20:35', '0', '0', '0');
INSERT INTO actions VALUES ('547', '59', '127.0.0.1', '', 'выход', '2013-09-27 20:33:33', '0', '0', '0');
INSERT INTO actions VALUES ('548', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.76 Safari/537.36', 'вход', '2013-09-27 20:46:09', '0', '0', '0');
INSERT INTO actions VALUES ('549', '59', '127.0.0.1', '', 'выход', '2013-09-27 20:46:36', '0', '0', '0');
INSERT INTO actions VALUES ('550', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.69 Safari/537.36', 'вход', '2013-10-06 19:38:20', '0', '0', '0');
INSERT INTO actions VALUES ('551', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.69 Safari/537.36', 'вход', '2013-10-08 01:19:10', '0', '0', '0');
INSERT INTO actions VALUES ('552', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.69 Safari/537.36', 'вход', '2013-10-08 20:15:53', '0', '0', '0');
INSERT INTO actions VALUES ('553', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.69 Safari/537.36', 'вход', '2013-10-09 20:36:37', '0', '0', '0');
INSERT INTO actions VALUES ('554', '59', '127.0.0.1', '', 'выход', '2013-10-09 20:40:43', '0', '0', '0');
INSERT INTO actions VALUES ('555', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.69 Safari/537.36', 'вход', '2013-10-10 01:36:00', '0', '0', '0');
INSERT INTO actions VALUES ('556', '59', '127.0.0.1', '', 'выход', '2013-10-10 02:01:48', '0', '0', '0');
INSERT INTO actions VALUES ('557', '59', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.69 Safari/537.36', 'вход', '2013-10-10 13:45:17', '0', '0', '0');
INSERT INTO actions VALUES ('558', '59', '127.0.0.1', '', 'выход', '2013-10-10 15:10:38', '0', '0', '0');


#
# Table structure for table `albums`
#

DROP TABLE IF EXISTS `albums`;
CREATE TABLE `albums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_category` int(11) NOT NULL DEFAULT '1' COMMENT 'К какой категории относится',
  `on_off` enum('on','off') NOT NULL DEFAULT 'off' COMMENT 'включить показ  альбома',
  `event` enum('on','off') NOT NULL DEFAULT 'off' COMMENT 'Событие заливки альбома на сайт (включить показ фотографий в альбоме)',
  `nm` varchar(64) NOT NULL DEFAULT '' COMMENT 'Имя альбома',
  `img` varchar(64) NOT NULL DEFAULT '' COMMENT 'Картинка заголовка альбома',
  `order_field` int(11) NOT NULL DEFAULT '0' COMMENT 'Порядковый номер  альбома ',
  `descr` varchar(512) NOT NULL COMMENT 'Текст слева под альбомом',
  `price` float(8,2) NOT NULL DEFAULT '10.00' COMMENT 'Цена файла фотографии',
  `pass` varchar(64) NOT NULL DEFAULT '' COMMENT 'Пароль на альбом',
  `ftp_folder` varchar(64) NOT NULL DEFAULT '/fotoarhiv/' COMMENT 'Папка альбома на FTP',
  `quality` int(11) NOT NULL DEFAULT '80' COMMENT 'Качество jpg',
  `foto_folder` varchar(64) NOT NULL DEFAULT '/images2/' COMMENT 'Рабочая папка на сервере',
  `watermark` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Водяной знак',
  `ip_marker` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Ip защита',
  `sharping` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Резкость',
  `vote_price` float(8,2) NOT NULL DEFAULT '0.01' COMMENT 'Цена голосования',
  `vote_time` int(10) NOT NULL DEFAULT '60' COMMENT 'время между голосованием',
  `vote_time_on` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'включить временное голосование',
  `pecat_A4` float(8,2) NOT NULL DEFAULT '30.00' COMMENT 'Цена A4',
  `pecat` float(8,2) NOT NULL DEFAULT '2.00' COMMENT 'Цена 13x18 и 9x12',
  PRIMARY KEY (`id`),
  KEY `ind1` (`id_category`)
) ENGINE=MyISAM AUTO_INCREMENT=740 DEFAULT CHARSET=cp1251;

#
# Dumping data for table `albums`
#

INSERT INTO albums VALUES ('734', '1', 'on', 'on', 'new', 'id734.jpg', '734', '', '10.00', '', '/fotoarhiv/svadba/02/', '80', '/images2/', '1', '1', '1', '0.01', '60', '0', '30.00', '12.00');
INSERT INTO albums VALUES ('737', '1', 'on', 'on', '3333', 'id737.jpg', '737', '', '10.00', '', '/fotoarhiv/svadba/01/', '80', '/images2/', '1', '1', '1', '0.01', '60', '1', '30.00', '2.00');
INSERT INTO albums VALUES ('730', '1', 'off', 'off', 'Проба длинно имя2', 'id730.jpg', '730', 'пропро', '8.00', '', '/fotoarhiv/', '80', '/images2/', '1', '1', '0', '0.01', '60', '1', '40.00', '12.00');
INSERT INTO albums VALUES ('729', '1', 'off', 'off', 'Тест', 'id729.jpg', '729', '', '8.00', '', '/fotoarhiv/', '80', '/images2/', '1', '1', '0', '0.01', '60', '1', '40.00', '12.00');
INSERT INTO albums VALUES ('731', '1', '', '', '999999', 'id731.jpg', '731', 'всываы', '8.00', '', '/fotoarhiv/', '80', '/images2/', '1', '1', '0', '0.01', '60', '1', '40.00', '12.00');
INSERT INTO albums VALUES ('733', '1', 'on', 'on', 'test', 'id733.jpg', '733', '', '10.00', '1', '/fotoarhiv/shkola/Vipuski 2003-2012/', '80', '/images2/', '1', '1', '0', '0.01', '60', '1', '30.00', '2.00');
INSERT INTO albums VALUES ('738', '1', 'off', 'off', '', '', '0', '', '10.00', '', '/fotoarhiv/', '80', '/images2/', '1', '1', '0', '0.01', '60', '1', '30.00', '2.00');


#
# Table structure for table `categories`
#

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_num` int(11) NOT NULL DEFAULT '0',
  `nm` varchar(64) NOT NULL,
  `txt` text NOT NULL,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `txt` (`txt`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=cp1251;

#
# Dumping data for table `categories`
#

INSERT INTO categories VALUES ('7', '7', 'Художественная гимнастика', '');
INSERT INTO categories VALUES ('2', '2', 'Юбилеи', '');
INSERT INTO categories VALUES ('4', '4', 'Школы', '');
INSERT INTO categories VALUES ('5', '5', 'Детсад №135', '');
INSERT INTO categories VALUES ('6', '6', 'Детсад №224', '');
INSERT INTO categories VALUES ('3', '3', 'Дети', '');
INSERT INTO categories VALUES ('1', '1', 'Свадьбы', '');


#
# Table structure for table `config`
#

DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admnick` varchar(50) NOT NULL COMMENT 'логин',
  `admpass` varchar(50) NOT NULL COMMENT 'пароль',
  `nop` int(2) DEFAULT '5',
  `common` int(1) DEFAULT '1' COMMENT '0 - запрет коментариев',
  `cop` int(2) DEFAULT '7',
  `captcha` int(1) DEFAULT '1' COMMENT 'сапча',
  `kolsm` int(3) DEFAULT '30',
  `anrek` int(1) DEFAULT '1',
  `kommdl` int(3) DEFAULT '70',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# Dumping data for table `config`
#

INSERT INTO config VALUES ('1', 'AleksJurii_019', 'b91372783f8b994248033efc9d9ca265', '5', '1', '7', '1', '30', '1', '70');


#
# Table structure for table `content`
#

DROP TABLE IF EXISTS `content`;
CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `txt` text NOT NULL COMMENT 'Содержание',
  `namecont` varchar(32) NOT NULL COMMENT 'Заголовок контента страниц',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=cp1251;

#
# Dumping data for table `content`
#

INSERT INTO content VALUES ('1', '<div class=\"header\">
<h1 align=\"center\">Баннер</h1>
<div id=\"myCarousel\" class=\"carousel slide\"><!-- Carousel items -->
<div class=\"carousel-inner\">
<div class=\"active item\">…</div>
<div class=\"item\">…</div>
<div class=\"item\">…</div>
</div>
<!-- Carousel nav --><a class=\"carousel-control left\" href=\"#myCarousel\" data-slide=\"prev\">‹</a> <a class=\"carousel-control right\" href=\"#myCarousel\" data-slide=\"next\">›</a></div>
</div>



<!--Левая колонка-->
<div class=\"l_colonka\">
<div class=\"small_menu\"><!--<div class =\"small_head\"><p class =\"toptext_00\">Меню:</p></div>--><!--Меню слева-->
<div class=\"drop-shadow lifted\" style=\"margin-left: 0; margin-right: 0; padding-left: 0; padding-right: 0; width: 225px;\"><dl id=\"menu\"><dt><a href=\"../js/dynamic-to-top/\"><strong>Видео</strong> </a></dt><dt><a href=\"../inc/captcha/index.php\"><strong>Фото</strong> </a></dt><dt><a href=\"../index.php\"><strong>Фотокниги</strong> </a></dt><dt><a href=\"../index.php\"><strong>Слайд шоу</strong> </a></dt><dt><a href=\"../index.php\"><strong>Коллажи</strong> </a></dt><dt><a href=\"../videoarhiv\"><strong>Прайс-лист по фотосъемке</strong> </a></dt><dt><a href=\"../prays-list_po_videosem\"><strong>Love Story</strong> </a></dt><dt><a href=\"../love_story\"><strong>Прайс-лист по видеосъемке</strong> </a></dt><dt><a href=\"../video_love_story\"><strong>Видео Love Story</strong> </a></dt><dt><a href=\"../fk/demo.php\"><strong>Гид по фотобанку </strong> </a></dt><dt><a href=\"http://ktonanovenkogo.ru/wp-content/uploads/style.html\"><strong>Видеоуроки</strong> </a></dt></dl></div>
</div>
<div style=\"clear: both;\"> </div>
<div class=\"contact\">
<div class=\"small_head\">
<p class=\"toptext_00\">Контакты:</p>
</div>
<p class=\"text_contact\" style=\"margin-top: 15px;\">Видеооператор</p>
<p class=\"text_contact\" style=\"margin-top: -10px;\">тел. 094-94-77-070</p>
<p class=\"text_contact\"><object style=\"margin-top: -10px; margin-bottom: -10px;\" width=\"115\" height=\"50\" data=\"img/1135_mail.swf\" type=\"application/x-shockwave-flash\"><param name=\"wmode\" value=\"transparent\" /><param name=\"allowScriptAccess\" value=\"always\" /><param name=\"flashvars\" value=\"&in_title=почта&&url=mailto:video@aleks.od.ua&\" /><param name=\"src\" value=\"img/1135_mail.swf\" /></object></p>
<p class=\"text_contact\">
<script type=\"text/javascript\">// <![CDATA[
scrambleVideo();
// ]]></script>
</p>
<p class=\"text_contact\" style=\"margin-top: 15px;\">Фотограф</p>
<p class=\"text_contact\" style=\"margin-top: -10px;\">тел. 703-01-67</p>
<p class=\"text_contact\"><object style=\"margin-top: -10px; margin-bottom: -10px;\" width=\"115\" height=\"50\" data=\"img/1135_mail.swf\" type=\"application/x-shockwave-flash\"><param name=\"wmode\" value=\"transparent\" /><param name=\"allowScriptAccess\" value=\"always\" /><param name=\"flashvars\" value=\"&in_title=почта&&url=mailto:foto@aleks.od.ua&\" /><param name=\"src\" value=\"img/1135_mail.swf\" /></object></p>
<p class=\"text_contact\">
<script type=\"text/javascript\">// <![CDATA[
scrambleFoto();
// ]]></script>
</p>
</div>
</div>






<!--Средняя колонка-->
<div class=\"c_colonka\">
<div class=\"block\">
<h2>Направление деятельности</h2>
<h1>Немного о нас</h1>

<p>Студия «Креатив» - это профессиональная фото и видеосъемка свадеб, корпоративных вечеров, юбилеев и других памятных торжеств; Love story; портретное, семейное, детское фото; гламурное фото и т.д. Наши преимущества – соответствующее профильное образование а так же большой практический опыт проведения и создания фото и видеосъемок на различные темы. Лучший фотограф и оператор Одессы в студии «Креатив». Обратившись к нам, Вы останетесь довольны. Яркая память о Вашем празднике – наша основная задача!</p>
</div>

<div class=\"drop-shadow lifted\">
<p> </p>
<p>В жизни каждого человека свадьба – это серьезный и ответственный шаг, это важный и запоминающийся день. Свадьба – это тот радостный момент, когда невеста будет самой красивой девушкой в мире, когда всё внимание, все слова, все поздравления будут адресованы лучшей паре на свете. Свадьба – это море радости, смеха, улыбок, брызги шампанского, танцы и веселые конкурсы. Момент, который запомнится молодой паре на всю жизнь!!! И, конечно же, не секрет, что в жизни двух людей, любящих друг друга, самым знаменательным и значимым событием является День Свадьбы. А все светлые и важные дни хочется запомнить навсегда. Но как сделать так, чтобы воспоминания оставались живыми и динамичными? Все очень просто: вам нужна профессиональная свадебная фото и видеосъемка.</p>
<p> </p>
</div>
</div>








<!--Правая колонка-->
<div class=\"drop-shadow lifted\" style=\"margin: 55px 0px 0px 15px; padding-left: 0px; padding-right: 0px; width: 232px; border-right-width: 10px; border-left-width: 5px;\">
<div class=\"r_colonka\">
<div class=\"news\" style=\"padding: 0px;\">
<div class=\"news_title\">Новости:</div>
<div class=\"data\"><object style=\"margin-top: -3px; margin-left: -5px;\" width=\"90\" height=\"20\" data=\"img/bigclock4.swf\" type=\"application/x-shockwave-flash\"><param name=\"wmode\" value=\"transparent\" /><param name=\"src\" value=\"img/bigclock4.swf\" /></object></div>
<p class=\"news_tit\" style=\"margin: 8px 0;\">Скидка 400гр</p>
<div><span style=\"color: #000000;\">на съемку свадеб - все дни, кроме<br /> <span style=\"text-align: center;\"><span class=\"ttext_orange\" style=\"font-family: Georgia,Times New Roman,Times,serif; font-size: 12px; font-weight: normal; color: #0000cd;\">Пт,Сб и Вс.</span></span></span></div>
<div class=\"spec_title\">Спецпредложения:</div>
<p style=\"font-family: Georgia,Times New Roman,Times,serif; font-size: 12px; font-weight: normal; color: #000000;\">padding-left: – определяет внутренний отступ слева. margin-top: – определяет внешний отступ сверху. margin-left: – определяет внешний отступ слева. min-width: – определяет минимальную ширину. max-width: – определяет максимальную ширину.</p>
</div>
<p>Поделитесь с друзьями:</p>
 <!-- AddThis Button BEGIN -->
        <div class=\"addthis_toolbox addthis_default_style addthis_32x32_style\">
            <a class=\"addthis_button_odnoklassniki_ru\"></a>
            <a class=\"addthis_button_vk\"></a>
            <a class=\"addthis_button_mymailru\"></a>
            <a class=\"addthis_button_compact\"></a>
            <a class=\"addthis_counter addthis_bubble_style\"></a>
        </div>
        <script type=\"text/javascript\">var addthis_config = {\"data_track_addressbar\":true};</script>
        <script type=\"text/javascript\" src=\"//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5130b3ac183d6054\"></script>
        <!-- AddThis Button END -->
<p> </p>
</div>

</div>', '1.Главная');
INSERT INTO content VALUES ('2', '<br><br><br>   

<p>\"Покупайте лотереи сберегательного банка!... А не будут брать - отключим газ!\"</p>


<!--

<style type=\"text/css\">

body
{
   
   margin: 0;
   background-color: #110011;
   color: #DCDCDC;
}
</style>
<style type=\"text/css\">

h5
{
   font-family: Arial;
   font-size: 19px;
   font-weight: normal;
   font-style: normal;
   text-decoration: none;
   color: #000000;
   margin: 0 0 0 0;
   padding: 0 0 0 0;
   display: inline;
}
</style>

<style type=\"text/css\">
#Table1
{
   border: 0px #C0C0C0 none;
   background-color: transparent;
   border-spacing: 0px;
}
#Table1 td
{
   padding: 0px 0px 0px 0px;
}
#Table1 td div
{
   white-space: nowrap;
}
#Table2
{
   border: 0px #C0C0C0 none;
   background-color: #FFA500;
   border-spacing: 1px;
}
#Table2 td
{
   padding: 3px 3px 3px 3px;
}
#Table2 td div
{
   white-space: nowrap;
}
#Table4
{
   border: 0px #C0C0C0 none;
   background-color: #FFA500;
   border-spacing: 1px;
}
#Table4 td
{
   padding: 3px 3px 3px 3px;
}
#Table4 td div
{
   white-space: nowrap;
}
#Table5
{
   border: 0px #C0C0C0 none;
   background-color: #FFA500;
   border-spacing: 0px;
}
#Table5 td
{
   padding: 6px 6px 6px 6px;
}
#Table5 td div
{
   white-space: nowrap;
}
#Table6
{
   border: 0px #C0C0C0 none;
   background-color: #FFA500;
   border-spacing: 1px;
}
#Table6 td
{
   padding: 3px 3px 3px 3px;
}
#Table6 td div
{
   white-space: nowrap;
}
#Table3
{
   border: 1px #C0C0C0 dotted;
   background-color: #FFA500;
   border-spacing: 0px;
}
#Table3 td
{
   padding: 0px 0px 0px 0px;
}
#Table3 td div
{
   white-space: nowrap;
}
</style>


<body>
<div id=\"container\">
<table style=\"position:absolute;left:234px;top:125px;width:736px;height:902px;z-index:0;\" cellpadding=\"0\" cellspacing=\"0\" id=\"Table1\">
<tr>
<td colspan=\"2\" style=\"background-color:transparent;text-align:center;vertical-align:middle;height:26px;\">
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:21px;\">Прайс-лист по фотосъемке:</span></div>
</td>
</tr>
<tr>
<td colspan=\"2\" style=\"background-color:transparent;text-align:center;vertical-align:middle;height:24px;\">
<div><span style=\"color:#FF4500;font-family:Arial;font-size:15px;\"><strong>Акция - при заказе фото и видео СКИДКА 400гр.   на съемку свадьбы в Воскресенье </strong></span></div>
</td>
</tr>
<tr>
<td style=\"background-color:#FFD700;text-align:center;vertical-align:middle;width:586px;height:28px;\">
<div><h5>Услуги</h5><span style=\"color:#000000;font-family:Arial;font-size:19px;\"><strong>  </strong></span><span style=\"color:#000000;font-family:Arial;font-size:13px;\"><strong>( желтым цветом выделенны различия)</strong></span></div>
</td>
<td style=\"background-color:#FFD700;text-align:center;vertical-align:middle;height:28px;\">
<div><h5>Стоимость</h5></div>
</td>
</tr>
<tr>
<td style=\"background-color:transparent;text-align:left;vertical-align:middle;width:586px;height:248px;\">
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:16px;\"><strong><br></strong></span></div>
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:16px;\"><strong>                                           Пакет услуг \"</strong></span><span style=\"color:#00FF7F;font-family:Arial;font-size:21px;\"><em>Стандарт</em></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:16px;\"><strong>\"</strong></span></div>
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:15px;\">- репортажная и постановочная съемка свадьбы в RAW формате</span></div>
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:15px;\">  ( до тортика, но не позже 24.00 )</span></div>
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:15px;\">- обработка фотографий ( цвет, кадрировка )</span></div>
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:15px;\">- ретущь выбранных заказчиком фотографий  -  8 гр. каждая</span></div>
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:15px;\">- печать контролек  на листах А4 -  беспатно,  в  виде фотокниги  + 400 гр.</span></div>
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:15px;\">- 8 гр. за фото в услугах фотобанка в течении  6 месяцев</span></div>
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:15px;\">- запись на диск при 80% заказе от отснятого количества фотографий</span></div>
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:15px;\">- минимальный заказ ~ 350-500 фотографий - свадьба 35-70 человек </span></div>
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:15px;\">   (зависит от количества гостей)</span></div>
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:15px;\">- скидка на ФОТОКНИГУ - 200 гр.</span></div>
</td>
<td style=\"background-color:transparent;text-align:center;vertical-align:middle;height:248px;\">
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"><strong> 800 Гр. + 8 Гр.</strong></span></div>
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"><strong>каждая фотография</strong></span></div>
</td>
</tr>
<tr>
<td style=\"background-color:transparent;text-align:left;vertical-align:top;width:586px;height:180px;\">
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:17px;\"><strong>                                   </strong></span></div>
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:17px;\"><strong>                                   Пакет услуг \"</strong></span><span style=\"color:#00FF7F;font-family:Arial;font-size:21px;\"><em>Диск-mini</em></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:17px;\"><strong>\"</strong></span></div>
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:15px;\">- постановочная и репортажная съемка  в RAW формате свадебной прогулки</span></div>
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:15px;\">   ( до 3х часов )</span></div>
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:15px;\">- обработка фотографий ( цвет и кадрировка  ) и подготовка к печати</span></div>
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:15px;\">- запись на диск + оформление обложки</span></div>
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:15px;\">- 4 гр. за фото  услуги фотобанка  в течении  1 месяца  после выполнения работы</span></div>
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:15px;\">- скидка на ФОТОКНИГУ - 150 гр.</span></div>
</td>
<td style=\"background-color:transparent;text-align:center;vertical-align:middle;height:180px;\">
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"><strong> 2 400 гр.</strong></span></div>
</td>
</tr>
<tr>
<td style=\"background-color:transparent;text-align:left;vertical-align:top;width:586px;height:66px;\">
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:17px;\"><strong>                                   Пакет услуг \"</strong></span><span style=\"color:#00FF7F;font-family:Arial;font-size:21px;\"><em>Диск-mini</em></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:17px;\"><strong>\"</strong></span></div>
</td>
<td style=\"background-color:transparent;text-align:left;vertical-align:top;height:66px;\">
<div><span style=\"color:#000000;font-family:Arial;font-size:13px;\"> </span></div>
</td>
</tr>
<tr>
<td style=\"background-color:transparent;text-align:left;vertical-align:top;width:586px;height:66px;\">
<div><span style=\"color:#000000;font-family:Arial;font-size:13px;\"> </span><span style=\"color:#F5F5F5;font-family:Arial;font-size:17px;\"><strong>                                   Пакет услуг \"</strong></span><span style=\"color:#00FF7F;font-family:Arial;font-size:21px;\"><em>Диск-mini</em></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:17px;\"><strong>\"</strong></spa
n></div>
</td>
<td style=\"background-color:transparent;text-align:left;vertical-align:top;height:66px;\">
<div><span style=\"color:#000000;font-family:Arial;font-size:13px;\"> </span></div>
</td>
</tr>
<tr>
<td style=\"background-color:transparent;text-align:left;vertical-align:top;width:586px;height:66px;\">
<div><span style=\"color:#000000;font-family:Arial;font-size:13px;\"> </span><span style=\"color:#F5F5F5;font-family:Arial;font-size:17px;\"><strong>                                   Пакет услуг \"</strong></span><span style=\"color:#00FF7F;font-family:Arial;font-size:21px;\"><em>Диск-mini</em></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:17px;\"><strong>\"</strong></spa
n></div>
</td>
<td style=\"background-color:transparent;text-align:left;vertical-align:top;height:66px;\">
<div><span style=\"color:#000000;font-family:Arial;font-size:13px;\"> </span></div>
</td>
</tr>
<tr>
<td style=\"background-color:transparent;text-align:left;vertical-align:top;width:586px;height:66px;\">
<div><span style=\"color:#000000;font-family:Arial;font-size:13px;\"> </span><span style=\"color:#F5F5F5;font-family:Arial;font-size:17px;\"><strong>                                   Пакет услуг \"</strong></span><span style=\"color:#00FF7F;font-family:Arial;font-size:21px;\"><em>Диск-mini</em></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:17px;\"><strong>\"</strong></spa
n></div>
</td>
<td style=\"background-color:transparent;text-align:left;vertical-align:top;height:66px;\">
<div><span style=\"color:#000000;font-family:Arial;font-size:13px;\"> </span></div>
</td>
</tr>
<tr>
<td style=\"background-color:transparent;text-align:left;vertical-align:top;width:586px;height:66px;\">
<div><span style=\"color:#000000;font-family:Arial;font-size:13px;\"> </span><span style=\"color:#F5F5F5;font-family:Arial;font-size:17px;\"><strong>                                   Пакет услуг \"</strong></span><span style=\"color:#00FF7F;font-family:Arial;font-size:21px;\"><em>Диск-mini</em></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:17px;\"><strong>\"</strong></spa
n></div>
</td>
<td style=\"background-color:transparent;text-align:left;vertical-align:top;height:66px;\">
<div><span style=\"color:#000000;font-family:Arial;font-size:13px;\"> </span></div>
</td>
</tr>
<tr>
<td style=\"background-color:transparent;text-align:left;vertical-align:top;width:586px;height:66px;\">
<div><span style=\"color:#000000;font-family:Arial;font-size:13px;\"> </span><span style=\"color:#F5F5F5;font-family:Arial;font-size:17px;\"><strong>                                   Пакет услуг \"</strong></span><span style=\"color:#00FF7F;font-family:Arial;font-size:21px;\"><em>Диск-mini</em></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:17px;\"><strong>\"</strong></spa
n></div>
</td>
<td style=\"background-color:transparent;text-align:left;vertical-align:top;height:66px;\">
<div><span style=\"color:#000000;font-family:Arial;font-size:13px;\"> </span></div>
</td>
</tr>
</table>
<table style=\"position:absolute;left:32px;top:127px;width:176px;height:207px;z-index:1;\" cellpadding=\"3\" cellspacing=\"1\" id=\"Table2\">
<tr>
<td style=\"background-color:transparent;text-align:center;vertical-align:middle;height:38px;\">
<div><span style=\"color:#000000;font-family:Arial;font-size:13px;letter-spacing:0px;\"><strong>ПРАЙС - ЛИСТЫ</strong></span></div>
</td>
</tr>
<tr>
<td style=\"background-color:#000040;text-align:left;vertical-align:top;height:154px;\">
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"><br></span></div>
<div><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\">></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"> </span><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\"><a href=\"#\" onmouseup=\"ShowObject(\'Table1\', 0);return false;\" onblur=\"ShowObject(\'Table2\', 1);return false;\">sdffsdfsdf</a></span></div>
<div><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\">></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"> <a href=\"#\" onmouseup=\"ShowObject(\'Table1\', 1);return false;\">sdfsdfsdfs</a></span></div>
<div><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\">></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"> sdfsdfsdf</span></div>
<div><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\">></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"> sdfsddfs</span></div>
</td>
</tr>
</table>
<table style=\"position:absolute;left:1001px;top:127px;width:176px;height:207px;z-index:2;\" cellpadding=\"3\" cellspacing=\"1\" id=\"Table4\">
<tr>
<td style=\"background-color:transparent;text-align:center;vertical-align:middle;height:38px;\">
<div><span style=\"color:#000000;font-family:Arial;font-size:13px;letter-spacing:0px;\"><strong>ПРАЙС - ЛИСТЫ</strong></span></div>
</td>
</tr>
<tr>
<td style=\"background-color:#000040;text-align:left;vertical-align:top;height:154px;\">
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"><br></span></div>
<div><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\">></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"> </span><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\"><a href=\"#\" onmouseup=\"ShowObject(\'Table1\', 0);return false;\" onblur=\"ShowObject(\'Table2\', 1);return false;\">sdffsdfsdf</a></span></div>
<div><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\">></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"> <a href=\"#\" onmouseup=\"ShowObject(\'Table1\', 1);return false;\">sdfsdfsdfs</a></span></div>
<div><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\">></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"> sdfsdfsdf</span></div>
<div><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\">></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"> sdfsddfs</span></div>
</td>
</tr>
</table>
<table style=\"position:absolute;left:22px;top:127px;width:196px;height:290px;z-index:3;\" cellpadding=\"6\" cellspacing=\"0\" id=\"Table5\">
<tr>
<td style=\"background-color:transparent;text-align:center;vertical-align:middle;height:24px;\">
<div><span style=\"color:#000000;font-family:Arial;font-size:13px;letter-spacing:0px;\"><strong>ПРАЙС - ЛИСТЫ</strong></span></div>
</td>
</tr>
<tr>
<td style=\"background-color:#1A001A;text-align:left;vertical-align:top;height:242px;\">
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"><br></span></div>
<div><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\">></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"> прайс на видеосъёмку</span></div>
<div><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\">></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"> <a href=\"#\" onmouseup=\"ShowObject(\'Table1\', 1);return false;\">sdfsdfsdfs</a></span></div>
<div><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\">></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"> sdfsdfsdf</span></div>
<div><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\">></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"> sdfsddfs</span></div>
</td>
</tr>
</table>
<table style=\"position:absolute;left:1001px;top:589px;width:176px;height:207px;z-index:4;\" cellpadding=\"3\" cellspacing=\"1\" id=\"Table6\">
<tr>
<td style=\"background-color:transparent;text-align:center;vertical-align:middle;height:38px;\">
<div><span style=\"color:#000000;font-family:Arial;font-size:13px;letter-spacing:0px;\"><strong>ПРАЙС - ЛИСТЫ</strong></span></div>
</td>
</tr>
<tr>
<td style=\"background-color:#000040;text-align:left;vertical-align:top;height:154px;\">
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"><br></span></div>
<div><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\">></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"> </span><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\"><a href=\"#\" onmouseup=\"ShowObject(\'Table1\', 0);return false;\" onblur=\"ShowObject(\'Table2\', 1);return false;\">sdffsdfsdf</a></span></div>
<div><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\">></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"> <a href=\"#\" onmouseup=\"ShowObject(\'Table1\', 1);return false;\">sdfsdfsdfs</a></span></div>
<div><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\">></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"> sdfsdfsdf</span></div>
<div><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\">></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"> sdfsddfs</span></div>
</td>
</tr>
</table>
<table style=\"position:absolute;left:23px;top:589px;width:196px;height:289px;z-index:5;\" cellpadding=\"0\" cellspacing=\"0\" id=\"Table3\">
<tr>
<td style=\"background-color:transparent;text-align:center;vertical-align:middle;height:39px;\">
<div><span style=\"color:#000000;font-family:Arial;font-size:13px;letter-spacing:0px;\"><strong>ПРАЙС - ЛИСТЫ</strong></span></div>
</td>
</tr>
<tr>
<td style=\"background-color:#1A001A;text-align:left;vertical-align:top;height:248px;\">
<div><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"><br></span></div>
<div><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\">></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"> </span><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\"><a href=\"#\" onmouseup=\"ShowObject(\'Table1\', 0);return false;\" onblur=\"ShowObject(\'Table2\', 1);return false;\">sdffsdfsdf</a></span></div>
<div><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\">></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"> <a href=\"#\" onmouseup=\"ShowObject(\'Table1\', 1);return false;\">sdfsdfsdfs</a></span></div>
<div><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\">></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"> sdfsdfsdf</span></div>
<div><span style=\"color:#FFD700;font-family:Arial;font-size:13px;\">></span><span style=\"color:#F5F5F5;font-family:Arial;font-size:13px;\"> sdfsddfs</span></div>
</td>
</tr>
</table>
</div>
-->', '2.Фотобанк');
INSERT INTO content VALUES ('3', '3.Цены', '3.Цены');
INSERT INTO content VALUES ('4', '<script type=\"text/javascript\" language=\"JavaScript\">// <![CDATA[
var h=(new Date()).getHours();
if (h > 23 || h < 7) document.write(\"Что-то припозднились вы сегодня.\") ;
if (h > 6 && h < 12) document.write(\"Кто ходит в гости по утрам...\");
if (h > 11 && h < 19) document.write(\"Милости просим, гости дорогие.\");
if (h > 18 && h < 24) document. write(\"Добрый вечер!\");
// ]]></script>
', '4.Контакты');
INSERT INTO content VALUES ('5', '<p> Различные варианты свадеб</p>

', '5.Фото-свадьбы');
INSERT INTO content VALUES ('6', '<p><strong>&nbsp;ОБНОВИТЕ СТРАНИЧКУ</strong>, чтоб увидеть новую цитату. vbvbn&nbsp; bvnb<br /><br /></p>
<p>&nbsp;</p>', '6.Фото-дети');
INSERT INTO content VALUES ('7', '<table id=\"1\" style=\"width: 1200px; height: 299px;\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\" align=\"center\"><caption>&nbsp;</caption>
<tbody>
<tr style=\"background-color: #d2d500; height: 30px;\" align=\"center\" valign=\"middle\">
<td>hjkhjkhjkhjkjk</td>
<th scope=\"row\" align=\"center\">hjkjkjkhkjkhjk</th>
<td align=\"center\">hjkkjkhkjk</td>
</tr>
<tr style=\"height: 500px;\">
<td><!--Левая колонка--><br />
<div class=\"l_colonka\"><br />
<div class=\"small_menu\"><!--<div class =\"small_head\"><p class =\"toptext_00\">Меню:</p></div>--> <!--Меню слева--><dl id=\"menu\"><dt><a href=\"../myfotos/foto.php\"> <strong>Видео</strong> </a></dt><dt><a href=\"../index.php\"> <strong>Фото</strong> </a></dt><dt><a href=\"../index.php\"> <strong>Фотокниги</strong> </a></dt><dt><a href=\"../index.php\"> <strong>Слайд шоу</strong> </a></dt><dt><a href=\"../index.php\"> <strong>Коллажи</strong> </a></dt><dt><a href=\"../videoarhiv\"> <strong>Прайс-лист по фотосъемке</strong> </a></dt><dt><a href=\"../prays-list_po_videosem\"> <strong>Love Story</strong> </a></dt><dt><a href=\"../love_story\"> <strong>Прайс-лист по видеосъемке</strong> </a></dt><dt><a href=\"../video_love_story\"> <strong>Видео Love Story</strong> </a></dt><dt><a href=\"../fk/demo.php\"> <strong>Гид по фотобанку </strong> </a></dt><dt><a href=\"http://ktonanovenkogo.ru/wp-content/uploads/style.html\"> <strong>Видеоуроки</strong> </a></dt></dl></div>
<br />
<div class=\"contact\"><br />
<div class=\"small_head\"><br />
<p class=\"toptext_00\">Контакты:</p>
</div>
<p class=\"text_contact\">Видеооператор</p>
<p class=\"text_contact\">тел. 094-94-77-070</p>
<p class=\"text_contact\"><a href=\"mailto:jurii@aleks.od.ua\">video@aleks.od.ua</a></p>
<p class=\"text_contact\">Фотограф</p>
<p class=\"text_contact\">тел. 703-01-67</p>
<p class=\"text_contact\"><a href=\"mailto:anna@aleks.od.ua\">foto@aleks.od.ua</a></p>
</div>
</div>
</td>
<td style=\"width: 700px;\" valign=\"top\">
<p style=\"margin-left: 30px;\">НовостиАтрибуты и значения: background-color: &ndash; определяет цвет фона. margin:0 auto &ndash; определяет центрирование блока. width: &ndash; определяет ширину в пикселях или в процентах. height: &ndash; определяет высоту. float:left &ndash; определяет обтекание слева. border-right: &ndash; определяет свойства правой границы. clear:both &ndash; отменяет обтекание с обеих сторон. padding-left: &ndash; определяет внутренний отступ слева. margin-top: &ndash; определяет внешний отступ сверху. margin-left: &ndash; определяет внешний отступ слева. min-width: &ndash; определяет минимальную ширину. max-width: &ndash; определяет <sup>максимальную</sup> <sub>ширину.</sub></p>
</td>
<td align=\"right\" valign=\"top\">
<h2 style=\"text-align: left;\">НОВОСТИ<span style=\"font-size: large; font-family: verdana,geneva;\"><br /></span></h2>
<p style=\"text-align: left;\">Атрибуты и значения: background-color: &ndash; определяет цвет фона. margin:0 auto &ndash; определяет центрирование блока. width: &ndash; определяет ширину в пикселях или в процентах. height: &ndash; определяет высоту. float:left &ndash; определяет обтекание слева. border-right: &ndash; определяет свойства правой границы. clear:both &ndash; отменяет обтекание с обеих сторон. padding-left: &ndash; определяет внутренний отступ слева. margin-top: &ndash; определяет внешний отступ сверху. margin-left: &ndash; определяет внешний отступ слева. min-width: &ndash; определяет минимальную ширину. max-width: &ndash; определяет максимальную ширину.</p>
<p class=\"news_title\">&nbsp;</p>
</td>
</tr>
</tbody>
</table>', '7.Фото-банкеты');
INSERT INTO content VALUES ('8', '<p><strong>Hello world!! gfhgfgh hgвыаыв<br /></strong></p>
<p><strong>орлрол </strong></p>
<!-- AddThis Button BEGIN -->
<div class=\"addthis_toolbox addthis_default_style addthis_32x32_style\"><a class=\"addthis_button_preferred_1\"></a> <a class=\"addthis_button_preferred_2\"></a> <a class=\"addthis_button_preferred_3\"></a> <a class=\"addthis_button_preferred_4\"></a> <a class=\"addthis_button_compact\"></a> <a class=\"addthis_counter addthis_bubble_style\"></a></div>
<script type=\"text/javascript\">// <![CDATA[
var addthis_config = {\"data_track_addressbar\":true};
// ]]></script>
<script src=\"http://s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5130b3ac183d6054\" type=\"text/javascript\"></script>
<!-- AddThis Button END -->
<p><span id=\"share42\"> <a style=\"display: inline-block; vertical-align: bottom; width: 32px; height: 32px; margin: 0 6px 6px 0; padding: 0; outline: none; background: url(http://literball.com/js/icons.png) -0px 0 no-repeat;\" title=\"Поделиться в Facebook\" onclick=\"window.open(\'http://www.facebook.com/sharer.php?u=VIDEO_URL&t=VIDEO_TITLE\', \'_blank\', \'scrollbars=0, resizable=1, menubar=0, left=200, top=200, width=550, height=440, toolbar=0, status=0\');return false\" rel=\"nofollow\" href=\"#\" target=\"_blank\"></a> <a style=\"display: inline-block; vertical-align: bottom; width: 32px; height: 32px; margin: 0 6px 6px 0; padding: 0; outline: none; background: url(http://literball.com/js/icons.png) -32px 0 no-repeat;\" title=\"Добавить в Одноклассники\" onclick=\"window.open(\'http://www.odnoklassniki.ru/dk?st.cmd=addShare&st._surl=VIDEO_URL&title=VIDEO_TITLE\', \'_blank\', \'scrollbars=0, resizable=1, menubar=0, left=200, top=200, width=550, height=440, toolbar=0, status=0\');return false\" rel=\"nofollow\" href=\"#\" target=\"_blank\"></a> <a style=\"display: inline-block; vertical-align: bottom; width: 32px; height: 32px; margin: 0 6px 6px 0; padding: 0; outline: none; background: url(http://literball.com/js/icons.png) -64px 0 no-repeat;\" title=\"Добавить в Twitter\" onclick=\"window.open(\'http://twitter.com/share?text=VIDEO_TITLE&url=VIDEO_URL\', \'_blank\', \'scrollbars=0, resizable=1, menubar=0, left=200, top=200, width=550, height=440, toolbar=0, status=0\');return false\" rel=\"nofollow\" href=\"#\" target=\"_blank\"></a> <a style=\"display: inline-block; vertical-align: bottom; width: 32px; height: 32px; margin: 0 6px 6px 0; padding: 0; outline: none; background: url(http://literball.com/js/icons.png) -96px 0 no-repeat;\" title=\"Поделиться В Контакте\" onclick=\"window.open(\'http://vk.com/share.php?url=VIDEO_URL&title=VIDEO_TITLE\', \'_blank\', \'scrollbars=0, resizable=1, menubar=0, left=200, top=200, width=554, height=421, toolbar=0, status=0\');return false\" rel=\"nofollow\" href=\"#\" target=\"_blank\"></a> </span></p>', '8.Фотокниги');
INSERT INTO content VALUES ('9', 'Тест', '9.Фото-выпускники');
INSERT INTO content VALUES ('10', '10.Фото-разное', '10.Фото-разное');
INSERT INTO content VALUES ('11', '<center>
Свадебная прогулка в парке.
<br><br>
<iframe width=\"640\" height=\"360\" src=\"http://www.youtube.com/embed/dCSYge7x7mQ?rel=0\" frameborder=\"0\" allowfullscreen></iframe><br><br><br><br><br>

Невеста Рафаэлла.
<br><br>
<iframe width=\"640\" height=\"360\" src=\"http://www.youtube.com/embed/ciWi4JcbWNw?rel=0\" frameborder=\"0\" allowfullscreen></iframe><br><br><br><br><br>


Путешествие из Ильичевска в Одессу.
<br><br>
<iframe width=\"640\" height=\"360\" src=\"http://www.youtube.com/embed/Wr7Y3jrQ6gc?rel=0\" frameborder=\"0\" allowfullscreen></iframe><br><br><br><br><br>

Романтичесская прогулка.
<br><br>
<iframe width=\"640\" height=\"360\" src=\"http://www.youtube.com/embed/15HsXscr8aU?rel=0\" frameborder=\"0\" allowfullscreen></iframe><br><br><br><br><br>

Невеста Оксана.
<br><br>
<iframe width=\"640\" height=\"360\" src=\"http://www.youtube.com/embed/neScekWAZ7w?rel=0\" frameborder=\"0\" allowfullscreen></iframe>
<br><br><br><br><br>
Свадьба Жени и Андрея.
<br><br>
<iframe width=\"640\" height=\"360\" src=\"http://www.youtube.com/embed/waJNGpUhbLk?rel=0\" frameborder=\"0\" allowfullscreen></iframe><br><br><br><br><br>

Заключительный клип свадебного фильма.
<br><br>
<iframe width=\"640\" height=\"360\" src=\"http://www.youtube.com/embed/G6-7rboF8Dc?rel=0\" frameborder=\"0\" allowfullscreen></iframe><br><br><br><br><br>


Игра ВА-БАНК или где взять деньги на свадьбу.  :)  Шуточный фильм, показанный в день свадьбы.
<br><br>
<iframe width=\"640\" height=\"360\" src=\"http://www.youtube.com/embed/rlMrCRe81OQ?rel=0\" frameborder=\"0\" allowfullscreen></iframe><br><br><br><br><br>

Свадебная прогулка Deja-vu.
<br><br>
<iframe width=\"640\" height=\"360\" src=\"http://www.youtube.com/embed/sqgb0b-tV3o?rel=0\" frameborder=\"0\" allowfullscreen></iframe><br><br><br><br><br>

Романтичесское свидание на море.
<br><br>
<iframe width=\"640\" height=\"360\" src=\"http://www.youtube.com/embed/7Z5DGeJbqrc?rel=0\" frameborder=\"0\" allowfullscreen></iframe>
</center>', '11.Видео-свадьбы');
INSERT INTO content VALUES ('12', '<p style=\"text-align: center;\">&nbsp;<object style=\"float: left;\" width=\"276\" height=\"158\" data=\"http://31.31.105.95/videostation/player/cbplayer/player.swf?config=http%3A%2F%2F31.31.105.95%2Fvideostation%2Fplayer%2Fcbplayer%2Fembed_player.php%3Fvid%3D960%26autoplay%3Dyes\" type=\"application/x-shockwave-flash\"><param name=\"src\" value=\"http://31.31.105.95/videostation/player/cbplayer/player.swf?config=http%3A%2F%2F31.31.105.95%2Fvideostation%2Fplayer%2Fcbplayer%2Fembed_player.php%3Fvid%3D960%26autoplay%3Dyes\" /><param name=\"allowscriptaccess\" value=\"always\" /><param name=\"allowfullscreen\" value=\"true\" /></object></p>
<p><object style=\"display: block; margin-left: auto; margin-right: auto;\" width=\"660\" height=\"408\" data=\"http://192.168.1.232/videostation/player/cbplayer/player.swf?config=http%3A%2F%2F192.168.1.232%2Fvideostation%2Fplayer%2Fcbplayer%2Fembed_player.php%3Fvid%3D960%26autoplay%3Dyes\" type=\"application/x-shockwave-flash\"><param name=\"src\" value=\"http://192.168.1.232/videostation/player/cbplayer/player.swf?config=http%3A%2F%2F192.168.1.232%2Fvideostation%2Fplayer%2Fcbplayer%2Fembed_player.php%3Fvid%3D960%26autoplay%3Dyes\" /><param name=\"allowscriptaccess\" value=\"always\" /><param name=\"allowfullscreen\" value=\"true\" /></object></p>', '12.Видео-дети');
INSERT INTO content VALUES ('13', '<center>
Открытый урок
<br>
<iframe width=\"640\" height=\"360\" src=\"http://www.youtube.com/embed/J5u_IEey2J4?rel=0\" frameborder=\"0\" allowfullscreen></iframe><br><br><br><br>

Интервью
<br>
<iframe width=\"640\" height=\"360\" src=\"http://www.youtube.com/embed/XMgk2sbbZA4?rel=0\" 
frameborder=\"0\" allowfullscreen></iframe><br><br><br><br>

Клип для мамы
<br>
<iframe width=\"640\" height=\"360\" src=\"http://www.youtube.com/embed/TMbd6t_KboE?rel=0\" frameborder=\"0\" allowfullscreen></iframe>

</center>', '13.Видео-выпускники');
INSERT INTO content VALUES ('14', '<p>Видеосъемка концертов, спектаклей и постановок осуществляется в зависимости от поставленной заказчиком задачи одной или двумя - тремя камерами. В формате CD (DVD) или FullHD. Чем отличаются между собой форматы и разницу между однокамерной  и двукамерной съемкой Вы можете посмотреть ниже.</p>
<center>
<br><br> Для сравнения:<br> Балет \"Золушка\" в \"CD\" формате, однокамерная съемка.

<br><br>

<iframe width=\"640\" height=\"360\" src=\"http://www.youtube.com/embed/-9DCLZn9uAI?rel=0\" frameborder=\"0\" allowfullscreen></iframe>

<br><br><br><br><br> \"Золушка\" в формате \"HD\", однокамерная съемка. <br><br>

<iframe width=\"1280\" height=\"720\" src=\"http://www.youtube.com/embed/-9DCLZn9uAI?rel=0\" frameborder=\"0\" allowfullscreen></iframe>

<br><br><br><br><br>

Tomas Nevergreen. Концерт. Двухкамерная съёмка в \"CD\" формате.<br><br>
<iframe width=\"640\" height=\"360\" src=\"http://www.youtube.com/embed/cLagdI0G7dI?rel=0\" frameborder=\"0\" allowfullscreen></iframe>
<br><br><br><br><br><br>


Tomas Nevergreen. Концерт. Двухкамерная съёмка в \"HD\" формате.<br><br>
<iframe width=\"1280\" height=\"720\" src=\"http://www.youtube.com/embed/cLagdI0G7dI?rel=0\" frameborder=\"0\" al<br><br>lowfullscreen></iframe>


</center>', '14.Видео-разное');
INSERT INTO content VALUES ('16', '16.Видео-банкеты', '16.Видео-банкеты');
INSERT INTO content VALUES ('15', '<center>
Монтаж видеокипа из предоставленных заказчиком фотографий.
<br><br>
<iframe width=\"640\" height=\"360\" src=\"http://www.youtube.com/embed/DbJspiIoJ1k?rel=0\" frameborder=\"0\" allowfullscreen></iframe>
</center>', '15.Видео-слайдшоу');
INSERT INTO content VALUES ('17', '<p>Свадебные фотографии и свадебное видео от студии &laquo;Креатив&raquo; помогут Вам вновь и вновь переживать трепетные моменты этого чудесного дня. Если Вы празднуете свою свадьбу в Одессе, она уже будет незабываемой и красивой. Неповторимая Южная Пальмира с ее романтическими мостиками, историческими старинными двориками, восхитительными парками и архитектурой &mdash; идеальное место для Вашей свадьбы. Одним из самых важных моментов для молодоженов является свадебное фото, запечатлевшее всю эту красоту и историю создания новой семьи. Эти фотографии будут греть воспоминаниями, дадут возможность снова пережить радостные мгновения, заставят улыбнуться любого, кто взглянет на эти снимки &ndash; источник радости и вдохновения. Свадебный фотограф студии &laquo;Креатив&raquo; не пропустит ни одной детали Вашего праздника, подчеркнет красоту любящей пары, выполнит работу на высоком профессиональном уровне. Свадебная фотосъемка &ndash; это не просто банальный альбом с фотографиями гостей и виновников торжества, а семейная реликвия, которая будет передаваться из поколения в поколение, рассказывая уникальную историю Вашей свадьбы. Один из главных праздников, который бывает лишь раз является свадьба фото с которой будут согревать воспоминаниями всю жизнь.</p>
<p>Видеооператор на свадьбу &ndash; так же неотъемлемая часть любого торжества. Мы творчески подходим к обработке и монтажу видеосъемки. У нас всегда разные и оригинальные фильмы, сюжеты которых мы обязательно продумаем с Вами до мелочей: будь то просто небольшой свадебный ролик или же хроника всего дня с предварительной съемкой. Главный праздник новой семьи &ndash; свадьба видео с которой мы превратим в настоящий кинофильм, где Вы будете главными героями!!!</p>
<p>Свадебное видео и фото от профессиональной студии &laquo;Креатив&raquo; - это яркая память всех светлых и важных дней Вашей жизни. Наши фотограф и видеооператор работают зачастую вместе, что сокращает время и облегчает сам процесс съемки. Специалисты студии всегда создают для своих клиентов все самое красивое и лучшее!</p>
<center>
<p><span style=\"font-size: 18px;\"> Образцы работ, снятые нашей студией.</span></p>
</center>
<p>&nbsp;</p>', '17.Услуги до иконок');
INSERT INTO content VALUES ('18', '
<p><span style=\"color: #ccc; font-size:14px\">Совет: если у Вас не воспроизводится видео в браузере попробуйте
отключить ADBLOCK или воспользуйтесь другим браузером. Вы также можете просмотреть
эти матерьялы напрямую на YouTube.</span></p>	', '18.Услуги после иконок');


#
# Table structure for table `download_photo`
#

DROP TABLE IF EXISTS `download_photo`;
CREATE TABLE `download_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL DEFAULT '0',
  `id_order` int(11) NOT NULL DEFAULT '0',
  `id_order_item` int(11) NOT NULL DEFAULT '0',
  `id_photo` int(11) NOT NULL DEFAULT '0',
  `dt_start` int(11) NOT NULL DEFAULT '0',
  `downloads` int(11) NOT NULL DEFAULT '0',
  `download_key` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_photo` (`id_photo`),
  KEY `dt_start` (`dt_start`),
  KEY `download_key` (`download_key`)
) ENGINE=MyISAM AUTO_INCREMENT=359 DEFAULT CHARSET=cp1251 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

#
# Dumping data for table `download_photo`
#

INSERT INTO download_photo VALUES ('89', '17', '63', '90', '2919', '1360402309', '0', '2285da77253fc2b823b78122669c48b1');
INSERT INTO download_photo VALUES ('88', '17', '63', '89', '2920', '1360402309', '0', '5388b8772aa74ecd57673ddb677b0693');
INSERT INTO download_photo VALUES ('87', '17', '62', '88', '2908', '1360402078', '0', 'fdef7f2d227e9030eff9f367a911cbff');
INSERT INTO download_photo VALUES ('86', '17', '62', '87', '2922', '1360402078', '0', 'bc0e722df4b923599534429660165012');
INSERT INTO download_photo VALUES ('85', '17', '62', '86', '2923', '1360402078', '0', 'b5018b30a8c9c661e8964dabc30bd00c');
INSERT INTO download_photo VALUES ('84', '17', '62', '85', '2924', '1360402078', '0', '6fb8bcf6f24b5281889e67efe8766894');
INSERT INTO download_photo VALUES ('83', '17', '62', '84', '2925', '1360402078', '0', '235f497fe5f7a988a7351578554dec4f');
INSERT INTO download_photo VALUES ('82', '17', '61', '83', '2899', '1360395734', '0', '0adbb0f50413c4c254e43d7d3419a96e');
INSERT INTO download_photo VALUES ('81', '17', '61', '82', '2924', '1360395734', '0', 'e8705a94c342bf8367ea50dcbdefc83b');
INSERT INTO download_photo VALUES ('80', '17', '61', '81', '2879', '1360395734', '0', '9999e294683943cefe084317fbe3329f');
INSERT INTO download_photo VALUES ('79', '17', '61', '80', '2881', '1360395734', '0', '0d624c101b4612b765ea81272c6e2994');
INSERT INTO download_photo VALUES ('78', '17', '61', '79', '2882', '1360395734', '0', '728f6766c125009741c5f697f3a7c2e2');
INSERT INTO download_photo VALUES ('77', '25', '60', '78', '2882', '1360395609', '0', '1b391b40630a73637ac9b16944c25d30');
INSERT INTO download_photo VALUES ('76', '25', '60', '77', '2878', '1360395609', '0', '546235ee12d91152ad26652aa0c2a8db');
INSERT INTO download_photo VALUES ('75', '25', '60', '76', '2887', '1360395609', '0', '3b46ce2f23b129a450ec6bbbf4572cf8');
INSERT INTO download_photo VALUES ('74', '25', '60', '75', '2888', '1360395609', '0', 'e2ae01de8c105d251ab2e7b1f800fa57');
INSERT INTO download_photo VALUES ('71', '25', '60', '72', '2890', '1360395609', '0', 'cb9e237a02e8be7a6074d54c38f43b70');
INSERT INTO download_photo VALUES ('72', '25', '60', '73', '2892', '1360395609', '0', '30a427b30a0454e8ed3fcdc98d0cedf1');
INSERT INTO download_photo VALUES ('73', '25', '60', '74', '2895', '1360395609', '0', 'e00c72f0adb2811a6031f55dd5f1180b');
INSERT INTO download_photo VALUES ('90', '17', '63', '91', '2918', '1360402309', '0', '8e5fe915023db9c07b7ef8bfdf37ac33');
INSERT INTO download_photo VALUES ('91', '17', '63', '92', '2917', '1360402309', '0', 'c4d16033796d9b2c1f8dcbc704040f37');
INSERT INTO download_photo VALUES ('92', '17', '63', '93', '2916', '1360402309', '0', '9b17be22b49519d9f90574b07278ecde');
INSERT INTO download_photo VALUES ('93', '17', '63', '94', '2915', '1360402309', '0', '6b93a6f84e52ae2842f1214fc198bdfa');
INSERT INTO download_photo VALUES ('94', '17', '63', '95', '2914', '1360402309', '0', 'ec25f0955c8a66891e8a5de9ffdb235d');
INSERT INTO download_photo VALUES ('95', '17', '63', '96', '2913', '1360402309', '0', '4187514639df4a147adf023cd3ffcae4');
INSERT INTO download_photo VALUES ('96', '17', '63', '97', '2912', '1360402309', '0', '3273a0a9a161094fec3bbdb0b1b12a2b');
INSERT INTO download_photo VALUES ('97', '17', '63', '98', '2911', '1360402309', '0', 'da80cb1856227fbeda3d61f664d58600');
INSERT INTO download_photo VALUES ('98', '17', '63', '99', '2910', '1360402309', '0', 'ac924adab63f348b0f8dbb8a5046ce86');
INSERT INTO download_photo VALUES ('99', '17', '63', '100', '2909', '1360402309', '0', '9da15bbb26f8ea06d22c3f5919025767');
INSERT INTO download_photo VALUES ('100', '17', '63', '101', '2895', '1360402309', '0', 'e691c635d9138409d5e0a313ad9a45e1');
INSERT INTO download_photo VALUES ('101', '25', '64', '102', '2933', '1360528321', '0', '425db0b9816cb7f5a8d3e10bab088cfc');
INSERT INTO download_photo VALUES ('102', '25', '64', '103', '2932', '1360528321', '0', '3a74617027bdef4c811abde850807228');
INSERT INTO download_photo VALUES ('103', '25', '64', '104', '2931', '1360528321', '0', '6d0724465effe3c767a25a28a2538634');
INSERT INTO download_photo VALUES ('104', '18', '65', '105', '2935', '1360529827', '0', '45e7ebfab46d9b40a64a3ad40979da09');
INSERT INTO download_photo VALUES ('105', '18', '65', '106', '2934', '1360529827', '0', '3594ff2197426515e7d3ca595864a4a9');
INSERT INTO download_photo VALUES ('106', '18', '66', '107', '2944', '1360531478', '0', 'ce7dd1bd56e5b4ce5ad962c595e3dcb2');
INSERT INTO download_photo VALUES ('107', '18', '66', '108', '2943', '1360531478', '0', 'cc8a68448722c345d03f0fda85fbe1ca');
INSERT INTO download_photo VALUES ('108', '18', '66', '109', '2942', '1360531478', '0', 'd7f410c53dc8b7d58cd533c64cc79eee');
INSERT INTO download_photo VALUES ('109', '20', '67', '110', '2948', '1360531961', '0', '916c9969a29b34edc1a21f92dbe47cae');
INSERT INTO download_photo VALUES ('110', '20', '67', '111', '2947', '1360531961', '0', '83605ff7012e3ce19884e2d857f681b5');
INSERT INTO download_photo VALUES ('111', '20', '67', '112', '2946', '1360531961', '0', 'aa3ed8d18b3d550ea9287fe62d6deeac');
INSERT INTO download_photo VALUES ('112', '25', '68', '113', '4753', '1361809470', '0', '1a91b52bf4c5de3ff58115227583d454');
INSERT INTO download_photo VALUES ('113', '25', '68', '114', '4756', '1361809470', '0', 'c6e49c9fe03d592cd85061f455214fb1');
INSERT INTO download_photo VALUES ('114', '20', '72', '115', '5285', '1364239576', '0', '272edb609f0c469db4ddf69ef7a575dc');
INSERT INTO download_photo VALUES ('115', '20', '72', '116', '5287', '1364239576', '0', '55364799aba61d768fdf943421a49816');
INSERT INTO download_photo VALUES ('116', '20', '72', '117', '5288', '1364239576', '0', '3ba57398ee08932fe74a9c0ac512906e');
INSERT INTO download_photo VALUES ('117', '20', '73', '118', '5352', '1364262634', '0', 'dfe63866f374529c65ff0422ef59d69b');
INSERT INTO download_photo VALUES ('118', '20', '73', '119', '5268', '1364262634', '0', '2f61c1a317e578e8d7a86a306471902e');
INSERT INTO download_photo VALUES ('119', '20', '74', '120', '5267', '1364262700', '0', '9dcef6786d8a74798712e8533173e857');
INSERT INTO download_photo VALUES ('120', '20', '74', '121', '5266', '1364262700', '0', 'b4502c51e69d44a14e7f3922686a00c8');
INSERT INTO download_photo VALUES ('121', '20', '75', '122', '5351', '1364397878', '0', '314a41e820bb6ba550f06826862f0b62');
INSERT INTO download_photo VALUES ('122', '20', '75', '123', '5323', '1364397878', '0', '3ed323852451f0768308f7838689b9c4');
INSERT INTO download_photo VALUES ('123', '20', '76', '124', '5267', '1364397926', '0', '943124a3dcf8953fdbe5160f3ec39d8e');
INSERT INTO download_photo VALUES ('124', '20', '77', '125', '5275', '1364397950', '0', '8e007845df19775537decf6245fa7fdd');
INSERT INTO download_photo VALUES ('125', '29', '82', '126', '5956', '1367678563', '0', '633');
INSERT INTO download_photo VALUES ('126', '29', '82', '127', '5982', '1367678563', '0', '14');
INSERT INTO download_photo VALUES ('134', '29', '86', '135', '5986', '1367926173', '0', '12');
INSERT INTO download_photo VALUES ('133', '29', '86', '134', '6011', '1367926173', '0', '27');
INSERT INTO download_photo VALUES ('129', '29', '84', '130', '5956', '1367679052', '0', '9');
INSERT INTO download_photo VALUES ('130', '29', '84', '131', '5973', '1367679052', '0', '86');
INSERT INTO download_photo VALUES ('131', '29', '85', '132', '5972', '1367682174', '0', '985');
INSERT INTO download_photo VALUES ('132', '29', '85', '133', '6166', '1367682174', '0', '0');
INSERT INTO download_photo VALUES ('135', '29', '87', '136', '6021', '1368042392', '0', '4');
INSERT INTO download_photo VALUES ('136', '29', '87', '137', '6023', '1368042392', '0', '92');
INSERT INTO download_photo VALUES ('137', '29', '87', '138', '6025', '1368042392', '0', '2');
INSERT INTO download_photo VALUES ('138', '29', '88', '139', '6003', '1368042955', '0', '995');
INSERT INTO download_photo VALUES ('182', '29', '155', '183', '5986', '1368445889', '0', 'ca9ddc0d3dac07f44eb68190561e62ff');
INSERT INTO download_photo VALUES ('140', '29', '90', '141', '5983', '1368043307', '0', '0');
INSERT INTO download_photo VALUES ('141', '29', '91', '142', '5986', '1368043396', '0', '0');
INSERT INTO download_photo VALUES ('142', '29', '92', '143', '5990', '1368043459', '0', '0');
INSERT INTO download_photo VALUES ('143', '29', '93', '144', '5990', '1368043736', '0', '0');
INSERT INTO download_photo VALUES ('144', '29', '94', '145', '5986', '1368043832', '0', '3355');
INSERT INTO download_photo VALUES ('145', '29', '95', '146', '6004', '1368043940', '0', '8352593');
INSERT INTO download_photo VALUES ('146', '29', '96', '147', '5986', '1368044412', '0', '7736');
INSERT INTO download_photo VALUES ('147', '29', '97', '148', '5983', '1368044442', '0', '14');
INSERT INTO download_photo VALUES ('148', '29', '98', '149', '5990', '1368044499', '0', '6');
INSERT INTO download_photo VALUES ('149', '29', '99', '150', '5982', '1368047723', '0', '85005');
INSERT INTO download_photo VALUES ('150', '29', '99', '151', '5983', '1368047723', '0', '0');
INSERT INTO download_photo VALUES ('151', '29', '99', '152', '5990', '1368047723', '0', '0');
INSERT INTO download_photo VALUES ('152', '29', '99', '153', '5991', '1368047723', '0', '674');
INSERT INTO download_photo VALUES ('153', '29', '99', '154', '5993', '1368047723', '0', '0');
INSERT INTO download_photo VALUES ('154', '29', '99', '155', '6011', '1368047723', '0', '97300');
INSERT INTO download_photo VALUES ('155', '29', '99', '156', '6012', '1368047723', '0', '42479');
INSERT INTO download_photo VALUES ('156', '29', '99', '157', '6014', '1368047723', '0', '0');
INSERT INTO download_photo VALUES ('157', '29', '99', '158', '5986', '1368047723', '0', '65');
INSERT INTO download_photo VALUES ('159', '29', '100', '160', '6492', '1368048764', '0', '14');
INSERT INTO download_photo VALUES ('160', '29', '103', '161', '5990', '1368050129', '3', 'c21d8306d638ad35cef741a29cc85959');
INSERT INTO download_photo VALUES ('161', '29', '104', '162', '5986', '1368052419', '1', 'ee007415bc46bd752c18c3bc48fd51f3');
INSERT INTO download_photo VALUES ('162', '29', '105', '163', '5990', '1368084632', '1', 'eb00415f3f5ee51a0bdd1650633d4d1c');
INSERT INTO download_photo VALUES ('163', '29', '105', '164', '5986', '1368084632', '1', 'f865cd775b6ae0f0de79ad44af6875e7');
INSERT INTO download_photo VALUES ('164', '29', '105', '165', '6032', '1368084632', '0', '5d6c162621839722c7a2313ed7911581');
INSERT INTO download_photo VALUES ('165', '29', '105', '166', '6101', '1368084632', '0', '0c7fe6b7b5db153a0fa2499922256404');
INSERT INTO download_photo VALUES ('166', '29', '151', '167', '6492', '1368103965', '0', '5794238baff7fe44e4bb0e4f9d49f185');
INSERT INTO download_photo VALUES ('167', '29', '151', '168', '5990', '1368103965', '0', '66f145b60dd395803dc2beb3f2810f9b');
INSERT INTO download_photo VALUES ('168', '29', '151', '169', '6158', '1368103965', '0', 'e7abc004749f6457a1a99aa3ba625be3');
INSERT INTO download_photo VALUES ('169', '29', '151', '170', '6159', '1368103965', '0', '2f57c032f9365d8838f36d04e544359c');
INSERT INTO download_photo VALUES ('170', '29', '151', '171', '6160', '1368103965', '0', '1b10bfa6f0c98a992a19020351f636a7');
INSERT INTO download_photo VALUES ('171', '29', '152', '172', '6004', '1368104916', '0', '8f98de5403698e59e8b94ae08c07307a');
INSERT INTO download_photo VALUES ('172', '29', '153', '173', '6010', '1368120789', '0', 'f801d9e2bf5907ec4eaab696277d0c8e');
INSERT INTO download_photo VALUES ('173', '29', '153', '174', '5982', '1368120789', '0', 'b9d95669ca01f5e99008c72acdc89d1c');
INSERT INTO download_photo VALUES ('174', '29', '153', '175', '5990', '1368120789', '0', '04e8d3eee433012fd0d227a96b16b8c1');
INSERT INTO download_photo VALUES ('175', '29', '153', '176', '5986', '1368120789', '0', '840a3b93e52b9fb478f8d9bdda2c8bbc');
INSERT INTO download_photo VALUES ('176', '29', '153', '177', '6011', '1368120789', '0', '9de53dbdccf1901ad6ee0a5fe1845e04');
INSERT INTO download_photo VALUES ('177', '29', '154', '178', '5986', '1368134795', '0', 'cfe8bff8162847e21dee0eaf68dfb9bd');
INSERT INTO download_photo VALUES ('178', '29', '154', '179', '6021', '1368134795', '0', 'cf983989fb76b89d592ac10f9e76fb0e');
INSERT INTO download_photo VALUES ('179', '29', '154', '180', '6023', '1368134795', '0', 'd6ad71ee4c92350056cece8cc6090efc');
INSERT INTO download_photo VALUES ('180', '29', '154', '181', '6025', '1368134795', '0', 'abcae4c932c05dac2be61217a26c303c');
INSERT INTO download_photo VALUES ('181', '29', '154', '182', '6026', '1368134795', '0', 'feea74e1471d6e7b91db5cd9d0c86840');
INSERT INTO download_photo VALUES ('183', '29', '156', '184', '6006', '1368447408', '1', '7eac00ee516047edb477af424055e92a');
INSERT INTO download_photo VALUES ('184', '29', '156', '185', '6007', '1368447408', '1', 'd224bac8cce3e6ab84b20c427de2123f');
INSERT INTO download_photo VALUES ('185', '29', '156', '186', '6008', '1368447408', '1', '6d9b6ce3c356d122b89f52eee879bf67');
INSERT INTO download_photo VALUES ('186', '29', '157', '187', '6006', '1368469512', '0', '85815b62f5295abc63b0c2db4e74af08');
INSERT INTO download_photo VALUES ('187', '29', '157', '188', '6008', '1368469512', '0', 'a00591f6ad0437ebbcc1c16b9b1bf86d');
INSERT INTO download_photo VALUES ('188', '29', '168', '189', '6012', '1368471789', '0', '51c642d40d00556082d3fe3e5a74e5c3');
INSERT INTO download_photo VALUES ('189', '29', '168', '190', '6013', '1368471789', '0', 'e55b447d739283ce9c6178d87082be70');
INSERT INTO download_photo VALUES ('190', '29', '168', '191', '6014', '1368471789', '0', '9c40d4ee2cca8cbe0e24189e747e11ff');
INSERT INTO download_photo VALUES ('191', '29', '168', '192', '6020', '1368471789', '0', '3fd4ce4a86719d713cde763cea3a95a1');
INSERT INTO download_photo VALUES ('192', '29', '168', '193', '6021', '1368471789', '1', '1bb27dbc403b9dd256b0328559aaad57');
INSERT INTO download_photo VALUES ('193', '29', '169', '194', '5986', '1368473114', '0', 'ed7fd5baea6d21d8e3ad94eed8e9ca1a');
INSERT INTO download_photo VALUES ('194', '29', '169', '195', '5990', '1368473114', '0', 'c0dafa82aeba204c209d48d08f29f791');
INSERT INTO download_photo VALUES ('195', '29', '169', '196', '5991', '1368473114', '0', '4bed12b14841dbb47e3dcad578564954');
INSERT INTO download_photo VALUES ('196', '29', '171', '197', '5986', '1368473441', '0', '37f72929c295a1d4aa44c165ac62de93');
INSERT INTO download_photo VALUES ('197', '29', '172', '198', '5986', '1368812447', '0', 'a7dc611427fa374701435a713aa26ea5');
INSERT INTO download_photo VALUES ('198', '29', '172', '199', '5990', '1368812447', '0', '584a4701d9163fc9ad744dbc0df8fcaa');
INSERT INTO download_photo VALUES ('199', '29', '172', '200', '6045', '1368812447', '0', '7fad2c6c82c5c2c63810108e442fe133');
INSERT INTO download_photo VALUES ('200', '29', '172', '201', '6046', '1368812447', '0', '171b269c1925f6b86a0e391b4f716d12');
INSERT INTO download_photo VALUES ('201', '29', '172', '202', '6047', '1368812447', '1', '831cd5bdbaf1140b53faeb8f863a5f20');
INSERT INTO download_photo VALUES ('202', '29', '172', '203', '6048', '1368812447', '0', 'b93703543dc1cf8cfc6224c5064286f4');
INSERT INTO download_photo VALUES ('203', '29', '172', '204', '6053', '1368812447', '0', '553a55acad790765cdcc59ca8842b437');
INSERT INTO download_photo VALUES ('204', '29', '172', '205', '6055', '1368812447', '0', '0b7c2a74dc4242ca6cec6b15c299451a');
INSERT INTO download_photo VALUES ('205', '29', '172', '206', '6056', '1368812447', '0', '3a395fa2f11f97978a7f6398903b4d14');
INSERT INTO download_photo VALUES ('206', '29', '172', '207', '6059', '1368812447', '0', '9cc86d067f97ec162b7d8c92deb2a087');
INSERT INTO download_photo VALUES ('207', '29', '172', '208', '6060', '1368812447', '0', '3b7f6273a301474b4fbb2c4f1edb05a3');
INSERT INTO download_photo VALUES ('208', '29', '172', '209', '6061', '1368812447', '0', '718c8397ccfc310a4fd52e7eb4a4f5f3');
INSERT INTO download_photo VALUES ('209', '29', '172', '210', '6063', '1368812447', '0', 'd13df99d68819639f65748818ff5fd79');
INSERT INTO download_photo VALUES ('210', '29', '172', '211', '6065', '1368812447', '0', '34476fdb6ebd3e8d8f76eae308708551');
INSERT INTO download_photo VALUES ('211', '29', '172', '212', '6072', '1368812447', '0', 'a7c0f0f31f3840e9cb8719dd421c02e5');
INSERT INTO download_photo VALUES ('212', '29', '172', '213', '6073', '1368812447', '0', '1c36f84fd64226d37af80995d7e95542');
INSERT INTO download_photo VALUES ('213', '29', '172', '214', '6075', '1368812447', '0', '3a7294d37ebd5490e4b999cc90a3a291');
INSERT INTO download_photo VALUES ('214', '29', '172', '215', '6076', '1368812447', '0', '6767b987e24b2318cddaeb16807a593f');
INSERT INTO download_photo VALUES ('215', '29', '172', '216', '6080', '1368812447', '0', '62fbc4e5148f6d50d92f45672081e087');
INSERT INTO download_photo VALUES ('216', '29', '172', '217', '6083', '1368812447', '0', '34427b967de4580bf65f7669aaf5bc36');
INSERT INTO download_photo VALUES ('217', '29', '172', '218', '0', '1368812447', '0', '0583f1080a2445d53cee6ff59fd348e2');
INSERT INTO download_photo VALUES ('218', '29', '172', '219', '0', '1368812447', '0', '8a47d83d1ceed002aa2edf31206cf862');
INSERT INTO download_photo VALUES ('219', '29', '172', '220', '0', '1368812447', '0', '94a8d575793597346cb0bff26f2e4a1b');
INSERT INTO download_photo VALUES ('220', '29', '173', '221', '6006', '1368812963', '0', '109969b83f05884aa0fe286fc526b6ad');
INSERT INTO download_photo VALUES ('221', '29', '173', '222', '6007', '1368812963', '0', '597097b9e3c273b072ea10f34c03f876');
INSERT INTO download_photo VALUES ('222', '29', '173', '223', '6008', '1368812963', '0', '03eb3e809073d682a97e69d273f33b9d');
INSERT INTO download_photo VALUES ('223', '29', '173', '224', '6009', '1368812963', '1', 'ab7eb5dbe4ca9e008f0c1058d582757b');
INSERT INTO download_photo VALUES ('224', '29', '173', '225', '6010', '1368812963', '0', '84804ed72f2ac132df2f578eb00b5916');
INSERT INTO download_photo VALUES ('225', '29', '173', '226', '6012', '1368812963', '1', '0a3889a1182e333981e4dd7df6463b8a');
INSERT INTO download_photo VALUES ('226', '29', '173', '227', '6013', '1368812963', '0', '1553e4310a83a9d79a9be45816acc44d');
INSERT INTO download_photo VALUES ('227', '29', '173', '228', '6014', '1368812963', '0', '90aa26d5dccd970bbc52d38a80762229');
INSERT INTO download_photo VALUES ('228', '29', '173', '229', '6083', '1368812963', '0', '149266db05c638fd0e179833aa869a03');
INSERT INTO download_photo VALUES ('229', '29', '173', '230', '6084', '1368812963', '0', '5e35c9b163befa7e502de4f1bc181d67');
INSERT INTO download_photo VALUES ('230', '29', '173', '231', '0', '1368812963', '0', '159334eb5bb58a24eef6fedf8919a76a');
INSERT INTO download_photo VALUES ('231', '29', '173', '232', '0', '1368812963', '0', 'd0625e8c7b72477a7dfb584a2778b32c');
INSERT INTO download_photo VALUES ('232', '29', '173', '233', '0', '1368812963', '0', '91e0dbe60bb39a4eda4205b7ace76f61');
INSERT INTO download_photo VALUES ('233', '29', '13', '234', '6005', '1369392247', '1', '4dfa4f0dc5d56c05321d69a5daf3eb6a');
INSERT INTO download_photo VALUES ('234', '29', '13', '235', '6006', '1369392247', '0', 'abf4e44175912f28285a8e90a8bb1312');
INSERT INTO download_photo VALUES ('235', '29', '13', '236', '6007', '1369392247', '0', '6747da2bb7d7a0f27ddb7d8c75c31d01');
INSERT INTO download_photo VALUES ('236', '29', '13', '237', '6008', '1369392247', '0', '45bdeaabcf5563308dba168ab9d5ca2e');
INSERT INTO download_photo VALUES ('237', '29', '13', '238', '0', '1369392247', '0', 'ed79aeed5ea469e6e8671680a22c6b29');
INSERT INTO download_photo VALUES ('238', '29', '13', '239', '0', '1369392247', '0', '454198f3c514ba890a6bf5747ebbee6a');
INSERT INTO download_photo VALUES ('239', '29', '13', '240', '0', '1369392247', '0', 'ca8f96f93fd33bb13aaad30e0ecab259');
INSERT INTO download_photo VALUES ('240', '29', '15', '241', '6006', '1369393916', '0', '69e177670da2112c50fbdd597beb4201');
INSERT INTO download_photo VALUES ('241', '29', '15', '242', '0', '1369393916', '0', '91c73cfe5d5842391e59317b83b98644');
INSERT INTO download_photo VALUES ('242', '29', '15', '243', '0', '1369393916', '0', '981d1ba75e3c3a9f322413e33ee83dd8');
INSERT INTO download_photo VALUES ('243', '29', '15', '244', '0', '1369393916', '0', '5c8ea8eee84312fbfa70bf36f39b256e');
INSERT INTO download_photo VALUES ('244', '29', '17', '245', '5990', '1369394337', '0', 'fb76964c13df5752d1cc3ec2794e854b');
INSERT INTO download_photo VALUES ('245', '29', '17', '246', '0', '1369394337', '0', 'c1fa8269364881bf10abd4a636a0cabd');
INSERT INTO download_photo VALUES ('246', '29', '17', '247', '0', '1369394337', '0', '6fce608ef6f2733dd24bc3151ca10ed0');
INSERT INTO download_photo VALUES ('247', '29', '17', '248', '0', '1369394337', '0', '9ba4fdba278d8b977f9a04bc4c31dd91');
INSERT INTO download_photo VALUES ('248', '29', '17', '249', '5986', '1369394337', '0', '649cc4ca1c9acfb9474a0e958f3a5c13');
INSERT INTO download_photo VALUES ('249', '29', '18', '250', '5986', '1369394569', '0', '175c8b037f60bd8858fcd386457e1d07');
INSERT INTO download_photo VALUES ('250', '29', '18', '251', '0', '1369394569', '0', '7c7a79d9f1df66c8a3aac7dce30280c4');
INSERT INTO download_photo VALUES ('251', '29', '18', '252', '0', '1369394569', '0', '1dcd4324fb3281acc80e7fa4e733eca5');
INSERT INTO download_photo VALUES ('252', '29', '18', '253', '0', '1369394569', '0', '45f0c8a8195888940edea347e181dbce');
INSERT INTO download_photo VALUES ('253', '29', '28', '254', '5986', '1369397585', '0', 'a16996fbeedcedb853b27fa1ceceb6ad');
INSERT INTO download_photo VALUES ('254', '29', '28', '255', '0', '1369397585', '0', '2ae1c686fbede5f42a45e50a401e31c8');
INSERT INTO download_photo VALUES ('255', '29', '28', '256', '0', '1369397585', '0', '423eb50b085822edc506401b8e69f6e4');
INSERT INTO download_photo VALUES ('256', '29', '28', '257', '0', '1369397585', '0', 'a7ff946fcae8841d8c09787818def8d1');
INSERT INTO download_photo VALUES ('257', '29', '30', '258', '5986', '1369397952', '0', '245232e212b17c22a73be618dc5640cf');
INSERT INTO download_photo VALUES ('258', '29', '30', '259', '0', '1369397952', '0', '8b761bb4540f5828781178ea39f9624d');
INSERT INTO download_photo VALUES ('259', '29', '30', '260', '0', '1369397952', '0', '802a98117aae8173e9770e46fb57e445');
INSERT INTO download_photo VALUES ('260', '29', '30', '261', '0', '1369397952', '0', '514e5dade0ea704fecc7bffcdc9975d4');
INSERT INTO download_photo VALUES ('261', '29', '37', '262', '5986', '1369398286', '0', '50e9071b506ac3bb1d9d57d7d08c9de2');
INSERT INTO download_photo VALUES ('262', '29', '37', '263', '0', '1369398286', '0', 'f414d6861b0c2ba17708e74b8e6429b1');
INSERT INTO download_photo VALUES ('263', '29', '37', '264', '0', '1369398286', '0', '883d6f7429cdca54ce84ace7ef465355');
INSERT INTO download_photo VALUES ('264', '29', '37', '265', '0', '1369398286', '0', '5d5e539218074602e02ee1eb541fb611');
INSERT INTO download_photo VALUES ('265', '29', '37', '266', '5990', '1369398286', '0', '4d0d428cc62d401d7a74ae11bb9d606f');
INSERT INTO download_photo VALUES ('266', '29', '39', '267', '5986', '1369398376', '0', '6e1ab24414f6782f7ec3fbd87575b576');
INSERT INTO download_photo VALUES ('267', '29', '39', '268', '0', '1369398376', '0', 'e3620a2fb349c10e68c82d268f12e023');
INSERT INTO download_photo VALUES ('268', '29', '39', '269', '0', '1369398376', '0', 'cf869487209f8a3bdd59b1e385f3a636');
INSERT INTO download_photo VALUES ('269', '29', '39', '270', '0', '1369398376', '0', '76744788b14cdf9cc543d7eb9d078440');
INSERT INTO download_photo VALUES ('270', '29', '39', '271', '5990', '1369398376', '0', '36618efca1a7f3644a0c14bb0a06e71f');
INSERT INTO download_photo VALUES ('271', '29', '42', '272', '5983', '1369403195', '0', 'f2c06a18f229572dede66fd51b667659');
INSERT INTO download_photo VALUES ('272', '29', '42', '273', '0', '1369403195', '0', 'e8cb8fb6895d2afb748724278225f23c');
INSERT INTO download_photo VALUES ('273', '29', '42', '274', '0', '1369403195', '0', 'c30988a54400d1660d345b9b895fb9ab');
INSERT INTO download_photo VALUES ('274', '29', '42', '275', '0', '1369403195', '0', '4ed4c1a5ecb52c5a3b94af6bd0d76f71');
INSERT INTO download_photo VALUES ('275', '29', '43', '276', '5983', '1369403222', '0', 'fda06ce7ff95a4ca6d139cf5a1e85080');
INSERT INTO download_photo VALUES ('276', '29', '43', '277', '0', '1369403222', '0', 'c7feed08aab5dcef5bf43b939d1c3e49');
INSERT INTO download_photo VALUES ('277', '29', '43', '278', '0', '1369403222', '0', 'da871dd75e3c0c72beaeebbe100273a4');
INSERT INTO download_photo VALUES ('278', '29', '43', '279', '0', '1369403222', '0', '267e144ac899503af396f6abb457b851');
INSERT INTO download_photo VALUES ('279', '29', '44', '280', '5986', '1369403975', '0', '717cd5084404f11bb766b2292ab6764b');
INSERT INTO download_photo VALUES ('280', '29', '44', '281', '0', '1369403975', '0', '076fb924e6fac6076b9b36e2ac162e32');
INSERT INTO download_photo VALUES ('281', '29', '44', '282', '0', '1369403975', '0', 'e0a2192532ba91639cb850d828e66fd7');
INSERT INTO download_photo VALUES ('282', '29', '44', '283', '0', '1369403975', '0', 'c932acf1d89e63f82c4a62d1e2087c28');
INSERT INTO download_photo VALUES ('283', '29', '45', '284', '5986', '1369404001', '0', 'eec9cd131bb48b7dd329e67a2a5c96cc');
INSERT INTO download_photo VALUES ('284', '29', '45', '285', '0', '1369404001', '0', 'ac2cb651c8b11c233211fba2991981a6');
INSERT INTO download_photo VALUES ('285', '29', '45', '286', '0', '1369404001', '0', 'd564cd5c5ac162fdf13adc7cdf5e2a7d');
INSERT INTO download_photo VALUES ('286', '29', '45', '287', '0', '1369404001', '0', 'd67f6eea7c5d8d2e34c5055759228f69');
INSERT INTO download_photo VALUES ('287', '29', '46', '288', '5986', '1369404620', '0', '68ca44b91c2f9cd271314f6e24d80190');
INSERT INTO download_photo VALUES ('288', '29', '46', '289', '0', '1369404620', '0', 'e4d7fee77dbeb54f7d43a6aa31e77fb1');
INSERT INTO download_photo VALUES ('289', '29', '46', '290', '0', '1369404620', '0', '46dddb1321c63b4af07926d5d8957cb1');
INSERT INTO download_photo VALUES ('290', '29', '46', '291', '0', '1369404620', '0', '0193e99fe29a62dca86500b7e49bf1e5');
INSERT INTO download_photo VALUES ('291', '29', '47', '292', '5986', '1369404838', '0', '23201e6750b94d419d63fff8a3d0b0f9');
INSERT INTO download_photo VALUES ('292', '29', '47', '293', '0', '1369404838', '0', '57aecbe96d8f10b14f266cccfb1b0867');
INSERT INTO download_photo VALUES ('293', '29', '47', '294', '0', '1369404838', '0', 'b10aae40e4f98bbdecb3c60f19f6d57a');
INSERT INTO download_photo VALUES ('294', '29', '47', '295', '0', '1369404838', '0', '8361951495d82a931c72fd244b00d9bc');
INSERT INTO download_photo VALUES ('295', '29', '48', '296', '5983', '1369404867', '0', '3ee0511eacd9a498fc545416f79e434f');
INSERT INTO download_photo VALUES ('296', '29', '48', '297', '0', '1369404867', '0', 'd9d4380530b624ea8580cca4767a2396');
INSERT INTO download_photo VALUES ('297', '29', '48', '298', '0', '1369404867', '0', 'b0fd74952909d7b720be62c55c1d60a5');
INSERT INTO download_photo VALUES ('298', '29', '48', '299', '0', '1369404867', '0', 'cce823b6af2711791d3e154609817ab6');
INSERT INTO download_photo VALUES ('299', '29', '49', '300', '5983', '1369404983', '0', '537f096508307df07259131846630330');
INSERT INTO download_photo VALUES ('300', '29', '49', '301', '0', '1369404983', '0', 'e615f38ab6a9a59c2b5705be909691bd');
INSERT INTO download_photo VALUES ('301', '29', '49', '302', '0', '1369404983', '0', '4ff7d48153741650339ed07c80a77ad6');
INSERT INTO download_photo VALUES ('302', '29', '49', '303', '0', '1369404983', '0', 'ac7f34e3834d27f97444f6dedf648915');
INSERT INTO download_photo VALUES ('303', '29', '50', '304', '5986', '1369405348', '0', '9c9477dab1aa9de6e00e410d4c00b9ff');
INSERT INTO download_photo VALUES ('304', '29', '50', '305', '0', '1369405348', '0', 'd4b9267b53b71dc46c9a4add8cfa6399');
INSERT INTO download_photo VALUES ('305', '29', '50', '306', '0', '1369405348', '0', 'b1b5f2a577be58905115e23a3144e240');
INSERT INTO download_photo VALUES ('306', '29', '50', '307', '0', '1369405348', '0', '0ec59c68c5f747016d6dce91f6200342');
INSERT INTO download_photo VALUES ('307', '29', '51', '308', '5986', '1369405574', '0', '5de76a44e88dad592252331b54fba5a5');
INSERT INTO download_photo VALUES ('308', '29', '51', '309', '0', '1369405574', '0', 'cb224046b8a3753532007b8c7841e7cb');
INSERT INTO download_photo VALUES ('309', '29', '51', '310', '0', '1369405574', '0', '222f46375eb708eba1903ccbca2ed694');
INSERT INTO download_photo VALUES ('310', '29', '51', '311', '0', '1369405574', '0', 'ff475cffe0536d78194020cb8815c0cd');
INSERT INTO download_photo VALUES ('311', '29', '52', '312', '5986', '1369405682', '0', 'fbb3b4a26f6b07db2f8c4c0173f48523');
INSERT INTO download_photo VALUES ('312', '29', '52', '313', '0', '1369405682', '0', 'b13b95d32025cffa332f62708b3d363c');
INSERT INTO download_photo VALUES ('313', '29', '52', '314', '0', '1369405682', '0', '391a93a9e6c823bd7dd68b31b5d6305c');
INSERT INTO download_photo VALUES ('314', '29', '52', '315', '0', '1369405682', '0', 'dd6b125a52b36ce3e476ce898e052920');
INSERT INTO download_photo VALUES ('315', '29', '53', '316', '5982', '1369405907', '0', '02d0905fa3c43ac0f954410f27ca44be');
INSERT INTO download_photo VALUES ('316', '29', '53', '317', '0', '1369405907', '0', 'e9a4da61a3c61144006d79655787af43');
INSERT INTO download_photo VALUES ('317', '29', '53', '318', '0', '1369405907', '0', '2ab4580f38eddb04f2f4f0c6dc9bd023');
INSERT INTO download_photo VALUES ('318', '29', '53', '319', '0', '1369405907', '0', 'c1d61243da86c22d002b43049a8bed1e');
INSERT INTO download_photo VALUES ('319', '29', '54', '320', '5986', '1369426295', '0', 'a9a8ffce1a4b84faa742bbac8cd33395');
INSERT INTO download_photo VALUES ('320', '29', '54', '321', '5990', '1369426295', '0', '854d85775d8d52d1747a5f9180b44617');
INSERT INTO download_photo VALUES ('321', '29', '54', '322', '0', '1369426295', '0', '9a58d16f66b112b5dcc5b1aeb640cc0f');
INSERT INTO download_photo VALUES ('322', '29', '54', '323', '0', '1369426295', '0', '49df301e8ab444268f3ddbe37e92c228');
INSERT INTO download_photo VALUES ('323', '29', '54', '324', '0', '1369426295', '0', 'fd3ab8bb8bf4bf8b4b5b8256e70210c1');
INSERT INTO download_photo VALUES ('324', '29', '55', '325', '5990', '1369426760', '0', '6b6893e9b55a9d737daa1fc757caee71');
INSERT INTO download_photo VALUES ('325', '29', '55', '326', '0', '1369426760', '0', '375d5a92bd37d4018910eb6f14a8f68b');
INSERT INTO download_photo VALUES ('326', '29', '55', '327', '0', '1369426760', '0', '450fa707eeac58bac1a09bc58a719eda');
INSERT INTO download_photo VALUES ('327', '29', '55', '328', '0', '1369426760', '0', 'c7a4215fea8b994c87ff374ef28c0cf4');
INSERT INTO download_photo VALUES ('328', '29', '56', '329', '5990', '1369427107', '0', 'b24cebd38f6f8c926454939cb55d0bdf');
INSERT INTO download_photo VALUES ('329', '29', '56', '330', '0', '1369427107', '0', '58a733a8209bef82f3f68f3d792378f9');
INSERT INTO download_photo VALUES ('330', '29', '56', '331', '0', '1369427107', '0', 'd28981448099dfa1c2bf46528b4e0456');
INSERT INTO download_photo VALUES ('331', '29', '56', '332', '0', '1369427107', '0', 'b12f1919c7f081f9848192b1bec8bfa0');
INSERT INTO download_photo VALUES ('332', '29', '57', '333', '5990', '1369427472', '0', '7f5f78a8f02f3cd7bfeda69ff463e140');
INSERT INTO download_photo VALUES ('333', '29', '57', '334', '0', '1369427472', '0', 'ed77730065d3d6e20dfc9ea20cc886d8');
INSERT INTO download_photo VALUES ('334', '29', '57', '335', '0', '1369427472', '0', '14f7320ed6aad7297cc40dd8aa101762');
INSERT INTO download_photo VALUES ('335', '29', '57', '336', '0', '1369427472', '0', '6b7de024a36c7978e2a8d72ee8c1125c');
INSERT INTO download_photo VALUES ('336', '29', '58', '337', '5986', '1369427605', '0', 'ca8cb8a614d8a3c66229565edd8707aa');
INSERT INTO download_photo VALUES ('337', '29', '58', '338', '0', '1369427605', '0', '17329007c37521c00e5d6005cd6ce03e');
INSERT INTO download_photo VALUES ('338', '29', '58', '339', '0', '1369427605', '0', 'b66cddfd2c5e818845c6ef06b33675b9');
INSERT INTO download_photo VALUES ('339', '29', '58', '340', '0', '1369427605', '0', '576c5542fcf3457adac54a1fc9577159');
INSERT INTO download_photo VALUES ('340', '29', '59', '341', '5990', '1369462898', '0', '1fadd2b34e21d916c6b4d59b3bbef757');
INSERT INTO download_photo VALUES ('341', '29', '60', '342', '6106', '1369464337', '0', 'db75404d2d16f6490db870961e8eeb42');
INSERT INTO download_photo VALUES ('342', '29', '61', '343', '5986', '1369464536', '0', '8c813901f11c3db3287f03ff375e591c');
INSERT INTO download_photo VALUES ('343', '29', '62', '344', '5983', '1369466365', '0', '7cd28a87030594e51a3e1a558535b321');
INSERT INTO download_photo VALUES ('344', '29', '63', '345', '5990', '1369466547', '0', '1d809c160b8ff72a56ef6ac6f662dbcb');
INSERT INTO download_photo VALUES ('345', '29', '64', '346', '5983', '1369466717', '0', 'f2a5ea675e3b57b5e172a11f54a27557');
INSERT INTO download_photo VALUES ('346', '29', '64', '347', '5986', '1369466717', '0', '99e5a378336a370a997e8648a2e33b34');
INSERT INTO download_photo VALUES ('347', '29', '64', '348', '5990', '1369466717', '0', '5137aff9c3e8f803f729efdfbb86296c');
INSERT INTO download_photo VALUES ('348', '29', '64', '349', '5991', '1369466717', '0', 'e45b1fc0ebafd4936f802a6c83df2e95');
INSERT INTO download_photo VALUES ('349', '29', '65', '350', '5983', '2013', '0', 'bf554728f7fe02cafb4c05abf4c5a1ab');
INSERT INTO download_photo VALUES ('350', '29', '65', '351', '5986', '2013', '0', '846dc8d1c00679747fe5d7a8e6e8f322');
INSERT INTO download_photo VALUES ('351', '29', '65', '352', '5990', '2013', '0', 'c6dc28dcda818352529c6a762c41b79a');
INSERT INTO download_photo VALUES ('352', '29', '197', '353', '5986', '1371043193', '2', '22028886c01eee8658d2313d573fadb3');
INSERT INTO download_photo VALUES ('353', '59', '198', '354', '6673', '1372854443', '1', 'e41627015348dd88f3a66beb43130176');
INSERT INTO download_photo VALUES ('354', '59', '199', '355', '6883', '1375972456', '1', 'ba470c1738d913da9939a2505db2c23e');
INSERT INTO download_photo VALUES ('355', '59', '200', '356', '6891', '1376071840', '1', '1b8308c1b64bc5a65b6ebde50296c06d');
INSERT INTO download_photo VALUES ('356', '59', '200', '357', '6893', '1376071840', '1', '7359fc30753cddc895614785f7616e5a');
INSERT INTO download_photo VALUES ('357', '59', '200', '358', '6895', '1376071840', '0', '812f68ba76e0634ac8c5df7900aa34fa');
INSERT INTO download_photo VALUES ('358', '59', '201', '359', '6885', '1376072003', '1', 'dead9d8ae3ba5e026d4b4e7a79ab1a38');


#
# Table structure for table `komments`
#

DROP TABLE IF EXISTS `komments`;
CREATE TABLE `komments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `news_id` int(11) NOT NULL COMMENT 'принадлежность',
  `parents_id` int(11) DEFAULT NULL COMMENT 'к какому родителю принадлежит',
  `text` varchar(180) NOT NULL COMMENT 'коментарий',
  `user_id` varchar(40) DEFAULT NULL COMMENT 'кто коментировал, ставиться если есть регистрация',
  `data` int(11) NOT NULL COMMENT 'дата коментария',
  `email_komm` varchar(64) NOT NULL COMMENT 'почта',
  `us_name_komm` varchar(64) NOT NULL COMMENT 'Имя',
  `url_komm` varchar(64) NOT NULL COMMENT 'Сайт пользователя ',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=121 DEFAULT CHARSET=utf8;

#
# Dumping data for table `komments`
#

INSERT INTO komments VALUES ('1', '1', '0', 'чсячсячсячс', '59', '1360402078', 'aleksjurii@gmail.com', 'test', 'yt.yuyu');
INSERT INTO komments VALUES ('97', '1', '1', '<strong><em>ячсчсячдж</em></strong>', '', '1377626737', 'aleksjurii@gmail.com', 'Jurii', 'http://www.aleks.od.ua');
INSERT INTO komments VALUES ('120', '2', '115', 'прпрпрпрп прпрпр', '', '1377636099', 'aleksjurii@gmail.com', 'Jurii', 'http://www.aleks.od.ua');
INSERT INTO komments VALUES ('115', '2', '0', 'митпртпмрпмр', '', '1377631588', 'aleksjurii@gmail.com', 'Jurii', 'http://www.aleks.od.ua');
INSERT INTO komments VALUES ('117', '2', '0', 'я\\фвывячсмсчррое
ролпрло', '', '1377631603', 'aleksjurii@gmail.com', 'Jurii', 'http://www.aleks.od.ua');


#
# Table structure for table `nastr`
#

DROP TABLE IF EXISTS `nastr`;
CREATE TABLE `nastr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param_index` varchar(64) NOT NULL,
  `param_name` varchar(64) NOT NULL,
  `param_value` varchar(64) NOT NULL,
  `param_descr` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `param_name` (`param_name`)
) ENGINE=MyISAM AUTO_INCREMENT=1117 DEFAULT CHARSET=cp1251 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

#
# Dumping data for table `nastr`
#

INSERT INTO nastr VALUES ('1', '0', 'ftp_host', '192.168.1.232', 'FTP-хост фотобанка:');
INSERT INTO nastr VALUES ('2', '0', 'ftp_user', 'add', 'FTP-пользователь фотобанка:');
INSERT INTO nastr VALUES ('3', '0', 'ftp_pass', 'Foto_arhiv_27', 'FTP-пароль фотобанка:');
INSERT INTO nastr VALUES ('4', '1', 'nm_pocta', 'Новая  почта', 'Название почтового отделения №1:');
INSERT INTO nastr VALUES ('5', '1', 'http_pocta', 'http://novaposhta.ua/frontend/calculator/ru', 'Электронный адресс почтового отделения № 1:');
INSERT INTO nastr VALUES ('14', '2', 'dostavka', 'Самовывоз из студии (в Одессе)', 'Доставка №2');
INSERT INTO nastr VALUES ('15', '3', 'dostavka', 'Самовывоз из почтового отделения Вашего города', 'Доставка №3');
INSERT INTO nastr VALUES ('16', '4', 'dostavka', 'Доставка до двери почтовой службой (кроме Одессы)', 'Доставка №4');
INSERT INTO nastr VALUES ('6', '2', 'nm_pocta', 'Укрпочта', 'Название почтового отделения №2:');
INSERT INTO nastr VALUES ('7', '2', 'http_pocta', 'http://services.ukrposhta.com/CalcUtil/PostalMails.aspx', 'Электронный адресс почтового отделения № 2:');
INSERT INTO nastr VALUES ('20', '1', 'adr_pecat', 'Одесса, ул.Ленина 48', 'Адресс студии печати №1:');
INSERT INTO nastr VALUES ('21', '1', 'ftp_pecat_host', '91.90.9.27', 'FTP-хост студии №1:');
INSERT INTO nastr VALUES ('22', '1', 'ftp_pecat_user', 'Alekseeva', 'FTP-пользователь студии №1:');
INSERT INTO nastr VALUES ('23', '1', 'ftp_pecat_pass', 'Alekseeva', 'FTP-пароль студии №1:');
INSERT INTO nastr VALUES ('9', '1', 'oplata', 'пополнение баланса сайта', 'Вид оплаты №1');
INSERT INTO nastr VALUES ('10', '2', 'oplata', 'наложенный платеж', 'Вид оплаты №2');
INSERT INTO nastr VALUES ('13', '1', 'dostavka', 'Передать тренеру команды (в Одессе при полной предоплате)', 'Доставка №1');
INSERT INTO nastr VALUES ('12', '3', 'oplata', 'другое', 'Вид оплаты №4');
INSERT INTO nastr VALUES ('18', '6', 'dostavka', 'другое', 'Доставка №6');
INSERT INTO nastr VALUES ('24', '2', 'adr_pecat', 'Одесса, ул.Пушкинская (напротив цума)', 'Адресс студии печати №2:');
INSERT INTO nastr VALUES ('25', '2', 'ftp_pecat_host', '94.158.147.163', 'FTP-хост студии №2:');
INSERT INTO nastr VALUES ('26', '2', 'ftp_pecat_user', 'Alexeeva', 'FTP-пользователь студии №2:');
INSERT INTO nastr VALUES ('27', '2', 'ftp_pecat_pass', 'alex2013', 'FTP-пароль студии №2:');
INSERT INTO nastr VALUES ('17', '5', 'dostavka', 'Самовывоз от фотографа', 'Доставка №5');


#
# Table structure for table `news`
#

DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(75) NOT NULL COMMENT 'Название публикации',
  `head` text NOT NULL COMMENT 'публикация шапка',
  `body` text NOT NULL COMMENT 'публикация тело за кнопкой далее',
  `avtor-pub` varchar(75) NOT NULL COMMENT 'Кто опубликовал',
  `img` varchar(75) NOT NULL COMMENT 'адрес картинки',
  `on-cit` int(1) DEFAULT '0' COMMENT 'отключить вывод цитаты',
  `citata` varchar(75) NOT NULL COMMENT 'цитата',
  `avtor-cit` varchar(75) NOT NULL COMMENT 'автор высказывания',
  `date` varchar(20) NOT NULL COMMENT 'дата публикации',
  `komm` int(1) DEFAULT '1' COMMENT 'отключить вывод комментарий',
  `pros` int(11) DEFAULT '0' COMMENT 'количество просмотров',
  `kolonka` enum('l_colonka','c_colonka','r_colonka') NOT NULL DEFAULT 'c_colonka' COMMENT 'в какой колонке разместить',
  `location` set('главная','фотобанк','услуги','цены','контакты','гостевая','регистрация','страничка пользователя') NOT NULL DEFAULT 'главная' COMMENT 'страница размещения',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

#
# Dumping data for table `news`
#

INSERT INTO news VALUES ('1', 'Насколько правил', '<p>Здравствуйте уважаемые посетители нашего сайта!<br />Немного о нас и нашей студии<br />Основное направление нашей творчесской <br />деятельности - фото и видеосъемка свадеб<br />корпоративов и детских мероприятий<br />Профессионально занимаемся полным циклом -<br />от создания творческих идей до<br />их воплощения в жизнь в процессе съемки<br />и последующей обработки отснятого материала<br />Снимаем так же в интерьерах<br />студии в природе и в городе<br />Во время работы стремимся подчеркнуть<br />настроение и индивидуальность моделей<br />В завершающей стадии работы используем<br />цветокор и ретушь а также<br />различные фотоэффекты увеличивающие глубину воздействия<br />на восприятие зрителя дизайнерские приемы<br />в виде применения коллажей замены<br />фона микширования и других эффектов<br />В работе используется фото и<br />видеооборудование марки Саnon Sony и Panasonic<br />Наше творческое кредо &ndash; Всегда!</p>
<p>&nbsp;</p>
<p><span style=\"letter-spacing: 0px; line-height: 1.46em;\">&nbsp;</span></p>', '<p>веб-сайтов, напрямую или косвенно связанные с ними. В частности, иконки этих самых соц-сетей, расхватываются, как горячие пирожки и спрос на них только увеличивается. Русские социальные сети в этом плане, по сравнению веб-сайтов, напрямую или косвенно связанные с ними. В частности, иконки этих самых соц-сетей, расхватываются, как горячие пирожки и спрос на них только увеличивается. Русские социальные сети в этом плане, по сравнению веб-сайтов, напрямую или косвенно связанные с ними. В частности, иконки этих самых соц-сетей, расхватываются, как горячие пирожки и спрос на них только увеличивается. Русские социальные сети в этом плане, по сравнению веб-сайтов, напрямую или косвенно связанные с ними. В частности, иконки этих самых соц-сетей, расхватываются, как горячие пирожки и спрос на них только увеличивается. Русские социальные сети в этом плане, по сравнению веб-сайтов, напрямую или косвенно связанные с ними. В частности, иконки этих самых соц-сетей, расхватываются, как горячие пирожки и спрос на них только увеличивается. Русские социальные сети в этом плане,</p>', 'Jurii', './../reklama/thumb/imgNews-1.jpg', '0', '21222122221222212222', 'Цитата', '13.08.13 14:41', '1', '68', 'l_colonka', 'главная,фотобанк,цены');
INSERT INTO news VALUES ('2', 'Тест 2', '222222222', '2222222', '2шщшщ', './../reklama/thumb/imgNews-2.jpg', '1', '22222', '2щшщ', '13.08.15 14:41', '1', '37', 'r_colonka', 'контакты');


#
# Table structure for table `order_items`
#

DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_order` int(11) NOT NULL DEFAULT '0',
  `id_photo` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id_order` (`id_order`)
) ENGINE=MyISAM AUTO_INCREMENT=360 DEFAULT CHARSET=cp1251;

#
# Dumping data for table `order_items`
#

INSERT INTO order_items VALUES ('89', '63', '2920');
INSERT INTO order_items VALUES ('88', '62', '2908');
INSERT INTO order_items VALUES ('87', '62', '2922');
INSERT INTO order_items VALUES ('86', '62', '2923');
INSERT INTO order_items VALUES ('85', '62', '2924');
INSERT INTO order_items VALUES ('84', '62', '2925');
INSERT INTO order_items VALUES ('83', '61', '2899');
INSERT INTO order_items VALUES ('82', '61', '2924');
INSERT INTO order_items VALUES ('81', '61', '2879');
INSERT INTO order_items VALUES ('93', '63', '2916');
INSERT INTO order_items VALUES ('92', '63', '2917');
INSERT INTO order_items VALUES ('91', '63', '2918');
INSERT INTO order_items VALUES ('90', '63', '2919');
INSERT INTO order_items VALUES ('80', '61', '2881');
INSERT INTO order_items VALUES ('79', '61', '2882');
INSERT INTO order_items VALUES ('78', '60', '2882');
INSERT INTO order_items VALUES ('77', '60', '2878');
INSERT INTO order_items VALUES ('76', '60', '2887');
INSERT INTO order_items VALUES ('75', '60', '2888');
INSERT INTO order_items VALUES ('74', '60', '2895');
INSERT INTO order_items VALUES ('73', '60', '2892');
INSERT INTO order_items VALUES ('72', '60', '2890');
INSERT INTO order_items VALUES ('94', '63', '2915');
INSERT INTO order_items VALUES ('95', '63', '2914');
INSERT INTO order_items VALUES ('96', '63', '2913');
INSERT INTO order_items VALUES ('97', '63', '2912');
INSERT INTO order_items VALUES ('98', '63', '2911');
INSERT INTO order_items VALUES ('99', '63', '2910');
INSERT INTO order_items VALUES ('100', '63', '2909');
INSERT INTO order_items VALUES ('101', '63', '2895');
INSERT INTO order_items VALUES ('102', '64', '2933');
INSERT INTO order_items VALUES ('103', '64', '2932');
INSERT INTO order_items VALUES ('104', '64', '2931');
INSERT INTO order_items VALUES ('105', '65', '2935');
INSERT INTO order_items VALUES ('106', '65', '2934');
INSERT INTO order_items VALUES ('107', '66', '2944');
INSERT INTO order_items VALUES ('108', '66', '2943');
INSERT INTO order_items VALUES ('109', '66', '2942');
INSERT INTO order_items VALUES ('110', '67', '2948');
INSERT INTO order_items VALUES ('111', '67', '2947');
INSERT INTO order_items VALUES ('112', '67', '2946');
INSERT INTO order_items VALUES ('113', '68', '4753');
INSERT INTO order_items VALUES ('114', '68', '4756');
INSERT INTO order_items VALUES ('115', '72', '5285');
INSERT INTO order_items VALUES ('116', '72', '5287');
INSERT INTO order_items VALUES ('117', '72', '5288');
INSERT INTO order_items VALUES ('118', '73', '5352');
INSERT INTO order_items VALUES ('119', '73', '5268');
INSERT INTO order_items VALUES ('120', '74', '5267');
INSERT INTO order_items VALUES ('121', '74', '5266');
INSERT INTO order_items VALUES ('122', '75', '5351');
INSERT INTO order_items VALUES ('123', '75', '5323');
INSERT INTO order_items VALUES ('124', '76', '5267');
INSERT INTO order_items VALUES ('125', '77', '5275');
INSERT INTO order_items VALUES ('126', '82', '5956');
INSERT INTO order_items VALUES ('127', '82', '5982');
INSERT INTO order_items VALUES ('135', '86', '5986');
INSERT INTO order_items VALUES ('134', '86', '6011');
INSERT INTO order_items VALUES ('130', '84', '5956');
INSERT INTO order_items VALUES ('131', '84', '5973');
INSERT INTO order_items VALUES ('132', '85', '5972');
INSERT INTO order_items VALUES ('133', '85', '6166');
INSERT INTO order_items VALUES ('136', '87', '6021');
INSERT INTO order_items VALUES ('137', '87', '6023');
INSERT INTO order_items VALUES ('138', '87', '6025');
INSERT INTO order_items VALUES ('139', '88', '6003');
INSERT INTO order_items VALUES ('183', '155', '5986');
INSERT INTO order_items VALUES ('141', '90', '5983');
INSERT INTO order_items VALUES ('142', '91', '5986');
INSERT INTO order_items VALUES ('143', '92', '5990');
INSERT INTO order_items VALUES ('144', '93', '5990');
INSERT INTO order_items VALUES ('145', '94', '5986');
INSERT INTO order_items VALUES ('146', '95', '6004');
INSERT INTO order_items VALUES ('147', '96', '5986');
INSERT INTO order_items VALUES ('148', '97', '5983');
INSERT INTO order_items VALUES ('149', '98', '5990');
INSERT INTO order_items VALUES ('150', '99', '5982');
INSERT INTO order_items VALUES ('151', '99', '5983');
INSERT INTO order_items VALUES ('152', '99', '5990');
INSERT INTO order_items VALUES ('153', '99', '5991');
INSERT INTO order_items VALUES ('154', '99', '5993');
INSERT INTO order_items VALUES ('155', '99', '6011');
INSERT INTO order_items VALUES ('156', '99', '6012');
INSERT INTO order_items VALUES ('157', '99', '6014');
INSERT INTO order_items VALUES ('158', '99', '5986');
INSERT INTO order_items VALUES ('160', '100', '6492');
INSERT INTO order_items VALUES ('161', '103', '5990');
INSERT INTO order_items VALUES ('162', '104', '5986');
INSERT INTO order_items VALUES ('163', '105', '5990');
INSERT INTO order_items VALUES ('164', '105', '5986');
INSERT INTO order_items VALUES ('165', '105', '6032');
INSERT INTO order_items VALUES ('166', '105', '6101');
INSERT INTO order_items VALUES ('167', '151', '6492');
INSERT INTO order_items VALUES ('168', '151', '5990');
INSERT INTO order_items VALUES ('169', '151', '6158');
INSERT INTO order_items VALUES ('170', '151', '6159');
INSERT INTO order_items VALUES ('171', '151', '6160');
INSERT INTO order_items VALUES ('172', '152', '6004');
INSERT INTO order_items VALUES ('173', '153', '6010');
INSERT INTO order_items VALUES ('174', '153', '5982');
INSERT INTO order_items VALUES ('175', '153', '5990');
INSERT INTO order_items VALUES ('176', '153', '5986');
INSERT INTO order_items VALUES ('177', '153', '6011');
INSERT INTO order_items VALUES ('178', '154', '5986');
INSERT INTO order_items VALUES ('179', '154', '6021');
INSERT INTO order_items VALUES ('180', '154', '6023');
INSERT INTO order_items VALUES ('181', '154', '6025');
INSERT INTO order_items VALUES ('182', '154', '6026');
INSERT INTO order_items VALUES ('184', '156', '6006');
INSERT INTO order_items VALUES ('185', '156', '6007');
INSERT INTO order_items VALUES ('186', '156', '6008');
INSERT INTO order_items VALUES ('187', '157', '6006');
INSERT INTO order_items VALUES ('188', '157', '6008');
INSERT INTO order_items VALUES ('189', '168', '6012');
INSERT INTO order_items VALUES ('190', '168', '6013');
INSERT INTO order_items VALUES ('191', '168', '6014');
INSERT INTO order_items VALUES ('192', '168', '6020');
INSERT INTO order_items VALUES ('193', '168', '6021');
INSERT INTO order_items VALUES ('194', '169', '5986');
INSERT INTO order_items VALUES ('195', '169', '5990');
INSERT INTO order_items VALUES ('196', '169', '5991');
INSERT INTO order_items VALUES ('197', '171', '5986');
INSERT INTO order_items VALUES ('198', '172', '5986');
INSERT INTO order_items VALUES ('199', '172', '5990');
INSERT INTO order_items VALUES ('200', '172', '6045');
INSERT INTO order_items VALUES ('201', '172', '6046');
INSERT INTO order_items VALUES ('202', '172', '6047');
INSERT INTO order_items VALUES ('203', '172', '6048');
INSERT INTO order_items VALUES ('204', '172', '6053');
INSERT INTO order_items VALUES ('205', '172', '6055');
INSERT INTO order_items VALUES ('206', '172', '6056');
INSERT INTO order_items VALUES ('207', '172', '6059');
INSERT INTO order_items VALUES ('208', '172', '6060');
INSERT INTO order_items VALUES ('209', '172', '6061');
INSERT INTO order_items VALUES ('210', '172', '6063');
INSERT INTO order_items VALUES ('211', '172', '6065');
INSERT INTO order_items VALUES ('212', '172', '6072');
INSERT INTO order_items VALUES ('213', '172', '6073');
INSERT INTO order_items VALUES ('214', '172', '6075');
INSERT INTO order_items VALUES ('215', '172', '6076');
INSERT INTO order_items VALUES ('216', '172', '6080');
INSERT INTO order_items VALUES ('217', '172', '6083');
INSERT INTO order_items VALUES ('218', '172', '0');
INSERT INTO order_items VALUES ('219', '172', '0');
INSERT INTO order_items VALUES ('220', '172', '0');
INSERT INTO order_items VALUES ('221', '173', '6006');
INSERT INTO order_items VALUES ('222', '173', '6007');
INSERT INTO order_items VALUES ('223', '173', '6008');
INSERT INTO order_items VALUES ('224', '173', '6009');
INSERT INTO order_items VALUES ('225', '173', '6010');
INSERT INTO order_items VALUES ('226', '173', '6012');
INSERT INTO order_items VALUES ('227', '173', '6013');
INSERT INTO order_items VALUES ('228', '173', '6014');
INSERT INTO order_items VALUES ('229', '173', '6083');
INSERT INTO order_items VALUES ('230', '173', '6084');
INSERT INTO order_items VALUES ('231', '173', '0');
INSERT INTO order_items VALUES ('232', '173', '0');
INSERT INTO order_items VALUES ('233', '173', '0');
INSERT INTO order_items VALUES ('234', '13', '6005');
INSERT INTO order_items VALUES ('235', '13', '6006');
INSERT INTO order_items VALUES ('236', '13', '6007');
INSERT INTO order_items VALUES ('237', '13', '6008');
INSERT INTO order_items VALUES ('238', '13', '0');
INSERT INTO order_items VALUES ('239', '13', '0');
INSERT INTO order_items VALUES ('240', '13', '0');
INSERT INTO order_items VALUES ('241', '15', '6006');
INSERT INTO order_items VALUES ('242', '15', '0');
INSERT INTO order_items VALUES ('243', '15', '0');
INSERT INTO order_items VALUES ('244', '15', '0');
INSERT INTO order_items VALUES ('245', '17', '5990');
INSERT INTO order_items VALUES ('246', '17', '0');
INSERT INTO order_items VALUES ('247', '17', '0');
INSERT INTO order_items VALUES ('248', '17', '0');
INSERT INTO order_items VALUES ('249', '17', '5986');
INSERT INTO order_items VALUES ('250', '18', '5986');
INSERT INTO order_items VALUES ('251', '18', '0');
INSERT INTO order_items VALUES ('252', '18', '0');
INSERT INTO order_items VALUES ('253', '18', '0');
INSERT INTO order_items VALUES ('254', '28', '5986');
INSERT INTO order_items VALUES ('255', '28', '0');
INSERT INTO order_items VALUES ('256', '28', '0');
INSERT INTO order_items VALUES ('257', '28', '0');
INSERT INTO order_items VALUES ('258', '30', '5986');
INSERT INTO order_items VALUES ('259', '30', '0');
INSERT INTO order_items VALUES ('260', '30', '0');
INSERT INTO order_items VALUES ('261', '30', '0');
INSERT INTO order_items VALUES ('262', '37', '5986');
INSERT INTO order_items VALUES ('263', '37', '0');
INSERT INTO order_items VALUES ('264', '37', '0');
INSERT INTO order_items VALUES ('265', '37', '0');
INSERT INTO order_items VALUES ('266', '37', '5990');
INSERT INTO order_items VALUES ('267', '39', '5986');
INSERT INTO order_items VALUES ('268', '39', '0');
INSERT INTO order_items VALUES ('269', '39', '0');
INSERT INTO order_items VALUES ('270', '39', '0');
INSERT INTO order_items VALUES ('271', '39', '5990');
INSERT INTO order_items VALUES ('272', '42', '5983');
INSERT INTO order_items VALUES ('273', '42', '0');
INSERT INTO order_items VALUES ('274', '42', '0');
INSERT INTO order_items VALUES ('275', '42', '0');
INSERT INTO order_items VALUES ('276', '43', '5983');
INSERT INTO order_items VALUES ('277', '43', '0');
INSERT INTO order_items VALUES ('278', '43', '0');
INSERT INTO order_items VALUES ('279', '43', '0');
INSERT INTO order_items VALUES ('280', '44', '5986');
INSERT INTO order_items VALUES ('281', '44', '0');
INSERT INTO order_items VALUES ('282', '44', '0');
INSERT INTO order_items VALUES ('283', '44', '0');
INSERT INTO order_items VALUES ('284', '45', '5986');
INSERT INTO order_items VALUES ('285', '45', '0');
INSERT INTO order_items VALUES ('286', '45', '0');
INSERT INTO order_items VALUES ('287', '45', '0');
INSERT INTO order_items VALUES ('288', '46', '5986');
INSERT INTO order_items VALUES ('289', '46', '0');
INSERT INTO order_items VALUES ('290', '46', '0');
INSERT INTO order_items VALUES ('291', '46', '0');
INSERT INTO order_items VALUES ('292', '47', '5986');
INSERT INTO order_items VALUES ('293', '47', '0');
INSERT INTO order_items VALUES ('294', '47', '0');
INSERT INTO order_items VALUES ('295', '47', '0');
INSERT INTO order_items VALUES ('296', '48', '5983');
INSERT INTO order_items VALUES ('297', '48', '0');
INSERT INTO order_items VALUES ('298', '48', '0');
INSERT INTO order_items VALUES ('299', '48', '0');
INSERT INTO order_items VALUES ('300', '49', '5983');
INSERT INTO order_items VALUES ('301', '49', '0');
INSERT INTO order_items VALUES ('302', '49', '0');
INSERT INTO order_items VALUES ('303', '49', '0');
INSERT INTO order_items VALUES ('304', '50', '5986');
INSERT INTO order_items VALUES ('305', '50', '0');
INSERT INTO order_items VALUES ('306', '50', '0');
INSERT INTO order_items VALUES ('307', '50', '0');
INSERT INTO order_items VALUES ('308', '51', '5986');
INSERT INTO order_items VALUES ('309', '51', '0');
INSERT INTO order_items VALUES ('310', '51', '0');
INSERT INTO order_items VALUES ('311', '51', '0');
INSERT INTO order_items VALUES ('312', '52', '5986');
INSERT INTO order_items VALUES ('313', '52', '0');
INSERT INTO order_items VALUES ('314', '52', '0');
INSERT INTO order_items VALUES ('315', '52', '0');
INSERT INTO order_items VALUES ('316', '53', '5982');
INSERT INTO order_items VALUES ('317', '53', '0');
INSERT INTO order_items VALUES ('318', '53', '0');
INSERT INTO order_items VALUES ('319', '53', '0');
INSERT INTO order_items VALUES ('320', '54', '5986');
INSERT INTO order_items VALUES ('321', '54', '5990');
INSERT INTO order_items VALUES ('322', '54', '0');
INSERT INTO order_items VALUES ('323', '54', '0');
INSERT INTO order_items VALUES ('324', '54', '0');
INSERT INTO order_items VALUES ('325', '55', '5990');
INSERT INTO order_items VALUES ('326', '55', '0');
INSERT INTO order_items VALUES ('327', '55', '0');
INSERT INTO order_items VALUES ('328', '55', '0');
INSERT INTO order_items VALUES ('329', '56', '5990');
INSERT INTO order_items VALUES ('330', '56', '0');
INSERT INTO order_items VALUES ('331', '56', '0');
INSERT INTO order_items VALUES ('332', '56', '0');
INSERT INTO order_items VALUES ('333', '57', '5990');
INSERT INTO order_items VALUES ('334', '57', '0');
INSERT INTO order_items VALUES ('335', '57', '0');
INSERT INTO order_items VALUES ('336', '57', '0');
INSERT INTO order_items VALUES ('337', '58', '5986');
INSERT INTO order_items VALUES ('338', '58', '0');
INSERT INTO order_items VALUES ('339', '58', '0');
INSERT INTO order_items VALUES ('340', '58', '0');
INSERT INTO order_items VALUES ('341', '59', '5990');
INSERT INTO order_items VALUES ('342', '60', '6106');
INSERT INTO order_items VALUES ('343', '61', '5986');
INSERT INTO order_items VALUES ('344', '62', '5983');
INSERT INTO order_items VALUES ('345', '63', '5990');
INSERT INTO order_items VALUES ('346', '64', '5983');
INSERT INTO order_items VALUES ('347', '64', '5986');
INSERT INTO order_items VALUES ('348', '64', '5990');
INSERT INTO order_items VALUES ('349', '64', '5991');
INSERT INTO order_items VALUES ('350', '65', '5983');
INSERT INTO order_items VALUES ('351', '65', '5986');
INSERT INTO order_items VALUES ('352', '65', '5990');
INSERT INTO order_items VALUES ('353', '197', '5986');
INSERT INTO order_items VALUES ('354', '198', '6673');
INSERT INTO order_items VALUES ('355', '199', '6883');
INSERT INTO order_items VALUES ('356', '200', '6891');
INSERT INTO order_items VALUES ('357', '200', '6893');
INSERT INTO order_items VALUES ('358', '200', '6895');
INSERT INTO order_items VALUES ('359', '201', '6885');


#
# Table structure for table `order_print`
#

DROP TABLE IF EXISTS `order_print`;
CREATE TABLE `order_print` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_print` int(11) NOT NULL,
  `id_photo` int(11) NOT NULL,
  `koll` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `id_order` (`id_print`)
) ENGINE=MyISAM AUTO_INCREMENT=223 DEFAULT CHARSET=cp1251 COMMENT='Заказы на печать';

#
# Dumping data for table `order_print`
#

INSERT INTO order_print VALUES ('200', '124', '6017', '1');
INSERT INTO order_print VALUES ('199', '123', '6114', '1');
INSERT INTO order_print VALUES ('198', '122', '6059', '1');
INSERT INTO order_print VALUES ('197', '121', '6021', '1');
INSERT INTO order_print VALUES ('196', '120', '5986', '1');
INSERT INTO order_print VALUES ('195', '119', '5990', '1');
INSERT INTO order_print VALUES ('194', '118', '5990', '1');
INSERT INTO order_print VALUES ('193', '117', '5986', '1');
INSERT INTO order_print VALUES ('192', '116', '6008', '2');
INSERT INTO order_print VALUES ('191', '116', '6006', '1');
INSERT INTO order_print VALUES ('190', '115', '5983', '1');
INSERT INTO order_print VALUES ('189', '114', '5983', '1');
INSERT INTO order_print VALUES ('188', '113', '5990', '1');
INSERT INTO order_print VALUES ('187', '112', '6028', '1');
INSERT INTO order_print VALUES ('186', '111', '5986', '1');
INSERT INTO order_print VALUES ('185', '110', '5986', '2');
INSERT INTO order_print VALUES ('184', '109', '5982', '1');
INSERT INTO order_print VALUES ('183', '108', '5986', '1');
INSERT INTO order_print VALUES ('182', '107', '5986', '1');
INSERT INTO order_print VALUES ('181', '106', '6008', '1');
INSERT INTO order_print VALUES ('180', '106', '6007', '1');
INSERT INTO order_print VALUES ('179', '106', '6006', '1');
INSERT INTO order_print VALUES ('178', '106', '6005', '1');
INSERT INTO order_print VALUES ('177', '106', '6004', '1');
INSERT INTO order_print VALUES ('176', '106', '6003', '1');
INSERT INTO order_print VALUES ('175', '106', '5995', '1');
INSERT INTO order_print VALUES ('174', '106', '5993', '1');
INSERT INTO order_print VALUES ('173', '106', '5991', '1');
INSERT INTO order_print VALUES ('172', '106', '5990', '1');
INSERT INTO order_print VALUES ('171', '106', '5986', '1');
INSERT INTO order_print VALUES ('170', '106', '5983', '1');
INSERT INTO order_print VALUES ('169', '105', '6100', '2');
INSERT INTO order_print VALUES ('168', '105', '6098', '1');
INSERT INTO order_print VALUES ('167', '105', '6097', '3');
INSERT INTO order_print VALUES ('166', '104', '5993', '1');
INSERT INTO order_print VALUES ('165', '103', '5986', '1');
INSERT INTO order_print VALUES ('164', '102', '6055', '2');
INSERT INTO order_print VALUES ('163', '102', '6053', '1');
INSERT INTO order_print VALUES ('162', '102', '6048', '6');
INSERT INTO order_print VALUES ('161', '102', '6047', '4');
INSERT INTO order_print VALUES ('160', '102', '6046', '1');
INSERT INTO order_print VALUES ('159', '102', '6039', '3');
INSERT INTO order_print VALUES ('158', '102', '6038', '2');
INSERT INTO order_print VALUES ('157', '102', '6037', '4');
INSERT INTO order_print VALUES ('156', '102', '6033', '1');
INSERT INTO order_print VALUES ('155', '102', '6031', '1');
INSERT INTO order_print VALUES ('154', '102', '6028', '2');
INSERT INTO order_print VALUES ('153', '102', '6026', '1');
INSERT INTO order_print VALUES ('152', '101', '6028', '4');
INSERT INTO order_print VALUES ('151', '101', '6026', '2');
INSERT INTO order_print VALUES ('150', '100', '5995', '1');
INSERT INTO order_print VALUES ('149', '100', '5993', '2');
INSERT INTO order_print VALUES ('148', '100', '5991', '3');
INSERT INTO order_print VALUES ('147', '100', '5990', '4');
INSERT INTO order_print VALUES ('146', '100', '5986', '5');
INSERT INTO order_print VALUES ('145', '99', '6020', '1');
INSERT INTO order_print VALUES ('144', '99', '6017', '1');
INSERT INTO order_print VALUES ('143', '99', '6014', '1');
INSERT INTO order_print VALUES ('142', '99', '6013', '2');
INSERT INTO order_print VALUES ('141', '98', '5990', '1');
INSERT INTO order_print VALUES ('140', '97', '5986', '1');
INSERT INTO order_print VALUES ('139', '96', '5986', '1');
INSERT INTO order_print VALUES ('138', '96', '5990', '1');
INSERT INTO order_print VALUES ('137', '95', '5990', '1');
INSERT INTO order_print VALUES ('136', '94', '5990', '1');
INSERT INTO order_print VALUES ('135', '93', '5990', '1');
INSERT INTO order_print VALUES ('134', '92', '6097', '2');
INSERT INTO order_print VALUES ('133', '92', '5986', '1');
INSERT INTO order_print VALUES ('132', '91', '5986', '1');
INSERT INTO order_print VALUES ('131', '90', '5986', '1');
INSERT INTO order_print VALUES ('130', '89', '5990', '1');
INSERT INTO order_print VALUES ('129', '88', '5990', '1');
INSERT INTO order_print VALUES ('128', '87', '5990', '1');
INSERT INTO order_print VALUES ('127', '86', '5982', '1');
INSERT INTO order_print VALUES ('126', '85', '5982', '1');
INSERT INTO order_print VALUES ('125', '84', '5986', '1');
INSERT INTO order_print VALUES ('124', '84', '5990', '1');
INSERT INTO order_print VALUES ('123', '83', '5986', '1');
INSERT INTO order_print VALUES ('122', '83', '5983', '1');
INSERT INTO order_print VALUES ('121', '82', '5983', '1');
INSERT INTO order_print VALUES ('120', '82', '5982', '1');
INSERT INTO order_print VALUES ('119', '81', '5990', '1');
INSERT INTO order_print VALUES ('118', '81', '5986', '1');
INSERT INTO order_print VALUES ('117', '80', '5983', '1');
INSERT INTO order_print VALUES ('201', '125', '6021', '1');
INSERT INTO order_print VALUES ('202', '125', '5991', '1');
INSERT INTO order_print VALUES ('203', '125', '6023', '1');
INSERT INTO order_print VALUES ('204', '126', '5986', '3');
INSERT INTO order_print VALUES ('205', '126', '5993', '3');
INSERT INTO order_print VALUES ('206', '127', '5990', '1');
INSERT INTO order_print VALUES ('207', '128', '5990', '1');
INSERT INTO order_print VALUES ('208', '129', '6005', '1');
INSERT INTO order_print VALUES ('209', '130', '6005', '1');
INSERT INTO order_print VALUES ('210', '131', '6006', '1');
INSERT INTO order_print VALUES ('211', '132', '6673', '3');
INSERT INTO order_print VALUES ('212', '132', '6675', '5');
INSERT INTO order_print VALUES ('213', '133', '6664', '1');
INSERT INTO order_print VALUES ('214', '134', '6675', '4');
INSERT INTO order_print VALUES ('215', '135', '6664', '5');
INSERT INTO order_print VALUES ('216', '135', '6574', '1');
INSERT INTO order_print VALUES ('217', '136', '6664', '1');
INSERT INTO order_print VALUES ('218', '137', '6664', '1');
INSERT INTO order_print VALUES ('219', '138', '6891', '3');
INSERT INTO order_print VALUES ('220', '138', '6892', '4');
INSERT INTO order_print VALUES ('221', '139', '6886', '1');
INSERT INTO order_print VALUES ('222', '140', '6892', '3');


#
# Table structure for table `orders`
#

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL DEFAULT '0',
  `dt` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=202 DEFAULT CHARSET=cp1251;

#
# Dumping data for table `orders`
#

INSERT INTO orders VALUES ('66', '18', '1360531478', '0');
INSERT INTO orders VALUES ('65', '18', '1360529827', '0');
INSERT INTO orders VALUES ('64', '25', '1360528321', '0');
INSERT INTO orders VALUES ('63', '17', '1360402309', '0');
INSERT INTO orders VALUES ('62', '17', '1360402078', '0');
INSERT INTO orders VALUES ('61', '17', '1360395734', '0');
INSERT INTO orders VALUES ('60', '25', '1360395609', '0');
INSERT INTO orders VALUES ('67', '20', '1360531961', '0');
INSERT INTO orders VALUES ('68', '25', '1361809470', '0');
INSERT INTO orders VALUES ('72', '20', '1364239576', '0');
INSERT INTO orders VALUES ('73', '20', '1364262634', '0');
INSERT INTO orders VALUES ('74', '20', '1364262700', '0');
INSERT INTO orders VALUES ('75', '20', '1364397878', '0');
INSERT INTO orders VALUES ('76', '20', '1364397926', '0');
INSERT INTO orders VALUES ('77', '20', '1364397950', '0');
INSERT INTO orders VALUES ('82', '29', '1367678563', '0');
INSERT INTO orders VALUES ('86', '29', '1367926173', '0');
INSERT INTO orders VALUES ('84', '29', '1367679052', '0');
INSERT INTO orders VALUES ('85', '29', '1367682174', '0');
INSERT INTO orders VALUES ('87', '29', '1368042392', '0');
INSERT INTO orders VALUES ('88', '29', '1368042955', '0');
INSERT INTO orders VALUES ('155', '29', '1368445889', '0');
INSERT INTO orders VALUES ('90', '29', '1368043307', '0');
INSERT INTO orders VALUES ('91', '29', '1368043396', '0');
INSERT INTO orders VALUES ('92', '29', '1368043459', '0');
INSERT INTO orders VALUES ('93', '29', '1368043736', '0');
INSERT INTO orders VALUES ('94', '29', '1368043832', '0');
INSERT INTO orders VALUES ('95', '29', '1368043940', '0');
INSERT INTO orders VALUES ('96', '29', '1368044412', '0');
INSERT INTO orders VALUES ('97', '29', '1368044442', '0');
INSERT INTO orders VALUES ('98', '29', '1368044499', '0');
INSERT INTO orders VALUES ('99', '29', '1368047723', '0');
INSERT INTO orders VALUES ('100', '29', '1368048764', '0');
INSERT INTO orders VALUES ('101', '29', '1368049019', '0');
INSERT INTO orders VALUES ('102', '29', '1368049024', '0');
INSERT INTO orders VALUES ('103', '29', '1368050129', '0');
INSERT INTO orders VALUES ('104', '29', '1368052419', '0');
INSERT INTO orders VALUES ('105', '29', '1368084632', '0');
INSERT INTO orders VALUES ('151', '29', '1368103965', '0');
INSERT INTO orders VALUES ('152', '29', '1368104916', '0');
INSERT INTO orders VALUES ('153', '29', '1368120789', '0');
INSERT INTO orders VALUES ('154', '29', '1368134795', '0');
INSERT INTO orders VALUES ('156', '29', '1368447408', '0');
INSERT INTO orders VALUES ('157', '29', '1368469512', '0');
INSERT INTO orders VALUES ('168', '29', '1368471789', '0');
INSERT INTO orders VALUES ('169', '29', '1368473113', '0');
INSERT INTO orders VALUES ('170', '29', '1368473296', '0');
INSERT INTO orders VALUES ('171', '29', '1368473413', '0');
INSERT INTO orders VALUES ('172', '29', '1368812427', '0');
INSERT INTO orders VALUES ('173', '29', '1368812963', '0');
INSERT INTO orders VALUES ('197', '29', '1371043193', '0');
INSERT INTO orders VALUES ('198', '59', '1372854443', '0');
INSERT INTO orders VALUES ('199', '59', '1375972456', '0');
INSERT INTO orders VALUES ('200', '59', '1376071840', '0');
INSERT INTO orders VALUES ('201', '59', '1376072003', '0');


#
# Table structure for table `photos`
#

DROP TABLE IF EXISTS `photos`;
CREATE TABLE `photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_album` int(11) NOT NULL,
  `nm` varchar(64) NOT NULL,
  `img` varchar(64) NOT NULL,
  `votes` int(11) NOT NULL DEFAULT '0',
  `price` float(8,2) NOT NULL DEFAULT '0.00',
  `pecat` float(8,2) NOT NULL DEFAULT '0.00',
  `pecat_A4` float(8,2) NOT NULL DEFAULT '0.00',
  `ftp_path` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_album` (`id_album`),
  KEY `ind1` (`votes`)
) ENGINE=MyISAM AUTO_INCREMENT=7209 DEFAULT CHARSET=cp1251 COMMENT='Фотографии';

#
# Dumping data for table `photos`
#

INSERT INTO photos VALUES ('7193', '737', '00000', 'id7193.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7192', '737', '00003', 'id7192.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7191', '737', '00002', 'id7191.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7190', '737', '00001', 'id7190.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7189', '737', '00000', 'id7189.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7188', '737', '00003', 'id7188.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7187', '737', '00002', 'id7187.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7186', '737', '00001', 'id7186.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7185', '737', '00000', 'id7185.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7184', '737', '00003', 'id7184.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7183', '737', '00002', 'id7183.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7182', '737', '00001', 'id7182.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7181', '737', '00000', 'id7181.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7180', '737', '00003', 'id7180.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7179', '737', '00002', 'id7179.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7178', '737', '00001', 'id7178.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7177', '737', '00000', 'id7177.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7176', '737', '00003', 'id7176.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7175', '737', '00002', 'id7175.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7174', '737', '00001', 'id7174.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7173', '737', '00000', 'id7173.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7172', '737', '00003', 'id7172.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7171', '737', '00002', 'id7171.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7170', '737', '00001', 'id7170.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7169', '737', '00000', 'id7169.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7168', '737', '00003', 'id7168.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7167', '737', '00002', 'id7167.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7166', '737', '00001', 'id7166.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7165', '737', '00000', 'id7165.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7164', '737', '00003', 'id7164.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7163', '737', '00002', 'id7163.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7162', '737', '00001', 'id7162.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7161', '737', '00000', 'id7161.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7160', '737', '00003', 'id7160.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7159', '737', '00002', 'id7159.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7158', '737', '00001', 'id7158.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7157', '737', '00000', 'id7157.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7156', '737', '00003', 'id7156.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7155', '737', '00002', 'id7155.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7154', '737', '00001', 'id7154.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7153', '737', '00000', 'id7153.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7152', '737', '00003', 'id7152.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7151', '737', '00002', 'id7151.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7150', '737', '00001', 'id7150.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7149', '737', '00000', 'id7149.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7148', '737', '00003', 'id7148.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7147', '737', '00002', 'id7147.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7146', '737', '00001', 'id7146.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7145', '737', '00000', 'id7145.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7144', '737', '00003', 'id7144.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7143', '737', '00002', 'id7143.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7142', '737', '00001', 'id7142.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7141', '737', '00000', 'id7141.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7140', '737', '00003', 'id7140.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7139', '737', '00002', 'id7139.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7138', '737', '00001', 'id7138.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7137', '737', '00000', 'id7137.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7136', '737', '00003', 'id7136.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7135', '737', '00002', 'id7135.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7134', '737', '00001', 'id7134.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7133', '737', '00000', 'id7133.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7132', '737', '00003', 'id7132.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7131', '737', '00002', 'id7131.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7130', '737', '00001', 'id7130.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7129', '737', '00000', 'id7129.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7128', '737', '00003', 'id7128.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7127', '737', '00002', 'id7127.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7126', '737', '00001', 'id7126.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7125', '737', '00000', 'id7125.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7123', '737', '00002', 'id7123.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7122', '737', '00001', 'id7122.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7121', '737', '00000', 'id7121.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7120', '737', '00003', 'id7120.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7119', '737', '00002', 'id7119.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7118', '737', '00001', 'id7118.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7117', '737', '00000', 'id7117.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7116', '737', '00003', 'id7116.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7115', '737', '00002', 'id7115.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7114', '737', '00001', 'id7114.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7113', '737', '00000', 'id7113.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7112', '737', '00003', 'id7112.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7111', '737', '00002', 'id7111.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7110', '737', '00001', 'id7110.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7109', '737', '00000', 'id7109.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7108', '737', '00003', 'id7108.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7107', '737', '00002', 'id7107.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7106', '737', '00001', 'id7106.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7105', '737', '00000', 'id7105.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7104', '737', '00003', 'id7104.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7103', '737', '00002', 'id7103.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7102', '737', '00001', 'id7102.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7101', '737', '00000', 'id7101.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7100', '737', '00003', 'id7100.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7099', '737', '00002', 'id7099.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7098', '737', '00001', 'id7098.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7097', '737', '00000', 'id7097.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7096', '737', '00003', 'id7096.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7095', '737', '00002', 'id7095.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7094', '737', '00001', 'id7094.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7093', '737', '00000', 'id7093.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7092', '737', '00003', 'id7092.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7091', '737', '00002', 'id7091.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7090', '737', '00001', 'id7090.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7089', '737', '00000', 'id7089.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7088', '737', '00003', 'id7088.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7087', '737', '00002', 'id7087.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7086', '737', '00001', 'id7086.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7085', '737', '00000', 'id7085.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7084', '737', '00003', 'id7084.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7083', '737', '00002', 'id7083.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7082', '737', '00001', 'id7082.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7081', '737', '00000', 'id7081.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7080', '737', '00003', 'id7080.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7079', '737', '00002', 'id7079.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7078', '737', '00001', 'id7078.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7077', '737', '00000', 'id7077.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7076', '737', '00003', 'id7076.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7075', '737', '00002', 'id7075.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7074', '737', '00001', 'id7074.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7073', '737', '00000', 'id7073.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7072', '737', '00003', 'id7072.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7071', '737', '00002', 'id7071.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7070', '737', '00001', 'id7070.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7069', '737', '00000', 'id7069.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7068', '737', '00036', 'id7068.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00036.JPG');
INSERT INTO photos VALUES ('7067', '737', '00035', 'id7067.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00035.JPG');
INSERT INTO photos VALUES ('7066', '737', '00034', 'id7066.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00034.JPG');
INSERT INTO photos VALUES ('7065', '737', '00033', 'id7065.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00033.JPG');
INSERT INTO photos VALUES ('7064', '737', '00032', 'id7064.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00032.JPG');
INSERT INTO photos VALUES ('7063', '737', '00031', 'id7063.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00031.JPG');
INSERT INTO photos VALUES ('7062', '737', '00030', 'id7062.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00030.JPG');
INSERT INTO photos VALUES ('7061', '737', '00029', 'id7061.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00029.JPG');
INSERT INTO photos VALUES ('7060', '737', '00028', 'id7060.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00028.JPG');
INSERT INTO photos VALUES ('7059', '737', '00027', 'id7059.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00027.JPG');
INSERT INTO photos VALUES ('7058', '737', '00026', 'id7058.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00026.JPG');
INSERT INTO photos VALUES ('7057', '737', '00025', 'id7057.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00025.JPG');
INSERT INTO photos VALUES ('7056', '737', '00024', 'id7056.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00024.JPG');
INSERT INTO photos VALUES ('7055', '737', '00023', 'id7055.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00023.JPG');
INSERT INTO photos VALUES ('7054', '737', '00022', 'id7054.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00022.JPG');
INSERT INTO photos VALUES ('7053', '737', '00021', 'id7053.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00021.JPG');
INSERT INTO photos VALUES ('7052', '737', '00020', 'id7052.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00020.JPG');
INSERT INTO photos VALUES ('7051', '737', '00019', 'id7051.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00019.JPG');
INSERT INTO photos VALUES ('7050', '737', '00018', 'id7050.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00018.JPG');
INSERT INTO photos VALUES ('7049', '737', '00017', 'id7049.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00017.JPG');
INSERT INTO photos VALUES ('7048', '737', '00016', 'id7048.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00016.JPG');
INSERT INTO photos VALUES ('7047', '737', '00015', 'id7047.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00015.JPG');
INSERT INTO photos VALUES ('7046', '737', '00014', 'id7046.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00014.JPG');
INSERT INTO photos VALUES ('7045', '737', '00013', 'id7045.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00013.JPG');
INSERT INTO photos VALUES ('7044', '737', '00012', 'id7044.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00012.JPG');
INSERT INTO photos VALUES ('7043', '737', '00011', 'id7043.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00011.JPG');
INSERT INTO photos VALUES ('7042', '737', '00010', 'id7042.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00010.JPG');
INSERT INTO photos VALUES ('7041', '737', '00009', 'id7041.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00009.JPG');
INSERT INTO photos VALUES ('7040', '737', '00008', 'id7040.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00008.JPG');
INSERT INTO photos VALUES ('7039', '737', '00007', 'id7039.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00007.JPG');
INSERT INTO photos VALUES ('7038', '737', '00006', 'id7038.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00006.JPG');
INSERT INTO photos VALUES ('7037', '737', '00005', 'id7037.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00005.JPG');
INSERT INTO photos VALUES ('7036', '737', '00004', 'id7036.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00004.JPG');
INSERT INTO photos VALUES ('7035', '737', '00003', 'id7035.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00003.JPG');
INSERT INTO photos VALUES ('7034', '737', '00002', 'id7034.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00002.JPG');
INSERT INTO photos VALUES ('7033', '737', '00001', 'id7033.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00001.JPG');
INSERT INTO photos VALUES ('7032', '737', '00000', 'id7032.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00000.JPG');
INSERT INTO photos VALUES ('7031', '737', '00036', 'id7031.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00036.JPG');
INSERT INTO photos VALUES ('7030', '737', '00035', 'id7030.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00035.JPG');
INSERT INTO photos VALUES ('7029', '737', '00034', 'id7029.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00034.JPG');
INSERT INTO photos VALUES ('7028', '737', '00033', 'id7028.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00033.JPG');
INSERT INTO photos VALUES ('7027', '737', '00032', 'id7027.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00032.JPG');
INSERT INTO photos VALUES ('7026', '737', '00031', 'id7026.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00031.JPG');
INSERT INTO photos VALUES ('7025', '737', '00030', 'id7025.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00030.JPG');
INSERT INTO photos VALUES ('7024', '737', '00029', 'id7024.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00029.JPG');
INSERT INTO photos VALUES ('7023', '737', '00028', 'id7023.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00028.JPG');
INSERT INTO photos VALUES ('7022', '737', '00027', 'id7022.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00027.JPG');
INSERT INTO photos VALUES ('7021', '737', '00026', 'id7021.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00026.JPG');
INSERT INTO photos VALUES ('7020', '737', '00025', 'id7020.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00025.JPG');
INSERT INTO photos VALUES ('7019', '737', '00024', 'id7019.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00024.JPG');
INSERT INTO photos VALUES ('7018', '737', '00023', 'id7018.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00023.JPG');
INSERT INTO photos VALUES ('7017', '737', '00022', 'id7017.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00022.JPG');
INSERT INTO photos VALUES ('7016', '737', '00021', 'id7016.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00021.JPG');
INSERT INTO photos VALUES ('7015', '737', '00020', 'id7015.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00020.JPG');
INSERT INTO photos VALUES ('7014', '737', '00019', 'id7014.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00019.JPG');
INSERT INTO photos VALUES ('7013', '737', '00018', 'id7013.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00018.JPG');
INSERT INTO photos VALUES ('7012', '737', '00017', 'id7012.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00017.JPG');
INSERT INTO photos VALUES ('7011', '737', '00016', 'id7011.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00016.JPG');
INSERT INTO photos VALUES ('7010', '737', '00015', 'id7010.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00015.JPG');
INSERT INTO photos VALUES ('7009', '737', '00014', 'id7009.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00014.JPG');
INSERT INTO photos VALUES ('7008', '737', '00013', 'id7008.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00013.JPG');
INSERT INTO photos VALUES ('7007', '737', '00012', 'id7007.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00012.JPG');
INSERT INTO photos VALUES ('7006', '737', '00011', 'id7006.jpg', '2', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00011.JPG');
INSERT INTO photos VALUES ('7005', '737', '00010', 'id7005.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00010.JPG');
INSERT INTO photos VALUES ('7004', '737', '00009', 'id7004.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00009.JPG');
INSERT INTO photos VALUES ('7003', '737', '00008', 'id7003.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00008.JPG');
INSERT INTO photos VALUES ('7002', '737', '00007', 'id7002.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00007.JPG');
INSERT INTO photos VALUES ('7001', '737', '00006', 'id7001.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00006.JPG');
INSERT INTO photos VALUES ('7000', '737', '00005', 'id7000.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00005.JPG');
INSERT INTO photos VALUES ('6999', '737', '00004', 'id6999.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00004.JPG');
INSERT INTO photos VALUES ('6998', '737', '00003', 'id6998.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00003.JPG');
INSERT INTO photos VALUES ('6997', '737', '00002', 'id6997.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00002.JPG');
INSERT INTO photos VALUES ('6996', '737', '00001', 'id6996.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00001.JPG');
INSERT INTO photos VALUES ('6995', '737', '00000', 'id6995.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00000.JPG');
INSERT INTO photos VALUES ('6994', '737', '00000', 'id6994.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00000.JPG');
INSERT INTO photos VALUES ('6993', '737', '00036', 'id6993.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00036.JPG');
INSERT INTO photos VALUES ('6992', '737', '00035', 'id6992.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00035.JPG');
INSERT INTO photos VALUES ('6991', '737', '00034', 'id6991.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00034.JPG');
INSERT INTO photos VALUES ('6990', '737', '00033', 'id6990.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00033.JPG');
INSERT INTO photos VALUES ('6989', '737', '00032', 'id6989.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00032.JPG');
INSERT INTO photos VALUES ('6988', '737', '00031', 'id6988.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00031.JPG');
INSERT INTO photos VALUES ('6987', '737', '00030', 'id6987.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00030.JPG');
INSERT INTO photos VALUES ('6986', '737', '00029', 'id6986.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00029.JPG');
INSERT INTO photos VALUES ('6985', '737', '00028', 'id6985.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00028.JPG');
INSERT INTO photos VALUES ('6984', '737', '00027', 'id6984.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00027.JPG');
INSERT INTO photos VALUES ('6983', '737', '00026', 'id6983.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00026.JPG');
INSERT INTO photos VALUES ('6982', '737', '00025', 'id6982.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00025.JPG');
INSERT INTO photos VALUES ('6981', '737', '00024', 'id6981.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00024.JPG');
INSERT INTO photos VALUES ('6980', '737', '00023', 'id6980.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00023.JPG');
INSERT INTO photos VALUES ('6979', '737', '00022', 'id6979.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00022.JPG');
INSERT INTO photos VALUES ('6978', '737', '00021', 'id6978.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00021.JPG');
INSERT INTO photos VALUES ('6977', '737', '00020', 'id6977.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00020.JPG');
INSERT INTO photos VALUES ('6976', '737', '00019', 'id6976.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00019.JPG');
INSERT INTO photos VALUES ('6975', '737', '00018', 'id6975.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00018.JPG');
INSERT INTO photos VALUES ('6974', '737', '00017', 'id6974.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00017.JPG');
INSERT INTO photos VALUES ('6973', '737', '00016', 'id6973.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00016.JPG');
INSERT INTO photos VALUES ('6972', '737', '00015', 'id6972.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00015.JPG');
INSERT INTO photos VALUES ('6971', '737', '00014', 'id6971.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00014.JPG');
INSERT INTO photos VALUES ('6970', '737', '00013', 'id6970.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00013.JPG');
INSERT INTO photos VALUES ('6969', '737', '00012', 'id6969.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00012.JPG');
INSERT INTO photos VALUES ('6968', '737', '00011', 'id6968.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00011.JPG');
INSERT INTO photos VALUES ('6967', '737', '00010', 'id6967.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00010.JPG');
INSERT INTO photos VALUES ('6966', '737', '00009', 'id6966.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00009.JPG');
INSERT INTO photos VALUES ('6965', '737', '00008', 'id6965.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00008.JPG');
INSERT INTO photos VALUES ('6964', '737', '00007', 'id6964.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00007.JPG');
INSERT INTO photos VALUES ('6963', '737', '00006', 'id6963.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00006.JPG');
INSERT INTO photos VALUES ('6962', '737', '00005', 'id6962.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00005.JPG');
INSERT INTO photos VALUES ('6961', '737', '00004', 'id6961.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00004.JPG');
INSERT INTO photos VALUES ('6960', '737', '00003', 'id6960.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00003.JPG');
INSERT INTO photos VALUES ('6959', '737', '00002', 'id6959.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00002.JPG');
INSERT INTO photos VALUES ('6958', '737', '00001', 'id6958.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00001.JPG');
INSERT INTO photos VALUES ('6957', '737', '00000', 'id6957.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00000.JPG');
INSERT INTO photos VALUES ('6956', '737', '00036', 'id6956.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00036.JPG');
INSERT INTO photos VALUES ('6955', '737', '00035', 'id6955.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00035.JPG');
INSERT INTO photos VALUES ('6954', '737', '00034', 'id6954.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00034.JPG');
INSERT INTO photos VALUES ('6953', '737', '00033', 'id6953.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00033.JPG');
INSERT INTO photos VALUES ('6952', '737', '00032', 'id6952.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00032.JPG');
INSERT INTO photos VALUES ('6951', '737', '00031', 'id6951.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00031.JPG');
INSERT INTO photos VALUES ('6950', '737', '00030', 'id6950.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00030.JPG');
INSERT INTO photos VALUES ('6949', '737', '00029', 'id6949.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00029.JPG');
INSERT INTO photos VALUES ('6948', '737', '00028', 'id6948.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00028.JPG');
INSERT INTO photos VALUES ('6947', '737', '00027', 'id6947.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00027.JPG');
INSERT INTO photos VALUES ('6946', '737', '00026', 'id6946.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00026.JPG');
INSERT INTO photos VALUES ('6945', '737', '00025', 'id6945.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00025.JPG');
INSERT INTO photos VALUES ('6944', '737', '00024', 'id6944.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00024.JPG');
INSERT INTO photos VALUES ('6943', '737', '00023', 'id6943.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00023.JPG');
INSERT INTO photos VALUES ('6942', '737', '00022', 'id6942.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00022.JPG');
INSERT INTO photos VALUES ('6941', '737', '00021', 'id6941.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00021.JPG');
INSERT INTO photos VALUES ('6940', '737', '00020', 'id6940.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00020.JPG');
INSERT INTO photos VALUES ('6939', '737', '00019', 'id6939.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00019.JPG');
INSERT INTO photos VALUES ('6938', '737', '00018', 'id6938.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00018.JPG');
INSERT INTO photos VALUES ('6937', '737', '00017', 'id6937.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00017.JPG');
INSERT INTO photos VALUES ('6936', '737', '00016', 'id6936.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00016.JPG');
INSERT INTO photos VALUES ('6935', '737', '00015', 'id6935.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00015.JPG');
INSERT INTO photos VALUES ('6934', '737', '00014', 'id6934.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00014.JPG');
INSERT INTO photos VALUES ('6933', '737', '00013', 'id6933.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00013.JPG');
INSERT INTO photos VALUES ('6932', '737', '00012', 'id6932.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00012.JPG');
INSERT INTO photos VALUES ('6931', '737', '00011', 'id6931.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00011.JPG');
INSERT INTO photos VALUES ('6930', '737', '00010', 'id6930.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00010.JPG');
INSERT INTO photos VALUES ('6929', '737', '00009', 'id6929.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00009.JPG');
INSERT INTO photos VALUES ('6928', '737', '00008', 'id6928.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00008.JPG');
INSERT INTO photos VALUES ('6927', '737', '00007', 'id6927.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00007.JPG');
INSERT INTO photos VALUES ('6926', '737', '00006', 'id6926.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00006.JPG');
INSERT INTO photos VALUES ('6925', '737', '00005', 'id6925.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00005.JPG');
INSERT INTO photos VALUES ('6924', '737', '00004', 'id6924.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00004.JPG');
INSERT INTO photos VALUES ('6923', '737', '00003', 'id6923.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00003.JPG');
INSERT INTO photos VALUES ('6922', '737', '00002', 'id6922.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00002.JPG');
INSERT INTO photos VALUES ('6921', '737', '00001', 'id6921.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00001.JPG');
INSERT INTO photos VALUES ('6920', '737', '00000', 'id6920.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00000.JPG');
INSERT INTO photos VALUES ('6919', '737', '00036', 'id6919.jpg', '1', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00036.JPG');
INSERT INTO photos VALUES ('6918', '737', '00035', 'id6918.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00035.JPG');
INSERT INTO photos VALUES ('6917', '737', '00034', 'id6917.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00034.JPG');
INSERT INTO photos VALUES ('6916', '737', '00033', 'id6916.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00033.JPG');
INSERT INTO photos VALUES ('6915', '737', '00032', 'id6915.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00032.JPG');
INSERT INTO photos VALUES ('6914', '737', '00031', 'id6914.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00031.JPG');
INSERT INTO photos VALUES ('6913', '737', '00030', 'id6913.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00030.JPG');
INSERT INTO photos VALUES ('6912', '737', '00029', 'id6912.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00029.JPG');
INSERT INTO photos VALUES ('6911', '737', '00028', 'id6911.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00028.JPG');
INSERT INTO photos VALUES ('6910', '737', '00027', 'id6910.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00027.JPG');
INSERT INTO photos VALUES ('6909', '737', '00026', 'id6909.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00026.JPG');
INSERT INTO photos VALUES ('6908', '737', '00025', 'id6908.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00025.JPG');
INSERT INTO photos VALUES ('6907', '737', '00024', 'id6907.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00024.JPG');
INSERT INTO photos VALUES ('6906', '737', '00023', 'id6906.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00023.JPG');
INSERT INTO photos VALUES ('6905', '737', '00022', 'id6905.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00022.JPG');
INSERT INTO photos VALUES ('6904', '737', '00021', 'id6904.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00021.JPG');
INSERT INTO photos VALUES ('6903', '737', '00020', 'id6903.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00020.JPG');
INSERT INTO photos VALUES ('6902', '737', '00019', 'id6902.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00019.JPG');
INSERT INTO photos VALUES ('6901', '737', '00018', 'id6901.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00018.JPG');
INSERT INTO photos VALUES ('6900', '737', '00017', 'id6900.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00017.JPG');
INSERT INTO photos VALUES ('6899', '737', '00016', 'id6899.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00016.JPG');
INSERT INTO photos VALUES ('6898', '737', '00015', 'id6898.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00015.JPG');
INSERT INTO photos VALUES ('6897', '737', '00014', 'id6897.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00014.JPG');
INSERT INTO photos VALUES ('6896', '737', '00013', 'id6896.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00013.JPG');
INSERT INTO photos VALUES ('6895', '737', '00012', 'id6895.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00012.JPG');
INSERT INTO photos VALUES ('6894', '737', '00011', 'id6894.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00011.JPG');
INSERT INTO photos VALUES ('6893', '737', '00010', 'id6893.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00010.JPG');
INSERT INTO photos VALUES ('6892', '737', '00009', 'id6892.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00009.JPG');
INSERT INTO photos VALUES ('6891', '737', '00008', 'id6891.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00008.JPG');
INSERT INTO photos VALUES ('6890', '737', '00007', 'id6890.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00007.JPG');
INSERT INTO photos VALUES ('6889', '737', '00006', 'id6889.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00006.JPG');
INSERT INTO photos VALUES ('6888', '737', '00005', 'id6888.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00005.JPG');
INSERT INTO photos VALUES ('6887', '737', '00004', 'id6887.jpg', '4', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00004.JPG');
INSERT INTO photos VALUES ('6886', '737', '00003', 'id6886.jpg', '2', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00003.JPG');
INSERT INTO photos VALUES ('6883', '737', '00000', 'id6883.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00000.JPG');
INSERT INTO photos VALUES ('6884', '737', '00001', 'id6884.jpg', '1', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00001.JPG');
INSERT INTO photos VALUES ('6885', '737', '00002', 'id6885.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/02/00002.JPG');
INSERT INTO photos VALUES ('6697', '734', '00036', 'id6697.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00036.JPG');
INSERT INTO photos VALUES ('6696', '734', '00035', 'id6696.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00035.JPG');
INSERT INTO photos VALUES ('6695', '734', '00034', 'id6695.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00034.JPG');
INSERT INTO photos VALUES ('6694', '734', '00033', 'id6694.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00033.JPG');
INSERT INTO photos VALUES ('6693', '734', '00032', 'id6693.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00032.JPG');
INSERT INTO photos VALUES ('6692', '734', '00031', 'id6692.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00031.JPG');
INSERT INTO photos VALUES ('6691', '734', '00030', 'id6691.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00030.JPG');
INSERT INTO photos VALUES ('6690', '734', '00029', 'id6690.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00029.JPG');
INSERT INTO photos VALUES ('6689', '734', '00028', 'id6689.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00028.JPG');
INSERT INTO photos VALUES ('6688', '734', '00027', 'id6688.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00027.JPG');
INSERT INTO photos VALUES ('6687', '734', '00026', 'id6687.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00026.JPG');
INSERT INTO photos VALUES ('6686', '734', '00025', 'id6686.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00025.JPG');
INSERT INTO photos VALUES ('6685', '734', '00024', 'id6685.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00024.JPG');
INSERT INTO photos VALUES ('6684', '734', '00023', 'id6684.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00023.JPG');
INSERT INTO photos VALUES ('6683', '734', '00022', 'id6683.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00022.JPG');
INSERT INTO photos VALUES ('6682', '734', '00021', 'id6682.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00021.JPG');
INSERT INTO photos VALUES ('6681', '734', '00020', 'id6681.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00020.JPG');
INSERT INTO photos VALUES ('6680', '734', '00019', 'id6680.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00019.JPG');
INSERT INTO photos VALUES ('6679', '734', '00018', 'id6679.jpg', '3', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00018.JPG');
INSERT INTO photos VALUES ('6678', '734', '00017', 'id6678.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00017.JPG');
INSERT INTO photos VALUES ('6677', '734', '00016', 'id6677.jpg', '1', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00016.JPG');
INSERT INTO photos VALUES ('6676', '734', '00015', 'id6676.jpg', '8', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00015.JPG');
INSERT INTO photos VALUES ('6675', '734', '00014', 'id6675.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00014.JPG');
INSERT INTO photos VALUES ('6674', '734', '00013', 'id6674.jpg', '2', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00013.JPG');
INSERT INTO photos VALUES ('6673', '734', '00012', 'id6673.jpg', '8', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00012.JPG');
INSERT INTO photos VALUES ('6672', '734', '00011', 'id6672.jpg', '1', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00011.JPG');
INSERT INTO photos VALUES ('6671', '734', '00010', 'id6671.jpg', '8', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00010.JPG');
INSERT INTO photos VALUES ('6670', '734', '00009', 'id6670.jpg', '15', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00009.JPG');
INSERT INTO photos VALUES ('6669', '734', '00008', 'id6669.jpg', '2', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00008.JPG');
INSERT INTO photos VALUES ('6668', '734', '00007', 'id6668.jpg', '3', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00007.JPG');
INSERT INTO photos VALUES ('6667', '734', '00006', 'id6667.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00006.JPG');
INSERT INTO photos VALUES ('6666', '734', '00005', 'id6666.jpg', '8', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00005.JPG');
INSERT INTO photos VALUES ('6665', '734', '00004', 'id6665.jpg', '13', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00004.JPG');
INSERT INTO photos VALUES ('6664', '734', '00003', 'id6664.jpg', '140', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00003.JPG');
INSERT INTO photos VALUES ('6661', '734', '00000', 'id6661.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00000.JPG');
INSERT INTO photos VALUES ('6662', '734', '00001', 'id6662.jpg', '0', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00001.JPG');
INSERT INTO photos VALUES ('6663', '734', '00002', 'id6663.jpg', '6', '10.00', '12.00', '30.00', '/fotoarhiv/svadba/02/00002.JPG');
INSERT INTO photos VALUES ('6608', '733', '2010', 'id6608.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2010.jpg');
INSERT INTO photos VALUES ('6607', '733', '2009', 'id6607.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2009.jpg');
INSERT INTO photos VALUES ('6606', '733', '2008', 'id6606.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2008.jpg');
INSERT INTO photos VALUES ('6605', '733', '2007', 'id6605.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2007.jpg');
INSERT INTO photos VALUES ('6604', '733', '2006', 'id6604.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2006.jpg');
INSERT INTO photos VALUES ('6603', '733', '2005', 'id6603.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2005.JPG');
INSERT INTO photos VALUES ('6602', '733', '2004', 'id6602.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2004.JPG');
INSERT INTO photos VALUES ('6601', '733', '2003', 'id6601.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2003.JPG');
INSERT INTO photos VALUES ('6600', '733', '2012', 'id6600.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2012.jpg');
INSERT INTO photos VALUES ('6599', '733', '2011', 'id6599.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2011.jpg');
INSERT INTO photos VALUES ('6598', '733', '2010', 'id6598.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2010.jpg');
INSERT INTO photos VALUES ('6597', '733', '2009', 'id6597.jpg', '1', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2009.jpg');
INSERT INTO photos VALUES ('6596', '733', '2008', 'id6596.jpg', '1', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2008.jpg');
INSERT INTO photos VALUES ('6595', '733', '2007', 'id6595.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2007.jpg');
INSERT INTO photos VALUES ('6594', '733', '2006', 'id6594.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2006.jpg');
INSERT INTO photos VALUES ('6593', '733', '2005', 'id6593.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2005.JPG');
INSERT INTO photos VALUES ('6592', '733', '2004', 'id6592.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2004.JPG');
INSERT INTO photos VALUES ('6591', '733', '2003', 'id6591.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2003.JPG');
INSERT INTO photos VALUES ('6590', '733', '2012', 'id6590.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2012.jpg');
INSERT INTO photos VALUES ('6589', '733', '2011', 'id6589.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2011.jpg');
INSERT INTO photos VALUES ('6588', '733', '2010', 'id6588.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2010.jpg');
INSERT INTO photos VALUES ('6587', '733', '2009', 'id6587.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2009.jpg');
INSERT INTO photos VALUES ('6586', '733', '2008', 'id6586.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2008.jpg');
INSERT INTO photos VALUES ('6585', '733', '2007', 'id6585.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2007.jpg');
INSERT INTO photos VALUES ('6584', '733', '2006', 'id6584.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2006.jpg');
INSERT INTO photos VALUES ('6583', '733', '2005', 'id6583.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2005.JPG');
INSERT INTO photos VALUES ('6582', '733', '2004', 'id6582.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2004.JPG');
INSERT INTO photos VALUES ('6581', '733', '2003', 'id6581.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2003.JPG');
INSERT INTO photos VALUES ('6580', '733', '2012', 'id6580.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2012.jpg');
INSERT INTO photos VALUES ('6579', '733', '2011', 'id6579.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2011.jpg');
INSERT INTO photos VALUES ('6578', '733', '2010', 'id6578.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2010.jpg');
INSERT INTO photos VALUES ('6577', '733', '2009', 'id6577.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2009.jpg');
INSERT INTO photos VALUES ('6576', '733', '2008', 'id6576.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2008.jpg');
INSERT INTO photos VALUES ('6575', '733', '2007', 'id6575.jpg', '1', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2007.jpg');
INSERT INTO photos VALUES ('6574', '733', '2006', 'id6574.jpg', '1', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2006.jpg');
INSERT INTO photos VALUES ('6573', '733', '2005', 'id6573.jpg', '1', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2005.JPG');
INSERT INTO photos VALUES ('6572', '733', '2004', 'id6572.jpg', '1', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2004.JPG');
INSERT INTO photos VALUES ('6571', '733', '2003', 'id6571.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2003.JPG');
INSERT INTO photos VALUES ('6609', '733', '2011', 'id6609.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2011.jpg');
INSERT INTO photos VALUES ('6610', '733', '2012', 'id6610.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2012.jpg');
INSERT INTO photos VALUES ('6611', '733', '2003', 'id6611.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2003.JPG');
INSERT INTO photos VALUES ('6612', '733', '2004', 'id6612.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2004.JPG');
INSERT INTO photos VALUES ('6613', '733', '2005', 'id6613.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2005.JPG');
INSERT INTO photos VALUES ('6614', '733', '2006', 'id6614.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2006.jpg');
INSERT INTO photos VALUES ('6615', '733', '2007', 'id6615.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2007.jpg');
INSERT INTO photos VALUES ('6616', '733', '2008', 'id6616.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2008.jpg');
INSERT INTO photos VALUES ('6617', '733', '2009', 'id6617.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2009.jpg');
INSERT INTO photos VALUES ('6618', '733', '2010', 'id6618.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2010.jpg');
INSERT INTO photos VALUES ('6619', '733', '2011', 'id6619.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2011.jpg');
INSERT INTO photos VALUES ('6620', '733', '2012', 'id6620.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2012.jpg');
INSERT INTO photos VALUES ('6621', '733', '2003', 'id6621.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2003.JPG');
INSERT INTO photos VALUES ('6622', '733', '2004', 'id6622.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2004.JPG');
INSERT INTO photos VALUES ('6623', '733', '2005', 'id6623.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2005.JPG');
INSERT INTO photos VALUES ('6624', '733', '2006', 'id6624.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2006.jpg');
INSERT INTO photos VALUES ('6625', '733', '2007', 'id6625.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2007.jpg');
INSERT INTO photos VALUES ('6626', '733', '2008', 'id6626.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2008.jpg');
INSERT INTO photos VALUES ('6627', '733', '2009', 'id6627.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2009.jpg');
INSERT INTO photos VALUES ('6628', '733', '2010', 'id6628.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2010.jpg');
INSERT INTO photos VALUES ('6629', '733', '2011', 'id6629.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2011.jpg');
INSERT INTO photos VALUES ('6630', '733', '2012', 'id6630.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2012.jpg');
INSERT INTO photos VALUES ('6631', '733', '2003', 'id6631.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2003.JPG');
INSERT INTO photos VALUES ('6632', '733', '2004', 'id6632.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2004.JPG');
INSERT INTO photos VALUES ('6633', '733', '2005', 'id6633.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2005.JPG');
INSERT INTO photos VALUES ('6634', '733', '2006', 'id6634.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2006.jpg');
INSERT INTO photos VALUES ('6635', '733', '2007', 'id6635.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2007.jpg');
INSERT INTO photos VALUES ('6636', '733', '2008', 'id6636.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2008.jpg');
INSERT INTO photos VALUES ('6637', '733', '2009', 'id6637.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2009.jpg');
INSERT INTO photos VALUES ('6638', '733', '2010', 'id6638.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2010.jpg');
INSERT INTO photos VALUES ('6639', '733', '2011', 'id6639.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2011.jpg');
INSERT INTO photos VALUES ('6640', '733', '2012', 'id6640.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2012.jpg');
INSERT INTO photos VALUES ('6641', '733', '2003', 'id6641.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2003.JPG');
INSERT INTO photos VALUES ('6642', '733', '2004', 'id6642.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2004.JPG');
INSERT INTO photos VALUES ('6643', '733', '2005', 'id6643.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2005.JPG');
INSERT INTO photos VALUES ('6644', '733', '2006', 'id6644.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2006.jpg');
INSERT INTO photos VALUES ('6645', '733', '2007', 'id6645.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2007.jpg');
INSERT INTO photos VALUES ('6646', '733', '2008', 'id6646.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2008.jpg');
INSERT INTO photos VALUES ('6647', '733', '2009', 'id6647.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2009.jpg');
INSERT INTO photos VALUES ('6648', '733', '2010', 'id6648.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2010.jpg');
INSERT INTO photos VALUES ('6649', '733', '2011', 'id6649.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2011.jpg');
INSERT INTO photos VALUES ('6650', '733', '2012', 'id6650.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2012.jpg');
INSERT INTO photos VALUES ('6651', '733', '2003', 'id6651.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2003.JPG');
INSERT INTO photos VALUES ('6652', '733', '2004', 'id6652.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2004.JPG');
INSERT INTO photos VALUES ('6653', '733', '2005', 'id6653.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2005.JPG');
INSERT INTO photos VALUES ('6654', '733', '2006', 'id6654.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2006.jpg');
INSERT INTO photos VALUES ('6655', '733', '2007', 'id6655.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2007.jpg');
INSERT INTO photos VALUES ('6656', '733', '2008', 'id6656.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2008.jpg');
INSERT INTO photos VALUES ('6657', '733', '2009', 'id6657.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2009.jpg');
INSERT INTO photos VALUES ('6658', '733', '2010', 'id6658.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2010.jpg');
INSERT INTO photos VALUES ('6659', '733', '2011', 'id6659.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2011.jpg');
INSERT INTO photos VALUES ('6660', '733', '2012', 'id6660.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/shkola/Vipuski 2003-2012/2012.jpg');
INSERT INTO photos VALUES ('7124', '737', '00003', 'id7124.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7194', '737', '00001', 'id7194.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7195', '737', '00002', 'id7195.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7196', '737', '00003', 'id7196.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7197', '737', '00000', 'id7197.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7198', '737', '00001', 'id7198.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7199', '737', '00002', 'id7199.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7200', '737', '00003', 'id7200.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7201', '737', '00000', 'id7201.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7202', '737', '00001', 'id7202.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7203', '737', '00002', 'id7203.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7204', '737', '00003', 'id7204.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');
INSERT INTO photos VALUES ('7205', '737', '00000', 'id7205.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00000.JPG');
INSERT INTO photos VALUES ('7206', '737', '00001', 'id7206.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00001.JPG');
INSERT INTO photos VALUES ('7207', '737', '00002', 'id7207.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00002.JPG');
INSERT INTO photos VALUES ('7208', '737', '00003', 'id7208.jpg', '0', '10.00', '2.00', '30.00', '/fotoarhiv/svadba/01/00003.JPG');


#
# Table structure for table `print`
#

DROP TABLE IF EXISTS `print`;
CREATE TABLE `print` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL COMMENT 'номер пользователя',
  `name` varchar(64) NOT NULL COMMENT 'имя пользователя',
  `subname` varchar(64) NOT NULL COMMENT 'фамилия пользователя',
  `phone` varchar(64) NOT NULL COMMENT 'телефон пользователя',
  `email` varchar(64) NOT NULL COMMENT 'E-mail заказчика',
  `dt` int(11) NOT NULL COMMENT 'дата заказа',
  `adr_poluc` varchar(512) NOT NULL COMMENT 'адрес почтового отделения или получателя ( город и номер)',
  `adr_studii` varchar(512) NOT NULL COMMENT 'адрес печатной студии ',
  `nPocta` varchar(64) NOT NULL COMMENT 'название почтовой службы',
  `id_nal` varchar(64) NOT NULL COMMENT 'способ оплаты оплата наложенным платежем или через сайт',
  `id_dost` varchar(64) NOT NULL COMMENT 'способ доставки',
  `user_dost` varchar(512) NOT NULL COMMENT 'способ доставки выбранный пользователем',
  `user_opl` varchar(512) NOT NULL COMMENT 'способ оплаты выбранный пользователем',
  `ramka` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'белая рамка',
  `mat_gl` enum('матовая','глянцевая') NOT NULL DEFAULT 'глянцевая' COMMENT 'тип бумаги',
  `format` enum('10x15','13x18','20x30') NOT NULL DEFAULT '13x18' COMMENT 'формат бумаги',
  `comm` varchar(512) NOT NULL COMMENT 'Примечание пользователя',
  `summ` float(8,2) NOT NULL DEFAULT '0.00' COMMENT 'Сумма за фото с учетом всех скидок',
  `zakaz` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'подтверждение заказа',
  `otpr` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'дата отправки заказа почтой',
  `dekl` varchar(64) NOT NULL COMMENT 'номер почтовой декларации',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 - получение денег и закрытие счета',
  `key` varchar(64) NOT NULL COMMENT 'для подтверждения заказа',
  PRIMARY KEY (`id`),
  KEY `key` (`key`)
) ENGINE=MyISAM AUTO_INCREMENT=141 DEFAULT CHARSET=cp1251 COMMENT='Печать фотографий';

#
# Dumping data for table `print`
#

INSERT INTO print VALUES ('83', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '2013', '', 'Одесса, ул.Пушкинская (напротив цума)', 'выбрать|выбрать', 'пополнение баланса сайта', 'Самовывоз из студии (в Одессе)', '', '', '0', 'глянцевая', '13x18', '', '24.00', '0', '0000-00-00 00:00:00', '', '0', 'fd7fc2b3981d448fbb50ba180e18a0c4');
INSERT INTO print VALUES ('82', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '2013', '898', 'выбрать', 'Укрпочта|http://services.ukrposhta.com/CalcUtil/PostalMails.aspx', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', 'гшш', '24.00', '0', '0000-00-00 00:00:00', '', '0', '57724a93e961c63d17e370b0cc0f7bbd');
INSERT INTO print VALUES ('80', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '2013', '', 'выбрать', 'Укрпочта|http://services.ukrposhta.com/CalcUtil/PostalMails.aspx', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '1', 'матовая', '20x30', '', '40.00', '0', '0000-00-00 00:00:00', '', '0', 'fc8a7346e91e62c25452e7f72b76908b');
INSERT INTO print VALUES ('81', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '2013', '', 'выбрать', 'Новая  почта|http://novaposhta.ua/frontend/calculator/ru', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '24.00', '0', '0000-00-00 00:00:00', '', '0', '32bf4f3a75e3a7051bee5f6144019b95');
INSERT INTO print VALUES ('84', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '0', '', 'выбрать', 'Новая  почта|http://novaposhta.ua/frontend/calculator/ru', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '24.00', '0', '0000-00-00 00:00:00', '', '0', 'd3f67b8da648899302eca600a2c7c25d');
INSERT INTO print VALUES ('85', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '0', '', 'выбрать', 'Новая  почта|http://novaposhta.ua/frontend/calculator/ru', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '12.00', '0', '0000-00-00 00:00:00', '', '0', '08a383258b776d98fa95b091385e242a');
INSERT INTO print VALUES ('86', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1369476722', '', 'выбрать', 'Укрпочта|http://services.ukrposhta.com/CalcUtil/PostalMails.aspx', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '12.00', '0', '0000-00-00 00:00:00', '', '0', 'd5bd32cf208ea20b95aa76437ecf8f12');
INSERT INTO print VALUES ('87', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1369477000', '', 'Одесса, ул.Пушкинская (напротив цума)', 'выбрать|выбрать', 'пополнение баланса сайта', 'Самовывоз из студии (в Одессе)', '', '', '0', 'глянцевая', '13x18', '', '12.00', '0', '0000-00-00 00:00:00', '', '0', '3eb68e844eafa0930c73877d9530c0fd');
INSERT INTO print VALUES ('88', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1369477436', '', 'выбрать', 'Укрпочта|http://services.ukrposhta.com/CalcUtil/PostalMails.aspx', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '12.00', '0', '0000-00-00 00:00:00', '', '0', '6cc3bc0ffd11116b3cbf1e6b28045416');
INSERT INTO print VALUES ('89', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1369477623', '', 'выбрать', 'Укрпочта|http://services.ukrposhta.com/CalcUtil/PostalMails.aspx', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '12.00', '0', '0000-00-00 00:00:00', '', '0', '9822530215418cd1f8c37537c2157d34');
INSERT INTO print VALUES ('90', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1369477694', '', 'выбрать', 'Укрпочта|http://services.ukrposhta.com/CalcUtil/PostalMails.aspx', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '12.00', '0', '0000-00-00 00:00:00', '', '0', '6f914bf695ed67a58ab62f6f52410623');
INSERT INTO print VALUES ('91', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1369477747', '', 'выбрать', 'Укрпочта|http://services.ukrposhta.com/CalcUtil/PostalMails.aspx', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '12.00', '0', '0000-00-00 00:00:00', '', '0', 'ca19ea3a2ab8e69d48905f78e6097dcd053edbef');
INSERT INTO print VALUES ('92', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1369477747', '', 'Одесса, ул.Пушкинская (напротив цума)', 'выбрать|выбрать', 'пополнение баланса сайта', 'Самовывоз из студии (в Одессе)', '', '', '0', 'матовая', '20x30', '', '120.00', '1', '0000-00-00 00:00:00', '', '0', '060ac0492d04229806d3648ddcf53c083f3e0a6a');
INSERT INTO print VALUES ('93', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1369507797', '', 'выбрать', 'Укрпочта|http://services.ukrposhta.com/CalcUtil/PostalMails.aspx', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', '695a4e7ef50b76aefc813c9071959688c640f11b');
INSERT INTO print VALUES ('94', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1369507926', '', 'выбрать', 'Новая  почта|http://novaposhta.ua/frontend/calculator/ru', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', '1ebfdb27845bf41a30a2096ce694631913175cf3');
INSERT INTO print VALUES ('95', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1369509361', '', 'выбрать', 'Укрпочта|http://services.ukrposhta.com/CalcUtil/PostalMails.aspx', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', '01fa22167fc278c7ee1cc3884983d0e60b51598e');
INSERT INTO print VALUES ('96', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1369573835', 'l;\'l;\'', 'выбрать', 'Укрпочта|http://services.ukrposhta.com/CalcUtil/PostalMails.aspx', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '24.00', '1', '0000-00-00 00:00:00', '', '0', 'e7946c1349ff7409e8570739aaab8bfe8c50a09f');
INSERT INTO print VALUES ('97', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1369649469', '', 'выбрать', 'Укрпочта|http://services.ukrposhta.com/CalcUtil/PostalMails.aspx', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', '6cb0a97640647af7a6d229e8e03b07611e9a9585');
INSERT INTO print VALUES ('98', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370092522', '', 'выбрать', 'Укрпочта|http://services.ukrposhta.com/CalcUtil/PostalMails.aspx', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', '14712391741981076c6539fcffa883771046be87');
INSERT INTO print VALUES ('99', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370179689', '', 'выбрать', 'Укрпочта|http://services.ukrposhta.com/CalcUtil/PostalMails.aspx', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '60.00', '1', '0000-00-00 00:00:00', '', '0', '1da7d723695da38fcdc1f233161d963ad34a03eb');
INSERT INTO print VALUES ('100', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370257240', '', 'Одесса, ул.Ленина 48', 'выбрать|выбрать', 'наложенный платеж', 'Самовывоз из студии (в Одессе)', '', '', '1', 'глянцевая', '13x18', '', '180.00', '1', '0000-00-00 00:00:00', '', '0', '066559338b2c4a7fe20ed74904caa8b4bd57b658');
INSERT INTO print VALUES ('101', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370266809', '', 'Одесса, ул.Пушкинская (напротив цума)', 'выбрать|выбрать', 'наложенный платеж', 'Самовывоз из студии (в Одессе)', '', '', '1', 'матовая', '20x30', '', '240.00', '1', '0000-00-00 00:00:00', '', '0', 'b9e943e883243cd30f1e19c581c719c02180d68b');
INSERT INTO print VALUES ('102', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370267304', '', 'Одесса, ул.Ленина 48', 'выбрать|выбрать', 'наложенный платеж', 'Самовывоз из студии (в Одессе)', '', '', '1', 'глянцевая', '13x18', '', '336.00', '1', '0000-00-00 00:00:00', '', '0', 'eb8fe843e7d7d78d5ebbe5bd15be2c2a6f02769a');
INSERT INTO print VALUES ('103', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370273729', '', 'Одесса, ул.Ленина 48', 'выбрать|выбрать', 'наложенный платеж', 'Самовывоз из студии (в Одессе)', '', '', '1', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', 'cb171cffba34fe42dd21b2c84ed39304c3a4e6a3');
INSERT INTO print VALUES ('104', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370288578', '', 'Одесса, ул.Пушкинская (напротив цума)', 'выбрать|выбрать', 'наложенный платеж', 'Самовывоз из студии (в Одессе)', '', '', '0', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', '76b681ba15039c4a1ba7ed93f4c554790e826f4b');
INSERT INTO print VALUES ('105', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370473647', '', 'Одесса, ул.Ленина 48', 'выбрать|выбрать', 'наложенный платеж', 'Самовывоз из студии (в Одессе)', '', '', '1', 'глянцевая', '13x18', '', '72.00', '1', '0000-00-00 00:00:00', '', '0', 'b76720d42ae9fa2458b25faaa09095ef4a7bf64e');
INSERT INTO print VALUES ('106', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370481645', '', 'Одесса, ул.Ленина 48', 'выбрать|выбрать', 'наложенный платеж', 'Самовывоз из студии (в Одессе)', '', '', '0', 'глянцевая', '13x18', '', '144.00', '1', '0000-00-00 00:00:00', '', '0', '737d654c41f57adc4a6326c489684d96b751d331');
INSERT INTO print VALUES ('107', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370572351', '', 'Одесса, ул.Ленина 48', 'Новая  почта|http://novaposhta.ua/frontend/calculator/ru', 'наложенный платеж', 'Самовывоз из студии (в Одессе)', '', '', '1', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', 'e9594525cc8d5e271b53703e059dba8a6f070d05');
INSERT INTO print VALUES ('108', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370618736', '', 'Одесса, ул.Ленина 48', 'выбрать|выбрать', 'наложенный платеж', 'Самовывоз из студии (в Одессе)', '', '', '0', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', '4652fc3f51077691fd62c69a8434efc25a3b52fa');
INSERT INTO print VALUES ('109', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370618953', '', 'Одесса, ул.Ленина 48', 'выбрать|выбрать', 'наложенный платеж', 'Самовывоз из студии (в Одессе)', '', '', '0', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', '174cc0d7033f17b52ccbdf7211c14751018f9845');
INSERT INTO print VALUES ('110', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370619386', '', 'Одесса, ул.Ленина 48', 'выбрать|выбрать', 'наложенный платеж', 'Самовывоз из студии (в Одессе)', '', '', '1', 'матовая', '13x18', '', '24.00', '1', '0000-00-00 00:00:00', '', '0', '1ced0a545b80aac0ab2e835b6d4bfb1ecc6b444e');
INSERT INTO print VALUES ('111', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370646046', '', 'Одесса, ул.Ленина 48', 'Новая  почта|http://novaposhta.ua/frontend/calculator/ru', 'наложенный платеж', 'Самовывоз из студии (в Одессе)', '', '', '0', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', '6597fce1cef9fb91ba89e379a34ac3c7074f2aff');
INSERT INTO print VALUES ('112', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370719583', '', 'Одесса, ул.Пушкинская (напротив цума)', 'выбрать|выбрать', 'пополнение баланса сайта', 'Самовывоз из студии (в Одессе)', '', '', '0', 'глянцевая', '13x18', '', '12.00', '0', '0000-00-00 00:00:00', '', '0', '992562ca7bd1d9a0e5fed70be38d1eaab7aacedf');
INSERT INTO print VALUES ('113', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370719839', '', 'выбрать', 'выбрать|выбрать', 'пополнение баланса сайта', 'Передать тренеру команды (в Одессе при полной предоплате)', '', '', '0', 'глянцевая', '13x18', '', '12.00', '0', '0000-00-00 00:00:00', '', '0', '83fe8c0ccd069189201f33d9f25293b598e6efe5');
INSERT INTO print VALUES ('114', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370719916', '', 'выбрать', 'выбрать|выбрать', 'пополнение баланса сайта', 'Самовывоз от фотографа', '', '', '0', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', 'c358e0199ec8a00607ff3caa3b4d41178b274a12');
INSERT INTO print VALUES ('115', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370724798', '', 'выбрать', 'Укрпочта|http://services.ukrposhta.com/CalcUtil/PostalMails.aspx', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '1', 'глянцевая', '10x15', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', '7acb511f41b482bf106afb68ac70ae2ad53c05f8');
INSERT INTO print VALUES ('116', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370731534', '', 'Одесса, ул.Пушкинская (напротив цума)', 'Укрпочта|http://services.ukrposhta.com/CalcUtil/PostalMails.aspx', 'наложенный платеж', 'Самовывоз из студии (в Одессе)', '', '', '0', 'глянцевая', '20x30', '', '120.00', '0', '0000-00-00 00:00:00', '', '0', 'b7583da805a63344ac4d5f1a4ff44bc9777727fb');
INSERT INTO print VALUES ('117', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370982031', '', 'выбрать', 'Новая  почта|http://novaposhta.ua/frontend/calculator/ru', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', '81d6b43c524ab71cbaa6b7039b67409f168b72ac');
INSERT INTO print VALUES ('118', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370982578', '', 'выбрать', 'Укрпочта|http://services.ukrposhta.com/CalcUtil/PostalMails.aspx', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', '22f09181f42ee761c8da3574ec569ad412019850');
INSERT INTO print VALUES ('119', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370983452', '', 'выбрать', 'Новая  почта|http://novaposhta.ua/frontend/calculator/ru', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', '650e11e0ce82b3dca43daaa6b2dd531564b79214');
INSERT INTO print VALUES ('120', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370983715', '', 'выбрать', 'Новая  почта|http://novaposhta.ua/frontend/calculator/ru', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', '824caa356cf8394150e2c2a1c9ab0c32e30b5eed');
INSERT INTO print VALUES ('121', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370987933', '', 'выбрать', 'Новая  почта|http://novaposhta.ua/frontend/calculator/ru', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', '4c82ffc0270397c84108986ca8af3d2fe4abc672');
INSERT INTO print VALUES ('122', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370988080', '', 'Одесса, ул.Ленина 48', 'выбрать|выбрать', 'наложенный платеж', 'Самовывоз из студии (в Одессе)', '', '', '0', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', '79dbd3d06df710942bcc23a03e5be9c62d6a187a');
INSERT INTO print VALUES ('123', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370988236', '', 'Одесса, ул.Ленина 48', 'выбрать|выбрать', 'пополнение баланса сайта', 'Самовывоз из студии (в Одессе)', '', '', '0', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', 'f3e2d10cb596c854c5520fd3939209f27bd966b2');
INSERT INTO print VALUES ('124', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1370991037', '', 'выбрать', 'выбрать|выбрать', 'другое', 'Самовывоз от фотографа', '', 'пропроп', '0', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', 'cc8257237d15f581172ba11c4ff72fd9ef09e5dd');
INSERT INTO print VALUES ('125', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1371042891', '', 'Одесса, ул.Ленина 48', 'выбрать|выбрать', 'пополнение баланса сайта', 'Самовывоз из студии (в Одессе)', '', '', '0', 'глянцевая', '13x18', '', '36.00', '1', '0000-00-00 00:00:00', '', '0', '10667cb96325501f2e30080a3f45c46b8a9f0675');
INSERT INTO print VALUES ('126', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1371044165', '', 'Одесса, ул.Ленина 48', 'выбрать|выбрать', 'наложенный платеж', 'Самовывоз из студии (в Одессе)', '', '', '0', 'глянцевая', '13x18', '', '72.00', '1', '0000-00-00 00:00:00', '', '0', '197b67f1eb116dfb8d6aa9e3813b495a1f05d4ef');
INSERT INTO print VALUES ('127', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1371113714', '', 'выбрать', 'Новая  почта|http://novaposhta.ua/frontend/calculator/ru', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '12.00', '0', '0000-00-00 00:00:00', '', '0', '4a795b5f9a1813339a8f2a6dcda96fa027436f3a');
INSERT INTO print VALUES ('128', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1371113844', '', 'выбрать', 'Укрпочта|http://services.ukrposhta.com/CalcUtil/PostalMails.aspx', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '12.00', '0', '0000-00-00 00:00:00', '', '0', 'c0aa2a1e4f4d244edfc460155e92684ee255ca00');
INSERT INTO print VALUES ('129', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1371417932', '', 'Одесса, ул.Ленина 48', 'выбрать|выбрать', 'наложенный платеж', 'Самовывоз из студии (в Одессе)', '', '', '0', 'глянцевая', '13x18', '', '12.00', '0', '0000-00-00 00:00:00', '', '0', '0c1e3eb353f95392556ea128ee8c5006b574e825');
INSERT INTO print VALUES ('130', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1371418286', '', 'Одесса, ул.Ленина 48', 'выбрать|выбрать', 'пополнение баланса сайта', 'Самовывоз из студии (в Одессе)', '', '', '0', 'глянцевая', '13x18', '', '12.00', '0', '0000-00-00 00:00:00', '', '0', '38f8c8f321df2ef36b99ab163a48435c9af248c7');
INSERT INTO print VALUES ('132', '59', 'Юрий', 'Алексеев', '7777777', 'uf-3027@te.net.ua', '1372841453', '', 'Одесса, ул.Ленина 48', 'выбрать|выбрать', 'наложенный платеж', 'Самовывоз из студии (в Одессе)', '', '', '1', 'матовая', '13x18', '7687878678yuiyui', '16.00', '1', '0000-00-00 00:00:00', '', '0', '71ec17446894706486aaa4dd52fdf8b607320486');
INSERT INTO print VALUES ('131', '29', 'test', 'test2', '77777', 'uf-3027@te.net.ua', '1371422655', '', 'Одесса, ул.Пушкинская (напротив цума)', 'выбрать|выбрать', 'наложенный платеж', 'Самовывоз из студии (в Одессе)', '', '', '0', 'глянцевая', '13x18', '', '12.00', '1', '0000-00-00 00:00:00', '', '0', '78faeb50ea4202c95a4928d1b3050339bf975597');
INSERT INTO print VALUES ('133', '59', 'Юрий', 'Алексеев', '7777777', 'uf-3027@te.net.ua', '1372854543', '', 'Одесса, ул.Ленина 48', 'выбрать|выбрать', 'наложенный платеж', 'Самовывоз из студии (в Одессе)', '', '', '0', 'глянцевая', '13x18', '', '2.00', '1', '0000-00-00 00:00:00', '', '0', '8554645c5374a860b830fe3e59cb632f30e2a4f3');
INSERT INTO print VALUES ('134', '59', 'Юрий', 'Алексеев', '7777777', 'uf-3027@te.net.ua', '1372880099', '', 'выбрать', 'Укрпочта|http://services.ukrposhta.com/CalcUtil/PostalMails.aspx', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '8.00', '0', '0000-00-00 00:00:00', '', '0', '24a757b8b1ee19afcb45462f1c22afa7c478dd70');
INSERT INTO print VALUES ('135', '59', 'test', 'Алексеев', '7777777', 'uf-3027@te.net.ua', '1373355169', '', 'Одесса, ул.Пушкинская (напротив цума)', 'выбрать|выбрать', 'пополнение баланса сайта', 'Самовывоз из студии (в Одессе)', '', '', '0', 'глянцевая', '13x18', '', '12.00', '0', '0000-00-00 00:00:00', '', '0', '56287e9db8888af6d827326b764fd5dabf5a2c10');
INSERT INTO print VALUES ('136', '59', 'test', 'Алексеев', '7777777', 'uf-3027@te.net.ua', '1374531797', '', 'выбрать', 'Укрпочта|http://services.ukrposhta.com/CalcUtil/PostalMails.aspx', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '2.00', '0', '0000-00-00 00:00:00', '', '0', 'f8f8d1f3690b3a94af63206aee81dce29739b717');
INSERT INTO print VALUES ('137', '59', 'test', 'Алексеев', '7777777', 'uf-3027@te.net.ua', '1375972654', '', 'выбрать', 'выбрать|выбрать', 'пополнение баланса сайта', 'Самовывоз от фотографа', '', '', '1', 'глянцевая', '20x30', '', '30.00', '1', '0000-00-00 00:00:00', '', '0', 'ca39fc1a558db60f387eefeec5b259a1eb14834d');
INSERT INTO print VALUES ('138', '59', 'test', 'Алексеев', '7777777', 'uf-3027@te.net.ua', '1376581043', '', 'Одесса, ул.Ленина 48', 'выбрать|выбрать', 'наложенный платеж', 'Самовывоз из студии (в Одессе)', '', '', '0', 'матовая', '13x18', '', '14.00', '0', '0000-00-00 00:00:00', '', '0', '619eb0bf4ea5d40732b8ead8b2273530e640904c');
INSERT INTO print VALUES ('139', '59', 'test', 'Алексеев', '7777777', 'aleksjurii@gmail.com', '1378425880', '', 'выбрать', 'Новая  почта|http://novaposhta.ua/frontend/calculator/ru', 'наложенный платеж', 'Самовывоз из почтового отделения Вашего города', '', '', '0', 'глянцевая', '13x18', '', '2.00', '0', '0000-00-00 00:00:00', '', '0', '52373fb39d31a563171097a4992199edf100dab5');
INSERT INTO print VALUES ('140', '59', 'test', 'Алексеев', '7777777', 'aleksjurii@gmail.com', '1379252759', '', 'выбрать', 'Новая  почта|http://novaposhta.ua/frontend/calculator/ru', 'пополнение баланса сайта', 'Доставка до двери почтовой службой (кроме Одессы)', '', '', '1', 'матовая', '20x30', 'ertretert', '90.00', '1', '0000-00-00 00:00:00', '', '0', 'ce12bf6b0dca9e9fa67201790808775c2ce1193c');


#
# Table structure for table `subs`
#

DROP TABLE IF EXISTS `subs`;
CREATE TABLE `subs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nm` varchar(64) NOT NULL COMMENT 'Название акции',
  `time_in` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Вреня начала акции',
  `time_out` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Дата конца',
  `time_act` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Время выполнения для одноразовой акции ',
  `time` int(11) NOT NULL COMMENT 'Повторять через каждые time часов',
  `id_album_event` int(11) NOT NULL COMMENT 'Событие альбома для выполнения условия',
  `id_user_event` varchar(64) NOT NULL COMMENT 'Событие usera для выполнения условия',
  `mode` enum('выполнить один раз','выполнять один раз в день','повторять через каждые time часов','выполнять постоянно при каждом заходе','выполнять при наступлении события') NOT NULL COMMENT 'Выполнение одно или многоразовая',
  `spec` varchar(256) NOT NULL COMMENT 'Описание',
  `a1` int(11) NOT NULL COMMENT 'Первый количественный аргумент акции',
  `a2` int(11) NOT NULL COMMENT 'Второй количественный аргумент акции',
  `a3` int(11) NOT NULL COMMENT 'Третий количественный аргумент акции',
  `txt` varchar(64) NOT NULL COMMENT 'Описание зависимостей аргументов a1, a2, a3 в программе',
  `var` enum('E-mail рассылки','баланс пользователя','альбом','сообщения') NOT NULL COMMENT 'Привязка к компонентам сайта',
  `order` enum('выполнять только для подписанных','выполнять для всех') NOT NULL COMMENT 'Условие выполнения ',
  `status` enum('в процессе','выполнено') NOT NULL COMMENT 'Статус выполнения ',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=cp1251 COMMENT='Существующие акции для пользователей';

#
# Dumping data for table `subs`
#

INSERT INTO subs VALUES ('1', '10%', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0', 'выполнить один раз', 'Скидки 10% при заказе от 1000 гривень', '1000', '10', '0', '', '', 'выполнять только для подписанных', 'в процессе');
INSERT INTO subs VALUES ('2', '1 гривня в день', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0', 'выполнять один раз в день', 'Каждый день по 1 гривне, всем зашедшим на сайт', '1', '1', '0', '', '', 'выполнять только для подписанных', 'в процессе');
INSERT INTO subs VALUES ('3', 'Бесплатная доставка', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0', 'выполнять постоянно при каждом заходе', 'При заказе фотографий от 1200 гривень - доставка бесплатная', '1200', '0', '0', '', 'E-mail рассылки', 'выполнять для всех', 'в процессе');
INSERT INTO subs VALUES ('4', 'Подписка на альбом', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '0', '0', 'выполнить один раз', 'Подписка на альбом \'Тест\'', '0', '0', '0', '', 'E-mail рассылки', 'выполнять для всех', 'выполнено');


#
# Table structure for table `subs_album_on`
#

DROP TABLE IF EXISTS `subs_album_on`;
CREATE TABLE `subs_album_on` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_album` int(11) NOT NULL COMMENT 'номер альбома',
  `id_alb_subs` int(11) NOT NULL COMMENT 'подписка на акции',
  `time_alb_subs` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'время подписки',
  PRIMARY KEY (`id`),
  KEY `id_album` (`id_album`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COMMENT='Подписка альбомов на акции';

#
# Dumping data for table `subs_album_on`
#



#
# Table structure for table `subs_user_on`
#

DROP TABLE IF EXISTS `subs_user_on`;
CREATE TABLE `subs_user_on` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL COMMENT 'Номер пользователя',
  `id_subs` int(11) NOT NULL COMMENT 'подписка на акции',
  `time_subs` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'время подписки',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=cp1251 COMMENT='подписка пользователей на акции ';

#
# Dumping data for table `subs_user_on`
#

INSERT INTO subs_user_on VALUES ('1', '29', '1', '2013-05-09 21:50:37');
INSERT INTO subs_user_on VALUES ('2', '29', '2', '2013-05-14 16:37:18');
INSERT INTO subs_user_on VALUES ('3', '18', '3', '2013-05-14 18:05:35');
INSERT INTO subs_user_on VALUES ('4', '18', '4', '2013-05-14 18:48:52');


#
# Table structure for table `users`
#

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `login` varchar(64) NOT NULL COMMENT 'логин',
  `pass` varchar(64) NOT NULL COMMENT 'пароль',
  `email` varchar(64) NOT NULL COMMENT 'почта',
  `skype` varchar(64) NOT NULL COMMENT 'скайп',
  `phone` varchar(64) NOT NULL COMMENT 'телефон',
  `block` tinyint(2) NOT NULL DEFAULT '1' COMMENT 'блокировка пользователя',
  `level` int(10) NOT NULL DEFAULT '1' COMMENT 'уровень доступа пользователя (категория)',
  `mail_me` varchar(64) NOT NULL DEFAULT 'on' COMMENT 'Разрешить администрации посылать уведомления пользователю',
  `timestamp` int(10) NOT NULL COMMENT 'Время регистрации',
  `us_name` varchar(64) NOT NULL COMMENT 'Имя',
  `us_surname` varchar(64) NOT NULL COMMENT 'Фамилия',
  `balans` float(8,2) NOT NULL DEFAULT '0.00' COMMENT 'денег на счету',
  `ip` varchar(64) NOT NULL COMMENT 'Ip регистрации ',
  `city` varchar(64) NOT NULL COMMENT 'Город проживания',
  `url` varchar(64) NOT NULL COMMENT 'Сайт пользователя ( доделать )',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'статус подтверждения регистрации',
  `komments_moder` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'статус разрешения коментариев',
  PRIMARY KEY (`id`),
  KEY `login` (`login`,`email`)
) ENGINE=MyISAM AUTO_INCREMENT=73 DEFAULT CHARSET=cp1251 COMMENT='Пользователи';

#
# Dumping data for table `users`
#

INSERT INTO users VALUES ('18', 'alex', 'be3c35685d009fd2cfa5d9e5d0c89308', 'alex.90476@gmail.com', '', '77-787', '1', '1', '1', '1353156597', 'Алексей', '', '120.00', '', '', '', '1', '0');
INSERT INTO users VALUES ('59', 'test', '098f6bcd4621d373cade4e832627b4f6', 'aleksjurii@gmail.com', 'noт', '7777777', '1', '1', 'on', '1371756447', 'test', 'Алексеев', '639.98', '31.31.116.22', 'Одесса', '', '1', '0');
INSERT INTO users VALUES ('60', 'fghfgh', 'b59c67bf196a4758191e42f76670ceba', 'sd@sd.gh', '', '', '1', '1', 'on', '1371765432', 'Юрий', '', '0.00', '2.93.63.25', '', '', '0', '0');
INSERT INTO users VALUES ('58', 'ghj', '229c488d4ba2a0054658094c273b65a2', 'ghj@fg.hj', '', '', '1', '1', 'on', '1371755549', 'Настоящее имя', '', '0.00', '127.0.0.1', '', '', '0', '0');
INSERT INTO users VALUES ('1', 'Юрий', '098f6bcd4621d373cade4e832627b4f6', '1@1.1', '', '', '1', '1', '1', '1111111111', 'Юрий', '', '938.00', '', '', '', '1', '0');


#
# Table structure for table `votes`
#

DROP TABLE IF EXISTS `votes`;
CREATE TABLE `votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL DEFAULT '0',
  `id_photo` int(11) NOT NULL DEFAULT '0',
  `golos_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_user` (`id_user`),
  KEY `id_photo` (`id_photo`),
  KEY `vote_time` (`golos_time`)
) ENGINE=MyISAM AUTO_INCREMENT=1010 DEFAULT CHARSET=cp1251 COMMENT='Голосование';

#
# Dumping data for table `votes`
#

INSERT INTO votes VALUES ('586', '29', '5990', '2013-05-07 14:51:12');
INSERT INTO votes VALUES ('585', '29', '5990', '2013-05-07 14:51:08');
INSERT INTO votes VALUES ('584', '29', '5986', '2013-05-07 14:51:02');
INSERT INTO votes VALUES ('583', '29', '5986', '2013-05-07 14:50:48');
INSERT INTO votes VALUES ('582', '29', '5982', '2013-05-07 14:50:23');
INSERT INTO votes VALUES ('581', '29', '5991', '2013-05-07 14:50:06');
INSERT INTO votes VALUES ('580', '29', '5991', '2013-05-07 14:50:05');
INSERT INTO votes VALUES ('579', '29', '5991', '2013-05-07 14:50:04');
INSERT INTO votes VALUES ('578', '29', '5982', '2013-05-07 14:49:44');
INSERT INTO votes VALUES ('539', '29', '5990', '2013-05-07 14:00:15');
INSERT INTO votes VALUES ('540', '29', '5990', '2013-05-07 14:00:22');
INSERT INTO votes VALUES ('541', '29', '5986', '2013-05-07 14:13:50');
INSERT INTO votes VALUES ('542', '29', '5990', '2013-05-07 14:20:44');
INSERT INTO votes VALUES ('543', '29', '5986', '2013-05-07 14:20:53');
INSERT INTO votes VALUES ('544', '29', '5990', '2013-05-07 14:21:30');
INSERT INTO votes VALUES ('545', '29', '5990', '2013-05-07 14:21:33');
INSERT INTO votes VALUES ('546', '29', '5982', '2013-05-07 14:27:18');
INSERT INTO votes VALUES ('547', '29', '5982', '2013-05-07 14:27:25');
INSERT INTO votes VALUES ('548', '29', '5982', '2013-05-07 14:27:59');
INSERT INTO votes VALUES ('549', '29', '5986', '2013-05-07 14:28:15');
INSERT INTO votes VALUES ('550', '29', '5986', '2013-05-07 14:28:19');
INSERT INTO votes VALUES ('551', '29', '6011', '2013-05-07 14:28:32');
INSERT INTO votes VALUES ('552', '29', '5991', '2013-05-07 14:29:02');
INSERT INTO votes VALUES ('553', '29', '5983', '2013-05-07 14:31:45');
INSERT INTO votes VALUES ('554', '29', '5983', '2013-05-07 14:31:49');
INSERT INTO votes VALUES ('555', '29', '5983', '2013-05-07 14:32:16');
INSERT INTO votes VALUES ('556', '29', '5986', '2013-05-07 14:32:20');
INSERT INTO votes VALUES ('557', '29', '5990', '2013-05-07 14:34:20');
INSERT INTO votes VALUES ('558', '29', '5990', '2013-05-07 14:34:33');
INSERT INTO votes VALUES ('559', '29', '5990', '2013-05-07 14:34:40');
INSERT INTO votes VALUES ('560', '29', '5986', '2013-05-07 14:34:48');
INSERT INTO votes VALUES ('561', '29', '5986', '2013-05-07 14:34:56');
INSERT INTO votes VALUES ('562', '29', '5986', '2013-05-07 14:36:08');
INSERT INTO votes VALUES ('563', '29', '5986', '2013-05-07 14:36:17');
INSERT INTO votes VALUES ('564', '29', '5990', '2013-05-07 14:37:04');
INSERT INTO votes VALUES ('565', '29', '6002', '2013-05-07 14:37:14');
INSERT INTO votes VALUES ('566', '29', '5990', '2013-05-07 14:39:17');
INSERT INTO votes VALUES ('567', '29', '6009', '2013-05-07 14:39:25');
INSERT INTO votes VALUES ('568', '29', '6003', '2013-05-07 14:39:37');
INSERT INTO votes VALUES ('569', '29', '6003', '2013-05-07 14:39:40');
INSERT INTO votes VALUES ('570', '29', '5991', '2013-05-07 14:40:14');
INSERT INTO votes VALUES ('571', '29', '5990', '2013-05-07 14:44:51');
INSERT INTO votes VALUES ('572', '29', '5990', '2013-05-07 14:45:16');
INSERT INTO votes VALUES ('573', '29', '5990', '2013-05-07 14:45:18');
INSERT INTO votes VALUES ('574', '29', '5990', '2013-05-07 14:45:20');
INSERT INTO votes VALUES ('575', '29', '5990', '2013-05-07 14:45:23');
INSERT INTO votes VALUES ('576', '29', '5990', '2013-05-07 14:45:25');
INSERT INTO votes VALUES ('577', '29', '5990', '2013-05-07 14:45:29');
INSERT INTO votes VALUES ('587', '29', '5986', '2013-05-07 15:25:33');
INSERT INTO votes VALUES ('588', '29', '5986', '2013-05-07 15:25:36');
INSERT INTO votes VALUES ('589', '29', '5990', '2013-05-07 15:25:57');
INSERT INTO votes VALUES ('590', '29', '5990', '2013-05-07 15:29:53');
INSERT INTO votes VALUES ('591', '29', '5990', '2013-05-07 15:41:14');
INSERT INTO votes VALUES ('592', '29', '5990', '2013-05-07 15:41:29');
INSERT INTO votes VALUES ('593', '29', '5986', '2013-05-07 15:42:00');
INSERT INTO votes VALUES ('594', '29', '5986', '2013-05-07 15:42:06');
INSERT INTO votes VALUES ('595', '29', '5986', '2013-05-07 15:42:30');
INSERT INTO votes VALUES ('596', '29', '5986', '2013-05-07 15:42:34');
INSERT INTO votes VALUES ('597', '29', '5990', '2013-05-07 15:43:27');
INSERT INTO votes VALUES ('598', '29', '5990', '2013-05-07 15:44:26');
INSERT INTO votes VALUES ('599', '29', '5990', '2013-05-07 15:47:28');
INSERT INTO votes VALUES ('600', '29', '5990', '2013-05-07 15:48:38');
INSERT INTO votes VALUES ('601', '29', '5990', '2013-05-07 15:48:46');
INSERT INTO votes VALUES ('602', '29', '5990', '2013-05-07 15:48:50');
INSERT INTO votes VALUES ('603', '29', '5990', '2013-05-07 15:49:22');
INSERT INTO votes VALUES ('604', '29', '5990', '2013-05-07 15:50:21');
INSERT INTO votes VALUES ('605', '29', '5990', '2013-05-07 15:50:26');
INSERT INTO votes VALUES ('606', '29', '5990', '2013-05-07 15:50:38');
INSERT INTO votes VALUES ('607', '29', '5990', '2013-05-07 15:50:43');
INSERT INTO votes VALUES ('608', '29', '5991', '2013-05-07 15:51:31');
INSERT INTO votes VALUES ('609', '29', '5990', '2013-05-07 16:12:13');
INSERT INTO votes VALUES ('610', '29', '5990', '2013-05-07 16:12:17');
INSERT INTO votes VALUES ('611', '29', '5990', '2013-05-07 16:18:12');
INSERT INTO votes VALUES ('612', '29', '5990', '2013-05-07 16:18:23');
INSERT INTO votes VALUES ('613', '29', '5990', '2013-05-07 16:18:58');
INSERT INTO votes VALUES ('614', '29', '5990', '2013-05-07 16:19:30');
INSERT INTO votes VALUES ('615', '29', '6101', '2013-05-07 16:26:01');
INSERT INTO votes VALUES ('616', '29', '6004', '2013-05-07 16:29:42');
INSERT INTO votes VALUES ('617', '29', '5982', '2013-05-07 16:58:24');
INSERT INTO votes VALUES ('618', '29', '6016', '2013-05-07 17:19:43');
INSERT INTO votes VALUES ('619', '29', '6020', '2013-05-07 17:21:14');
INSERT INTO votes VALUES ('620', '29', '6009', '2013-05-07 17:21:38');
INSERT INTO votes VALUES ('621', '29', '6021', '2013-05-07 17:22:03');
INSERT INTO votes VALUES ('622', '29', '6021', '2013-05-07 17:22:07');
INSERT INTO votes VALUES ('623', '29', '6021', '2013-05-07 17:22:10');
INSERT INTO votes VALUES ('624', '29', '6460', '2013-05-07 17:24:50');
INSERT INTO votes VALUES ('625', '29', '6470', '2013-05-07 17:25:55');
INSERT INTO votes VALUES ('626', '29', '6471', '2013-05-07 17:26:06');
INSERT INTO votes VALUES ('627', '29', '6472', '2013-05-07 17:26:10');
INSERT INTO votes VALUES ('628', '29', '6473', '2013-05-07 17:26:13');
INSERT INTO votes VALUES ('629', '29', '6474', '2013-05-07 17:26:16');
INSERT INTO votes VALUES ('630', '29', '6462', '2013-05-07 17:26:47');
INSERT INTO votes VALUES ('631', '29', '6469', '2013-05-07 17:28:14');
INSERT INTO votes VALUES ('632', '29', '6492', '2013-05-07 17:42:26');
INSERT INTO votes VALUES ('633', '29', '6483', '2013-05-07 17:43:20');
INSERT INTO votes VALUES ('634', '29', '6491', '2013-05-07 17:45:52');
INSERT INTO votes VALUES ('635', '29', '6492', '2013-05-07 17:46:14');
INSERT INTO votes VALUES ('636', '29', '6492', '2013-05-07 17:47:39');
INSERT INTO votes VALUES ('637', '29', '5986', '2013-05-07 17:48:05');
INSERT INTO votes VALUES ('638', '29', '5986', '2013-05-07 17:48:09');
INSERT INTO votes VALUES ('639', '29', '5986', '2013-05-07 17:48:12');
INSERT INTO votes VALUES ('640', '29', '5990', '2013-05-07 17:48:29');
INSERT INTO votes VALUES ('641', '29', '5990', '2013-05-07 17:48:32');
INSERT INTO votes VALUES ('642', '29', '6492', '2013-05-07 17:48:39');
INSERT INTO votes VALUES ('643', '29', '6492', '2013-05-07 17:48:44');
INSERT INTO votes VALUES ('644', '29', '6492', '2013-05-07 17:48:47');
INSERT INTO votes VALUES ('645', '29', '6492', '2013-05-07 17:48:51');
INSERT INTO votes VALUES ('646', '29', '6492', '2013-05-07 17:48:55');
INSERT INTO votes VALUES ('647', '29', '6492', '2013-05-07 17:48:58');
INSERT INTO votes VALUES ('648', '29', '6492', '2013-05-07 17:49:42');
INSERT INTO votes VALUES ('649', '29', '6492', '2013-05-07 17:49:47');
INSERT INTO votes VALUES ('650', '29', '6492', '2013-05-07 17:49:52');
INSERT INTO votes VALUES ('651', '29', '5990', '2013-05-07 17:50:19');
INSERT INTO votes VALUES ('652', '29', '5990', '2013-05-07 17:50:27');
INSERT INTO votes VALUES ('653', '29', '6476', '2013-05-07 17:50:55');
INSERT INTO votes VALUES ('654', '29', '6489', '2013-05-07 17:51:11');
INSERT INTO votes VALUES ('655', '29', '6490', '2013-05-07 17:51:15');
INSERT INTO votes VALUES ('656', '29', '6493', '2013-05-07 17:51:25');
INSERT INTO votes VALUES ('657', '29', '6484', '2013-05-07 17:51:53');
INSERT INTO votes VALUES ('658', '29', '6487', '2013-05-07 17:52:11');
INSERT INTO votes VALUES ('659', '29', '6477', '2013-05-07 17:52:32');
INSERT INTO votes VALUES ('660', '29', '6478', '2013-05-07 17:52:39');
INSERT INTO votes VALUES ('661', '29', '6479', '2013-05-07 17:52:43');
INSERT INTO votes VALUES ('662', '29', '6480', '2013-05-07 17:52:48');
INSERT INTO votes VALUES ('663', '29', '6481', '2013-05-07 17:52:55');
INSERT INTO votes VALUES ('664', '29', '6482', '2013-05-07 17:53:06');
INSERT INTO votes VALUES ('665', '29', '6485', '2013-05-07 17:53:16');
INSERT INTO votes VALUES ('666', '29', '6486', '2013-05-07 17:53:21');
INSERT INTO votes VALUES ('667', '29', '6496', '2013-05-07 17:53:36');
INSERT INTO votes VALUES ('668', '29', '6359', '2013-05-07 18:08:04');
INSERT INTO votes VALUES ('669', '29', '6359', '2013-05-07 18:08:27');
INSERT INTO votes VALUES ('670', '29', '6359', '2013-05-07 18:08:30');
INSERT INTO votes VALUES ('671', '29', '6359', '2013-05-07 18:08:32');
INSERT INTO votes VALUES ('672', '29', '6359', '2013-05-07 18:08:34');
INSERT INTO votes VALUES ('673', '29', '5990', '2013-05-07 18:09:06');
INSERT INTO votes VALUES ('674', '29', '6023', '2013-05-08 22:45:37');
INSERT INTO votes VALUES ('675', '29', '6023', '2013-05-08 22:45:40');
INSERT INTO votes VALUES ('676', '29', '6471', '2013-05-09 00:12:14');
INSERT INTO votes VALUES ('677', '29', '5986', '2013-05-09 01:33:31');
INSERT INTO votes VALUES ('678', '29', '5986', '2013-05-09 10:29:49');
INSERT INTO votes VALUES ('679', '29', '5990', '2013-05-09 10:30:59');
INSERT INTO votes VALUES ('680', '29', '6008', '2013-05-10 20:57:16');
INSERT INTO votes VALUES ('681', '29', '6098', '2013-05-12 15:23:02');
INSERT INTO votes VALUES ('682', '29', '5986', '2013-05-13 12:24:38');
INSERT INTO votes VALUES ('683', '29', '5986', '2013-05-20 01:12:43');
INSERT INTO votes VALUES ('684', '29', '5990', '2013-05-26 09:25:17');
INSERT INTO votes VALUES ('685', '29', '6005', '2013-06-09 00:51:59');
INSERT INTO votes VALUES ('686', '29', '5982', '2013-06-09 00:52:07');
INSERT INTO votes VALUES ('687', '29', '5983', '2013-06-09 00:52:22');
INSERT INTO votes VALUES ('688', '29', '5982', '2013-06-12 03:31:53');
INSERT INTO votes VALUES ('689', '29', '5982', '2013-06-12 03:32:08');
INSERT INTO votes VALUES ('690', '29', '5982', '2013-06-12 03:32:13');
INSERT INTO votes VALUES ('691', '29', '5982', '2013-06-12 03:32:17');
INSERT INTO votes VALUES ('692', '29', '5982', '2013-06-12 03:32:31');
INSERT INTO votes VALUES ('693', '29', '5982', '2013-06-12 03:32:54');
INSERT INTO votes VALUES ('694', '29', '5982', '2013-06-12 03:32:58');
INSERT INTO votes VALUES ('695', '29', '5982', '2013-06-12 03:33:02');
INSERT INTO votes VALUES ('696', '29', '6053', '2013-06-12 03:33:21');
INSERT INTO votes VALUES ('697', '29', '5986', '2013-06-12 03:47:22');
INSERT INTO votes VALUES ('698', '29', '5990', '2013-06-12 03:49:47');
INSERT INTO votes VALUES ('699', '29', '5990', '2013-06-12 03:49:54');
INSERT INTO votes VALUES ('700', '29', '5990', '2013-06-12 03:49:58');
INSERT INTO votes VALUES ('701', '29', '5990', '2013-06-12 03:50:02');
INSERT INTO votes VALUES ('702', '29', '5986', '2013-06-12 03:50:46');
INSERT INTO votes VALUES ('703', '29', '5982', '2013-06-12 03:50:58');
INSERT INTO votes VALUES ('704', '29', '5982', '2013-06-12 03:51:02');
INSERT INTO votes VALUES ('705', '29', '5986', '2013-06-12 03:52:28');
INSERT INTO votes VALUES ('706', '29', '5986', '2013-06-12 03:52:35');
INSERT INTO votes VALUES ('707', '29', '5986', '2013-06-12 03:52:39');
INSERT INTO votes VALUES ('708', '29', '5986', '2013-06-12 03:52:46');
INSERT INTO votes VALUES ('709', '29', '5990', '2013-06-12 03:55:52');
INSERT INTO votes VALUES ('710', '29', '5990', '2013-06-12 03:55:58');
INSERT INTO votes VALUES ('711', '29', '5990', '2013-06-12 03:56:06');
INSERT INTO votes VALUES ('712', '29', '5990', '2013-06-12 03:57:59');
INSERT INTO votes VALUES ('713', '29', '5990', '2013-06-12 03:58:04');
INSERT INTO votes VALUES ('714', '29', '5990', '2013-06-12 03:58:07');
INSERT INTO votes VALUES ('715', '29', '5986', '2013-06-12 04:06:13');
INSERT INTO votes VALUES ('716', '29', '5986', '2013-06-12 04:06:16');
INSERT INTO votes VALUES ('717', '29', '5986', '2013-06-12 04:08:51');
INSERT INTO votes VALUES ('718', '29', '5986', '2013-06-12 04:08:59');
INSERT INTO votes VALUES ('719', '29', '5986', '2013-06-12 04:09:03');
INSERT INTO votes VALUES ('720', '29', '5982', '2013-06-12 04:09:50');
INSERT INTO votes VALUES ('721', '29', '5986', '2013-06-12 04:12:32');
INSERT INTO votes VALUES ('722', '29', '5986', '2013-06-12 04:12:59');
INSERT INTO votes VALUES ('723', '29', '5986', '2013-06-12 04:13:12');
INSERT INTO votes VALUES ('724', '29', '5991', '2013-06-12 10:20:31');
INSERT INTO votes VALUES ('725', '29', '5991', '2013-06-12 10:21:38');
INSERT INTO votes VALUES ('726', '29', '5991', '2013-06-12 10:21:41');
INSERT INTO votes VALUES ('727', '29', '5986', '2013-06-12 10:22:03');
INSERT INTO votes VALUES ('728', '29', '5986', '2013-06-12 10:22:07');
INSERT INTO votes VALUES ('729', '29', '5986', '2013-06-12 10:22:10');
INSERT INTO votes VALUES ('730', '29', '5986', '2013-06-12 10:22:24');
INSERT INTO votes VALUES ('731', '29', '5986', '2013-06-12 10:22:28');
INSERT INTO votes VALUES ('732', '29', '5986', '2013-06-12 10:22:33');
INSERT INTO votes VALUES ('733', '29', '5990', '2013-06-12 10:25:22');
INSERT INTO votes VALUES ('734', '29', '5990', '2013-06-12 10:25:25');
INSERT INTO votes VALUES ('735', '29', '5983', '2013-06-12 10:25:31');
INSERT INTO votes VALUES ('736', '29', '5983', '2013-06-12 10:25:34');
INSERT INTO votes VALUES ('737', '29', '5995', '2013-06-12 10:25:40');
INSERT INTO votes VALUES ('738', '29', '5986', '2013-06-12 10:26:30');
INSERT INTO votes VALUES ('739', '29', '5986', '2013-06-12 10:27:35');
INSERT INTO votes VALUES ('740', '29', '5991', '2013-06-12 10:27:40');
INSERT INTO votes VALUES ('741', '29', '5986', '2013-06-12 10:35:46');
INSERT INTO votes VALUES ('742', '29', '5986', '2013-06-12 10:35:49');
INSERT INTO votes VALUES ('743', '29', '5986', '2013-06-12 10:35:52');
INSERT INTO votes VALUES ('744', '29', '5986', '2013-06-12 10:36:20');
INSERT INTO votes VALUES ('745', '29', '5986', '2013-06-12 10:36:23');
INSERT INTO votes VALUES ('746', '29', '5986', '2013-06-12 11:06:16');
INSERT INTO votes VALUES ('747', '29', '5990', '2013-06-12 11:06:31');
INSERT INTO votes VALUES ('748', '29', '5990', '2013-06-12 11:06:34');
INSERT INTO votes VALUES ('749', '29', '5990', '2013-06-12 11:06:37');
INSERT INTO votes VALUES ('750', '29', '5990', '2013-06-12 11:13:07');
INSERT INTO votes VALUES ('751', '29', '5990', '2013-06-12 11:14:21');
INSERT INTO votes VALUES ('752', '29', '5990', '2013-06-12 11:14:26');
INSERT INTO votes VALUES ('753', '29', '5982', '2013-06-12 11:14:38');
INSERT INTO votes VALUES ('754', '29', '5991', '2013-06-12 11:33:58');
INSERT INTO votes VALUES ('755', '29', '5991', '2013-06-12 11:34:03');
INSERT INTO votes VALUES ('756', '29', '5991', '2013-06-12 11:34:07');
INSERT INTO votes VALUES ('757', '29', '5991', '2013-06-12 11:34:46');
INSERT INTO votes VALUES ('758', '29', '5990', '2013-06-12 11:51:22');
INSERT INTO votes VALUES ('759', '29', '5990', '2013-06-12 11:51:27');
INSERT INTO votes VALUES ('760', '29', '5982', '2013-06-12 12:39:42');
INSERT INTO votes VALUES ('761', '29', '5982', '2013-06-12 12:39:45');
INSERT INTO votes VALUES ('762', '29', '5991', '2013-06-12 12:39:52');
INSERT INTO votes VALUES ('763', '29', '5991', '2013-06-12 12:52:30');
INSERT INTO votes VALUES ('764', '29', '5991', '2013-06-12 12:52:35');
INSERT INTO votes VALUES ('765', '29', '5990', '2013-06-12 12:59:37');
INSERT INTO votes VALUES ('766', '29', '6007', '2013-06-12 13:16:55');
INSERT INTO votes VALUES ('767', '29', '6063', '2013-06-12 13:34:51');
INSERT INTO votes VALUES ('768', '29', '6021', '2013-06-12 13:37:38');
INSERT INTO votes VALUES ('769', '29', '6037', '2013-06-12 13:37:50');
INSERT INTO votes VALUES ('770', '29', '6006', '2013-06-12 13:39:46');
INSERT INTO votes VALUES ('771', '29', '6020', '2013-06-12 13:40:16');
INSERT INTO votes VALUES ('772', '29', '6023', '2013-06-12 13:43:23');
INSERT INTO votes VALUES ('773', '29', '5993', '2013-06-12 13:43:45');
INSERT INTO votes VALUES ('774', '29', '6596', '2013-06-12 21:07:18');
INSERT INTO votes VALUES ('775', '29', '6597', '2013-06-12 21:07:47');
INSERT INTO votes VALUES ('776', '29', '6572', '2013-06-12 21:08:01');
INSERT INTO votes VALUES ('777', '29', '6573', '2013-06-12 21:10:46');
INSERT INTO votes VALUES ('778', '29', '6574', '2013-06-12 21:11:57');
INSERT INTO votes VALUES ('779', '29', '6575', '2013-06-12 21:12:01');
INSERT INTO votes VALUES ('780', '29', '6095', '2013-06-12 21:14:47');
INSERT INTO votes VALUES ('781', '29', '6085', '2013-06-12 21:23:36');
INSERT INTO votes VALUES ('782', '59', '6671', '2013-06-30 00:07:45');
INSERT INTO votes VALUES ('783', '59', '6671', '2013-06-30 00:07:57');
INSERT INTO votes VALUES ('784', '59', '6671', '2013-06-30 00:08:24');
INSERT INTO votes VALUES ('785', '59', '6670', '2013-06-30 15:58:17');
INSERT INTO votes VALUES ('786', '59', '6670', '2013-06-30 15:58:19');
INSERT INTO votes VALUES ('787', '59', '6670', '2013-06-30 15:58:24');
INSERT INTO votes VALUES ('788', '59', '6670', '2013-06-30 15:58:25');
INSERT INTO votes VALUES ('789', '59', '6679', '2013-06-30 15:58:32');
INSERT INTO votes VALUES ('790', '59', '6679', '2013-06-30 15:59:02');
INSERT INTO votes VALUES ('791', '59', '6679', '2013-06-30 15:59:04');
INSERT INTO votes VALUES ('792', '59', '6671', '2013-06-30 16:03:18');
INSERT INTO votes VALUES ('793', '59', '6671', '2013-06-30 16:03:40');
INSERT INTO votes VALUES ('794', '59', '6677', '2013-06-30 16:04:09');
INSERT INTO votes VALUES ('795', '59', '6665', '2013-06-30 16:04:43');
INSERT INTO votes VALUES ('796', '59', '6665', '2013-06-30 16:04:59');
INSERT INTO votes VALUES ('797', '59', '6664', '2013-06-30 16:05:28');
INSERT INTO votes VALUES ('798', '59', '6664', '2013-06-30 16:07:22');
INSERT INTO votes VALUES ('799', '59', '6664', '2013-06-30 16:17:12');
INSERT INTO votes VALUES ('800', '59', '6664', '2013-06-30 16:18:40');
INSERT INTO votes VALUES ('801', '59', '6664', '2013-06-30 16:19:45');
INSERT INTO votes VALUES ('802', '59', '6664', '2013-06-30 16:20:00');
INSERT INTO votes VALUES ('803', '59', '6664', '2013-06-30 16:20:19');
INSERT INTO votes VALUES ('804', '59', '6664', '2013-06-30 16:20:41');
INSERT INTO votes VALUES ('805', '59', '6664', '2013-06-30 16:21:16');
INSERT INTO votes VALUES ('806', '59', '6664', '2013-06-30 16:21:41');
INSERT INTO votes VALUES ('807', '59', '6664', '2013-06-30 16:22:56');
INSERT INTO votes VALUES ('808', '59', '6664', '2013-06-30 16:27:10');
INSERT INTO votes VALUES ('809', '59', '6664', '2013-06-30 16:27:41');
INSERT INTO votes VALUES ('810', '59', '6664', '2013-06-30 16:27:48');
INSERT INTO votes VALUES ('811', '59', '6664', '2013-06-30 16:27:51');
INSERT INTO votes VALUES ('812', '59', '6665', '2013-06-30 16:28:25');
INSERT INTO votes VALUES ('813', '59', '6664', '2013-06-30 16:29:49');
INSERT INTO votes VALUES ('814', '59', '6664', '2013-06-30 16:30:03');
INSERT INTO votes VALUES ('815', '59', '6664', '2013-06-30 16:30:20');
INSERT INTO votes VALUES ('816', '59', '6664', '2013-06-30 16:30:42');
INSERT INTO votes VALUES ('817', '59', '6664', '2013-06-30 16:31:03');
INSERT INTO votes VALUES ('818', '59', '6664', '2013-06-30 16:31:05');
INSERT INTO votes VALUES ('819', '59', '6664', '2013-06-30 16:31:09');
INSERT INTO votes VALUES ('820', '59', '6664', '2013-06-30 16:31:11');
INSERT INTO votes VALUES ('821', '59', '6664', '2013-06-30 16:31:15');
INSERT INTO votes VALUES ('822', '59', '6664', '2013-06-30 16:31:16');
INSERT INTO votes VALUES ('823', '59', '6664', '2013-06-30 16:31:36');
INSERT INTO votes VALUES ('824', '59', '6664', '2013-06-30 16:31:40');
INSERT INTO votes VALUES ('825', '59', '6664', '2013-06-30 16:31:52');
INSERT INTO votes VALUES ('826', '59', '6664', '2013-06-30 16:33:11');
INSERT INTO votes VALUES ('827', '59', '6664', '2013-06-30 16:33:13');
INSERT INTO votes VALUES ('828', '59', '6664', '2013-06-30 16:33:14');
INSERT INTO votes VALUES ('829', '59', '6665', '2013-06-30 16:33:18');
INSERT INTO votes VALUES ('830', '59', '6665', '2013-06-30 16:33:19');
INSERT INTO votes VALUES ('831', '59', '6666', '2013-06-30 16:33:22');
INSERT INTO votes VALUES ('832', '59', '6669', '2013-06-30 16:33:29');
INSERT INTO votes VALUES ('833', '59', '6664', '2013-06-30 16:34:02');
INSERT INTO votes VALUES ('834', '59', '6670', '2013-06-30 16:39:14');
INSERT INTO votes VALUES ('835', '59', '6670', '2013-06-30 16:39:16');
INSERT INTO votes VALUES ('836', '59', '6670', '2013-06-30 16:39:20');
INSERT INTO votes VALUES ('837', '59', '6670', '2013-06-30 16:39:20');
INSERT INTO votes VALUES ('838', '59', '6670', '2013-06-30 16:39:21');
INSERT INTO votes VALUES ('839', '59', '6670', '2013-06-30 16:39:21');
INSERT INTO votes VALUES ('840', '59', '6670', '2013-06-30 16:39:22');
INSERT INTO votes VALUES ('841', '59', '6676', '2013-06-30 16:43:20');
INSERT INTO votes VALUES ('842', '59', '6676', '2013-06-30 16:43:22');
INSERT INTO votes VALUES ('843', '59', '6676', '2013-06-30 16:43:23');
INSERT INTO votes VALUES ('844', '59', '6664', '2013-06-30 16:51:46');
INSERT INTO votes VALUES ('845', '59', '6664', '2013-06-30 16:52:03');
INSERT INTO votes VALUES ('846', '59', '6664', '2013-06-30 16:52:20');
INSERT INTO votes VALUES ('847', '59', '6664', '2013-06-30 16:52:22');
INSERT INTO votes VALUES ('848', '59', '6664', '2013-06-30 16:52:25');
INSERT INTO votes VALUES ('849', '59', '6664', '2013-06-30 16:52:48');
INSERT INTO votes VALUES ('850', '59', '6664', '2013-06-30 16:52:51');
INSERT INTO votes VALUES ('851', '59', '6664', '2013-06-30 16:53:24');
INSERT INTO votes VALUES ('852', '59', '6664', '2013-06-30 16:53:26');
INSERT INTO votes VALUES ('853', '59', '6665', '2013-06-30 16:53:58');
INSERT INTO votes VALUES ('854', '59', '6664', '2013-06-30 16:57:48');
INSERT INTO votes VALUES ('855', '59', '6664', '2013-06-30 16:57:49');
INSERT INTO votes VALUES ('856', '59', '6664', '2013-06-30 16:57:52');
INSERT INTO votes VALUES ('857', '59', '6664', '2013-06-30 16:57:53');
INSERT INTO votes VALUES ('858', '59', '6664', '2013-06-30 16:57:54');
INSERT INTO votes VALUES ('859', '59', '6670', '2013-06-30 16:58:04');
INSERT INTO votes VALUES ('860', '59', '6670', '2013-06-30 16:58:05');
INSERT INTO votes VALUES ('861', '59', '6665', '2013-06-30 16:58:11');
INSERT INTO votes VALUES ('862', '59', '6671', '2013-06-30 16:58:21');
INSERT INTO votes VALUES ('863', '59', '6664', '2013-06-30 17:02:52');
INSERT INTO votes VALUES ('864', '59', '6664', '2013-06-30 17:02:56');
INSERT INTO votes VALUES ('865', '59', '6664', '2013-06-30 17:03:15');
INSERT INTO votes VALUES ('866', '59', '6664', '2013-06-30 17:03:18');
INSERT INTO votes VALUES ('867', '59', '6664', '2013-06-30 17:04:02');
INSERT INTO votes VALUES ('868', '59', '6664', '2013-06-30 17:07:29');
INSERT INTO votes VALUES ('869', '59', '6664', '2013-06-30 17:07:30');
INSERT INTO votes VALUES ('870', '59', '6664', '2013-06-30 17:07:31');
INSERT INTO votes VALUES ('871', '59', '6664', '2013-06-30 17:07:37');
INSERT INTO votes VALUES ('872', '59', '6664', '2013-06-30 17:15:04');
INSERT INTO votes VALUES ('873', '59', '6664', '2013-06-30 17:15:06');
INSERT INTO votes VALUES ('874', '59', '6664', '2013-06-30 17:15:08');
INSERT INTO votes VALUES ('875', '59', '6664', '2013-06-30 17:15:11');
INSERT INTO votes VALUES ('876', '59', '6664', '2013-06-30 17:15:12');
INSERT INTO votes VALUES ('877', '59', '6664', '2013-06-30 17:15:12');
INSERT INTO votes VALUES ('878', '59', '6664', '2013-06-30 17:15:12');
INSERT INTO votes VALUES ('879', '59', '6664', '2013-06-30 17:15:13');
INSERT INTO votes VALUES ('880', '59', '6664', '2013-06-30 17:15:13');
INSERT INTO votes VALUES ('881', '59', '6664', '2013-06-30 17:15:13');
INSERT INTO votes VALUES ('882', '59', '6664', '2013-06-30 17:15:13');
INSERT INTO votes VALUES ('883', '59', '6664', '2013-06-30 17:15:13');
INSERT INTO votes VALUES ('884', '59', '6664', '2013-06-30 17:15:14');
INSERT INTO votes VALUES ('885', '59', '6664', '2013-06-30 17:15:14');
INSERT INTO votes VALUES ('886', '59', '6664', '2013-06-30 17:15:14');
INSERT INTO votes VALUES ('887', '59', '6664', '2013-06-30 17:15:14');
INSERT INTO votes VALUES ('888', '59', '6664', '2013-06-30 17:15:16');
INSERT INTO votes VALUES ('889', '59', '6664', '2013-06-30 17:15:16');
INSERT INTO votes VALUES ('890', '59', '6664', '2013-06-30 17:15:34');
INSERT INTO votes VALUES ('891', '59', '6664', '2013-06-30 17:15:36');
INSERT INTO votes VALUES ('892', '59', '6664', '2013-06-30 17:15:37');
INSERT INTO votes VALUES ('893', '59', '6664', '2013-06-30 17:21:33');
INSERT INTO votes VALUES ('894', '59', '6664', '2013-06-30 17:21:33');
INSERT INTO votes VALUES ('895', '59', '6664', '2013-06-30 17:21:34');
INSERT INTO votes VALUES ('896', '59', '6664', '2013-06-30 17:21:34');
INSERT INTO votes VALUES ('897', '59', '6664', '2013-06-30 17:21:35');
INSERT INTO votes VALUES ('898', '59', '6664', '2013-06-30 17:21:35');
INSERT INTO votes VALUES ('899', '59', '6664', '2013-06-30 17:21:36');
INSERT INTO votes VALUES ('900', '59', '6664', '2013-06-30 17:21:36');
INSERT INTO votes VALUES ('901', '59', '6664', '2013-06-30 17:21:37');
INSERT INTO votes VALUES ('902', '59', '6664', '2013-06-30 17:21:37');
INSERT INTO votes VALUES ('903', '59', '6664', '2013-06-30 17:21:38');
INSERT INTO votes VALUES ('904', '59', '6664', '2013-06-30 17:21:38');
INSERT INTO votes VALUES ('905', '59', '6664', '2013-06-30 17:21:39');
INSERT INTO votes VALUES ('906', '59', '6664', '2013-06-30 17:21:40');
INSERT INTO votes VALUES ('907', '59', '6664', '2013-06-30 17:22:40');
INSERT INTO votes VALUES ('908', '59', '6664', '2013-06-30 17:22:45');
INSERT INTO votes VALUES ('909', '59', '6664', '2013-06-30 17:22:46');
INSERT INTO votes VALUES ('910', '59', '6664', '2013-06-30 17:22:46');
INSERT INTO votes VALUES ('911', '59', '6664', '2013-06-30 17:22:47');
INSERT INTO votes VALUES ('912', '59', '6664', '2013-06-30 17:22:47');
INSERT INTO votes VALUES ('913', '59', '6664', '2013-06-30 17:22:48');
INSERT INTO votes VALUES ('914', '59', '6664', '2013-06-30 17:22:48');
INSERT INTO votes VALUES ('915', '59', '6664', '2013-06-30 17:22:49');
INSERT INTO votes VALUES ('916', '59', '6664', '2013-06-30 17:22:49');
INSERT INTO votes VALUES ('917', '59', '6664', '2013-06-30 17:22:50');
INSERT INTO votes VALUES ('918', '59', '6664', '2013-06-30 17:27:39');
INSERT INTO votes VALUES ('919', '59', '6664', '2013-06-30 17:27:55');
INSERT INTO votes VALUES ('920', '59', '6664', '2013-06-30 17:43:56');
INSERT INTO votes VALUES ('921', '59', '6673', '2013-06-30 17:45:12');
INSERT INTO votes VALUES ('922', '59', '6673', '2013-06-30 17:45:15');
INSERT INTO votes VALUES ('923', '59', '6673', '2013-06-30 17:45:15');
INSERT INTO votes VALUES ('924', '59', '6673', '2013-06-30 17:45:16');
INSERT INTO votes VALUES ('925', '59', '6673', '2013-06-30 17:45:16');
INSERT INTO votes VALUES ('926', '59', '6673', '2013-06-30 17:45:17');
INSERT INTO votes VALUES ('927', '59', '6673', '2013-06-30 17:45:17');
INSERT INTO votes VALUES ('928', '59', '6664', '2013-06-30 17:47:51');
INSERT INTO votes VALUES ('929', '59', '6664', '2013-06-30 17:48:31');
INSERT INTO votes VALUES ('930', '59', '6664', '2013-06-30 17:50:17');
INSERT INTO votes VALUES ('931', '59', '6664', '2013-06-30 17:51:26');
INSERT INTO votes VALUES ('932', '59', '6663', '2013-06-30 17:52:54');
INSERT INTO votes VALUES ('933', '59', '6663', '2013-06-30 17:52:55');
INSERT INTO votes VALUES ('934', '59', '6663', '2013-06-30 17:52:55');
INSERT INTO votes VALUES ('935', '59', '6663', '2013-06-30 17:52:55');
INSERT INTO votes VALUES ('936', '59', '6663', '2013-06-30 17:52:55');
INSERT INTO votes VALUES ('937', '59', '6663', '2013-06-30 17:52:55');
INSERT INTO votes VALUES ('938', '59', '6671', '2013-06-30 17:58:27');
INSERT INTO votes VALUES ('939', '59', '6664', '2013-06-30 17:59:02');
INSERT INTO votes VALUES ('940', '59', '6664', '2013-06-30 17:59:06');
INSERT INTO votes VALUES ('941', '59', '6664', '2013-06-30 18:02:05');
INSERT INTO votes VALUES ('942', '59', '6664', '2013-06-30 18:02:20');
INSERT INTO votes VALUES ('943', '59', '6671', '2013-06-30 18:03:26');
INSERT INTO votes VALUES ('944', '59', '6664', '2013-06-30 18:19:09');
INSERT INTO votes VALUES ('945', '59', '6664', '2013-06-30 18:19:17');
INSERT INTO votes VALUES ('946', '59', '6664', '2013-06-30 18:19:19');
INSERT INTO votes VALUES ('947', '59', '6664', '2013-06-30 18:19:20');
INSERT INTO votes VALUES ('948', '59', '6664', '2013-06-30 18:19:22');
INSERT INTO votes VALUES ('949', '59', '6664', '2013-06-30 18:19:22');
INSERT INTO votes VALUES ('950', '59', '6664', '2013-06-30 18:19:23');
INSERT INTO votes VALUES ('951', '59', '6664', '2013-06-30 18:21:56');
INSERT INTO votes VALUES ('952', '59', '6664', '2013-06-30 18:21:58');
INSERT INTO votes VALUES ('953', '59', '6664', '2013-06-30 18:21:58');
INSERT INTO votes VALUES ('954', '59', '6664', '2013-06-30 18:21:59');
INSERT INTO votes VALUES ('955', '59', '6666', '2013-06-30 18:30:20');
INSERT INTO votes VALUES ('956', '59', '6666', '2013-06-30 18:30:20');
INSERT INTO votes VALUES ('957', '59', '6666', '2013-06-30 18:30:21');
INSERT INTO votes VALUES ('958', '59', '6665', '2013-06-30 19:12:35');
INSERT INTO votes VALUES ('959', '59', '6664', '2013-06-30 19:17:14');
INSERT INTO votes VALUES ('960', '59', '6664', '2013-06-30 19:18:26');
INSERT INTO votes VALUES ('961', '59', '6664', '2013-06-30 19:18:28');
INSERT INTO votes VALUES ('962', '59', '6664', '2013-06-30 19:18:29');
INSERT INTO votes VALUES ('963', '59', '6664', '2013-06-30 19:18:30');
INSERT INTO votes VALUES ('964', '59', '6665', '2013-06-30 19:18:35');
INSERT INTO votes VALUES ('965', '59', '6665', '2013-06-30 19:18:37');
INSERT INTO votes VALUES ('966', '59', '6665', '2013-06-30 19:18:39');
INSERT INTO votes VALUES ('967', '59', '6665', '2013-06-30 19:18:40');
INSERT INTO votes VALUES ('968', '59', '6666', '2013-06-30 19:18:52');
INSERT INTO votes VALUES ('969', '59', '6672', '2013-06-30 19:34:23');
INSERT INTO votes VALUES ('970', '59', '6673', '2013-06-30 19:34:27');
INSERT INTO votes VALUES ('971', '59', '6664', '2013-07-03 12:00:24');
INSERT INTO votes VALUES ('972', '59', '6664', '2013-07-03 12:00:25');
INSERT INTO votes VALUES ('973', '59', '6664', '2013-07-03 12:00:26');
INSERT INTO votes VALUES ('974', '59', '6664', '2013-07-03 12:00:27');
INSERT INTO votes VALUES ('975', '59', '6664', '2013-07-03 12:00:29');
INSERT INTO votes VALUES ('976', '59', '6664', '2013-07-03 12:00:30');
INSERT INTO votes VALUES ('977', '59', '6664', '2013-07-03 12:00:32');
INSERT INTO votes VALUES ('978', '59', '6664', '2013-07-03 12:00:35');
INSERT INTO votes VALUES ('979', '59', '6664', '2013-07-03 12:00:36');
INSERT INTO votes VALUES ('980', '59', '6664', '2013-07-03 12:00:36');
INSERT INTO votes VALUES ('981', '59', '6674', '2013-07-08 09:40:17');
INSERT INTO votes VALUES ('982', '59', '6674', '2013-07-08 09:40:23');
INSERT INTO votes VALUES ('983', '59', '6676', '2013-07-08 09:40:36');
INSERT INTO votes VALUES ('984', '59', '6676', '2013-07-08 09:40:38');
INSERT INTO votes VALUES ('985', '59', '6676', '2013-07-08 09:40:39');
INSERT INTO votes VALUES ('986', '59', '6676', '2013-07-08 09:40:40');
INSERT INTO votes VALUES ('987', '59', '6676', '2013-07-08 09:40:40');
INSERT INTO votes VALUES ('988', '59', '6670', '2013-07-09 05:37:05');
INSERT INTO votes VALUES ('989', '59', '6666', '2013-07-09 05:43:06');
INSERT INTO votes VALUES ('990', '59', '6666', '2013-07-09 05:43:53');
INSERT INTO votes VALUES ('991', '59', '6664', '2013-07-09 05:52:40');
INSERT INTO votes VALUES ('992', '59', '6664', '2013-07-09 05:52:47');
INSERT INTO votes VALUES ('993', '59', '6665', '2013-07-09 06:01:50');
INSERT INTO votes VALUES ('994', '59', '6670', '2013-07-09 17:34:45');
INSERT INTO votes VALUES ('995', '59', '6668', '2013-07-09 17:40:11');
INSERT INTO votes VALUES ('996', '59', '6668', '2013-07-09 17:40:13');
INSERT INTO votes VALUES ('997', '59', '6668', '2013-07-09 17:53:50');
INSERT INTO votes VALUES ('998', '59', '6669', '2013-07-09 18:24:57');
INSERT INTO votes VALUES ('999', '59', '6666', '2013-07-09 18:53:12');
INSERT INTO votes VALUES ('1000', '59', '7006', '2013-07-20 16:37:18');
INSERT INTO votes VALUES ('1001', '59', '6887', '2013-08-08 15:32:49');
INSERT INTO votes VALUES ('1002', '59', '6887', '2013-08-08 17:58:09');
INSERT INTO votes VALUES ('1003', '59', '7006', '2013-08-08 17:58:16');
INSERT INTO votes VALUES ('1004', '59', '6886', '2013-09-06 03:04:00');
INSERT INTO votes VALUES ('1005', '59', '6886', '2013-09-08 19:59:05');
INSERT INTO votes VALUES ('1006', '59', '6884', '2013-09-10 20:14:51');
INSERT INTO votes VALUES ('1007', '59', '6887', '2013-09-10 22:52:00');
INSERT INTO votes VALUES ('1008', '59', '6919', '2013-09-24 16:42:15');
INSERT INTO votes VALUES ('1009', '59', '6887', '2013-09-24 18:17:26');


